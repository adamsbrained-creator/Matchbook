package com.matchbook.app

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.hypot

// =====================================================================================================
// Full screen map (3.9): the dotted world map over the whole screen, in portrait and in landscape.
// Pinch to zoom, drag to move, tap a country or a pin to pick it, then "Show" to use it on the page
// you came from. [mode] is "home" or "world" and says which page's country is picked.
// =====================================================================================================

@Composable
fun FullMapDialog(vm: AppVM, mode: String) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    var shapes by remember { mutableStateOf(WorldGeo.cached()) }
    LaunchedEffect(Unit) { if (shapes == null) shapes = WorldGeo.load(ctx) }
    val sh = shapes
    val groups = remember(vm.leagues, sh) { buildGroups(vm, sh) }
    var sel by remember { mutableStateOf(if (mode == "world") vm.worldCountry else vm.homeCountry) }
    val cur = groups.firstOrNull { it.key == sel }
    val leagueKeys = remember(groups) { groups.filter { it.shape != null }.map { it.key }.toSet() }

    var box by remember { mutableStateOf(IntSize.Zero) }
    var cam by remember { mutableStateOf<Cam?>(null) }
    var anim by remember { mutableStateOf<Job?>(null) }
    fun flyTo(t: Cam) {
        val from = cam ?: return
        anim?.cancel()
        anim = scope.launch {
            Animatable(0f).animateTo(1f, tween(450)) {
                cam = Cam(lerp(from.s, t.s, value), lerp(from.tx, t.tx, value), lerp(from.ty, t.ty, value))
            }
        }
    }
    LaunchedEffect(box, sh) {
        if (box.width > 0 && cam == null) {
            val w = box.width.toFloat(); val h = box.height.toFloat()
            cam = cur?.shape?.let { fitCam(it.focus, w, h) } ?: homeCam(w, h)
        }
    }

    val ocean = if (u.coral) u.track else u.sf
    val land = androidx.compose.ui.graphics.lerp(ocean, u.ink, if (u.dark) .26f else .30f)
    val dots = remember { DotField() }
    val hot = remember(groups) { hotKeys(groups) }
    val hotIdx = remember(sh, hot) { BooleanArray(sh?.size ?: 0) { sh!![it].key in hot } }
    val pickSet = pickSetFor(sh, cur?.key, groups)
    val memberGroup = remember(groups) { regionOfCountry(groups) }
    val dotPx = with(density) { 3.6.dp.toPx() }
    val pinR = with(density) { 12.dp.toPx() }
    val textMeasurer = rememberTextMeasurer()
    val items = remember(groups, vm.clubs) {
        groups.mapNotNull { g ->
            g.shape?.let { s ->
                PinItem(g.key, s.center.x, s.center.y, vm.clubs.count { c -> g.leagues.any { it.id == c.lid } }.toString(), u.acc, g.leagues.size)
            }
        }
    }
    val itemsNow by rememberUpdatedState(items)
    val shapesNow by rememberUpdatedState(sh)
    val keysNow by rememberUpdatedState(leagueKeys)
    val memberNow by rememberUpdatedState(memberGroup)

    Dialog(onDismissRequest = { vm.mapFull = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        // draw under the status bar and the cutout, and hide the system bars while the map is open
        val view = LocalView.current
        DisposableEffect(view) {
            val w = (view.parent as? DialogWindowProvider)?.window
            if (w != null) {
                WindowCompat.setDecorFitsSystemWindows(w, false)
                w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
                if (Build.VERSION.SDK_INT >= 28) {
                    w.attributes = w.attributes.apply {
                        layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                val ctl = WindowCompat.getInsetsController(w, view)
                ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(WindowInsetsCompat.Type.systemBars())
            }
            onDispose { }
        }
        Box(Modifier.fillMaxSize().background(ocean).onSizeChanged { box = it }) {
            Canvas(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val c = cam ?: return@detectTransformGestures
                            anim?.cancel()
                            val w = box.width.toFloat(); val h = box.height.toFloat()
                            val minS = w / 360f
                            val ns = (c.s * zoom).coerceIn(minS, minS * 80f)
                            val z = ns / c.s
                            cam = clampCam(Cam(ns, centroid.x - (centroid.x - c.tx) * z + pan.x, centroid.y - (centroid.y - c.ty) * z + pan.y), w, h)
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { p ->
                            val c = cam ?: return@detectTapGestures
                            val w = box.width.toFloat(); val h = box.height.toFloat()
                            val hit = pinsFor(itemsNow, c, pinR * 2.1f).minByOrNull { hypot(it.x - p.x, it.y - p.y) }
                                ?.takeIf { hypot(it.x - p.x, it.y - p.y) <= pinR * 1.5f }
                            if (hit != null) {
                                if (hit.items.size > 1) {
                                    val b = floatArrayOf(hit.items.minOf { it.lon } - .4f, hit.items.minOf { it.lat } - .4f, hit.items.maxOf { it.lon } + .4f, hit.items.maxOf { it.lat } + .4f)
                                    flyTo(fitCam(b, w, h))
                                } else sel = hit.items[0].id
                                return@detectTapGestures
                            }
                            val lon = (p.x - c.tx) / c.s; val lat = -(p.y - c.ty) / c.s
                            val s = shapesNow?.filter { val b = it.bbox; lon >= b[0] && lon <= b[2] && lat >= b[1] && lat <= b[3] && it.test(lon, lat) }
                                ?.minByOrNull { (it.bbox[2] - it.bbox[0]) * (it.bbox[3] - it.bbox[1]) }
                            sel = s?.let { if (it.key in keysNow) it.key else memberNow[it.key] } ?: ""
                        }
                    },
            ) {
                val c = cam ?: return@Canvas
                val list = sh ?: return@Canvas
                drawDots(dots, list, c, dotPx, land, u.acc.copy(alpha = .8f), u.acc, hotIdx, pickSet)
                for (pv in pinsFor(items, c, pinR * 2.1f)) {
                    if (pv.x < -pinR || pv.y < -pinR || pv.x > size.width + pinR || pv.y > size.height + pinR) continue
                    val single = pv.items.size == 1
                    val it0 = pv.items[0]
                    val on = single && it0.id == cur?.key
                    val fill = if (on) u.acc else u.menuBg
                    val fg = if (on) u.on else u.ink
                    if (on) drawCircle(u.acc, pinR + 5.dp.toPx(), Offset(pv.x, pv.y), style = Stroke(2.dp.toPx()))
                    drawCircle(Color.Black.copy(alpha = .3f), pinR + 1.dp.toPx(), Offset(pv.x, pv.y + 1.dp.toPx()))
                    drawCircle(fill, pinR, Offset(pv.x, pv.y))
                    if (!on) drawCircle(u.ln, pinR, Offset(pv.x, pv.y), style = Stroke(1.dp.toPx()))
                    val label = if (single) it0.label else pv.items.size.toString()
                    val txt = textMeasurer.measure(label, TextStyle(fontSize = if (label.length > 2) 9.sp else 11.sp, fontWeight = FontWeight.Bold, color = fg))
                    drawText(txt, topLeft = Offset(pv.x - txt.size.width / 2f, pv.y - txt.size.height / 2f))
                }
            }
            if (sh == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Tx("Loading the map...", 13 * u.fs, 600, u.mu)
            }
            // close, top left
            Box(
                Modifier.align(Alignment.TopStart).windowInsetsPadding(WindowInsets.safeDrawing).padding(14.dp)
                    .size(46.dp).clip(CircleShape).background(u.menuBg).clickable { vm.mapFull = null },
                contentAlignment = Alignment.Center,
            ) { Ico("close", 20.dp, u.ink, 2f) }
            // back to the whole world, bottom right
            Box(
                Modifier.align(Alignment.BottomEnd).windowInsetsPadding(WindowInsets.safeDrawing).padding(14.dp)
                    .size(46.dp).clip(CircleShape).background(u.menuBg)
                    .clickable { if (box.width > 0) flyTo(homeCam(box.width.toFloat(), box.height.toFloat())) },
                contentAlignment = Alignment.Center,
            ) { Ico("globe", 20.dp, u.ink, 1.9f) }
            // what is picked, bottom left
            Row(
                Modifier.align(Alignment.BottomStart).windowInsetsPadding(WindowInsets.safeDrawing).padding(start = 14.dp, bottom = 14.dp, end = 76.dp)
                    .clip(CircleShape).background(u.menuBg.copy(alpha = .94f)).padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (cur == null) Tx(if (sh == null) "" else "Pinch to zoom · tap a country", 12.5f * u.fs, 700, u.ink, Modifier.padding(vertical = 8.dp))
                else {
                    val nClubs = vm.clubs.count { c -> cur.leagues.any { it.id == c.lid } }
                    Column(Modifier.weight(1f, false)) {
                        Tx(flag(cur.label) + cur.label, 14 * u.fs, 800, u.ink, maxLines = 1)
                        Tx("${cur.leagues.size} ${if (cur.leagues.size == 1) "league" else "leagues"} · $nClubs clubs", 11.5f * u.fs, 600, u.mu, maxLines = 1)
                    }
                    SmallBtn("Show") {
                        if (mode == "world") { vm.worldCountry = cur.key; vm.worldLeague = "" } else { vm.homeCountry = cur.key; vm.homeLeague = "" }
                        vm.mapFull = null
                    }
                }
            }
        }
    }
}
