package com.matchbook.app

import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.pow

// =====================================================================================================
// Dotted world (3.3): land is drawn as a lattice of dots instead of filled shapes.
// The lattice step is a power of the square root of two, so it changes in small jumps while you zoom.
// Which country each dot belongs to is found by painting the country shapes into a small off-screen
// bitmap (one pixel per dot, one colour per country) and reading it back. The bitmap covers more than
// the screen, so panning does not repaint it every frame.
// =====================================================================================================

class DotField {
    private var src: List<GeoShape>? = null
    private var step = 0f
    private var i0 = 0
    private var j0 = 0
    private var cols = 0
    private var rows = 0
    private var ids = IntArray(0)

    /** Index of the country + 1 at lattice cell (i, j), or 0 for sea. */
    fun at(i: Int, j: Int): Int {
        val a = i - i0; val b = j - j0
        return if (a < 0 || b < 0 || a >= cols || b >= rows) 0 else ids[b * cols + a]
    }

    fun ensure(list: List<GeoShape>, st: Float, vi0: Int, vj0: Int, vc: Int, vr: Int) {
        if (src === list && step == st && vi0 >= i0 && vj0 >= j0 && vi0 + vc <= i0 + cols && vj0 + vr <= j0 + rows) return
        val mc = vc / 2 + 2; val mr = vr / 2 + 2
        val ni0 = vi0 - mc; val nj0 = vj0 - mr; val nc = vc + 2 * mc; val nr = vr + 2 * mr
        src = list; step = st
        if (nc <= 0 || nr <= 0 || nc.toLong() * nr > 700_000L) { i0 = 0; j0 = 0; cols = 0; rows = 0; ids = IntArray(0); return }
        val bmp = Bitmap.createBitmap(nc, nr, Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }
        cv.scale(1f / st, 1f / st)
        cv.translate(-ni0 * st, -nj0 * st)
        val x0 = ni0 * st; val x1 = (ni0 + nc) * st; val y0 = nj0 * st; val y1 = (nj0 + nr) * st
        for ((k, sp) in list.withIndex()) {
            val b = sp.bbox                       // minLon, minLat, maxLon, maxLat; y on screen is minus latitude
            if (b[2] < x0 || b[0] > x1 || -b[1] < y0 || -b[3] > y1) continue
            p.color = (0xFF shl 24) or (k + 1)
            cv.drawPath(sp.path.asAndroidPath(), p)
        }
        val px = IntArray(nc * nr)
        bmp.getPixels(px, 0, nc, 0, 0, nc, nr)
        bmp.recycle()
        for (q in px.indices) px[q] = px[q] and 0xFFFFFF
        ids = px; i0 = ni0; j0 = nj0; cols = nc; rows = nr
    }
}

/**
 * Draws the dots for the camera [c]. [spacingPx] is the wanted distance between dots on screen.
 * Countries flagged in [hotIdx] (they have leagues) use [hot], the countries flagged in [pickSet] use [pick] and a bigger dot.
 */
internal fun DrawScope.drawDots(
    f: DotField, list: List<GeoShape>, c: Cam, spacingPx: Float,
    land: Color, hot: Color, pick: Color, hotIdx: BooleanArray, pickSet: BooleanArray,
) {
    val s = c.s
    val lvl = ceil(log2(spacingPx / s) * 2f).toInt()
    val st = 2f.pow(lvl / 2f)
    val vi0 = floor((-c.tx / s) / st).toInt() - 1
    val vi1 = ceil(((size.width - c.tx) / s) / st).toInt() + 1
    val vj0 = floor((-c.ty / s) / st).toInt() - 1
    val vj1 = ceil(((size.height - c.ty) / s) / st).toInt() + 1
    f.ensure(list, st, vi0, vj0, vi1 - vi0 + 1, vj1 - vj0 + 1)
    val a = ArrayList<Offset>(); val b = ArrayList<Offset>(); val d = ArrayList<Offset>()
    val cell = st * s
    for (j in vj0..vj1) {
        val y = (j + .5f) * cell + c.ty
        for (i in vi0..vi1) {
            val id = f.at(i, j)
            if (id == 0) continue
            val o = Offset((i + .5f) * cell + c.tx, y)
            val k = id - 1
            if (k < pickSet.size && pickSet[k]) d.add(o) else if (k < hotIdx.size && hotIdx[k]) b.add(o) else a.add(o)
        }
    }
    if (a.isNotEmpty()) drawPoints(a, PointMode.Points, land, cell * .46f, StrokeCap.Round)
    if (b.isNotEmpty()) drawPoints(b, PointMode.Points, hot, cell * .56f, StrokeCap.Round)
    if (d.isNotEmpty()) drawPoints(d, PointMode.Points, pick, cell * .68f, StrokeCap.Round)
}
