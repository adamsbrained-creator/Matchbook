package com.matchbook.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.max

// =====================================================================================================
// Home (3.3): the first page. A dotted map at the top with a pin for every country that has leagues,
// and a sheet over it for the chosen country: its clubs, the next match and the top of the table.
// =====================================================================================================

/** True while a page draws under the status bar (Home does, so its map reaches the top of the screen). */
val LocalEdge = compositionLocalOf { false }

private val SheetShape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)

@Composable
private fun HomeChip(t: String, on: Boolean, small: Boolean = false, onClick: () -> Unit) {
    val u = LocalU.current
    Box(
        Modifier.height(if (small) 34.dp else 40.dp).clip(RoundedCornerShape(20.dp))
            .background(if (on) u.pri else if (u.coral) u.bg else u.fieldFill)
            .clickable(onClick = onClick).padding(horizontal = if (small) 14.dp else 16.dp),
        contentAlignment = Alignment.Center,
    ) { Tx(t, (if (small) 12.5f else 14f) * u.fs, if (on) 800 else 600, if (on) u.onPri else u.ink.copy(alpha = .85f), maxLines = 1) }
}

@Composable
fun HomePage(vm: AppVM) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val edge = LocalEdge.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    var shapes by remember { mutableStateOf(WorldGeo.cached()) }
    LaunchedEffect(Unit) { if (shapes == null) shapes = WorldGeo.load(ctx) }
    val sh = shapes
    val groups = remember(vm.leagues, sh) { buildGroups(vm, sh) }
    val cur = groups.firstOrNull { it.key == vm.homeCountry } ?: groups.firstOrNull()
    val curShape = cur?.shape
    val leagueKeys = remember(groups) { groups.filter { it.shape != null }.map { it.key }.toSet() }

    // ---- map camera
    var box by remember { mutableStateOf(IntSize.Zero) }
    var cam by remember { mutableStateOf<Cam?>(null) }
    var anim by remember { mutableStateOf<Job?>(null) }
    val shift = with(density) { (if (edge) 30.dp else 12.dp).toPx() }
    fun targetCam(): Cam {
        val w = box.width.toFloat(); val hh = box.height.toFloat()
        val f = curShape?.focus ?: return homeCam(w, hh)
        val cx = (f[0] + f[2]) / 2f; val cy = (f[1] + f[3]) / 2f
        val hw = max((f[2] - f[0]) * .9f, 9f); val hy = max((f[3] - f[1]) * .9f, 6f)
        val c = fitCam(floatArrayOf(cx - hw, cy - hy, cx + hw, cy + hy), w, hh)
        return clampCam(Cam(c.s, c.tx, c.ty + shift), w, hh)
    }
    LaunchedEffect(box, cur?.key, sh) {
        if (box.width <= 0) return@LaunchedEffect
        val t = targetCam()
        val from = cam ?: homeCam(box.width.toFloat(), box.height.toFloat()).also { cam = it }
        anim?.cancel()
        anim = scope.launch {
            Animatable(0f).animateTo(1f, tween(500)) {
                cam = Cam(lerp(from.s, t.s, value), lerp(from.tx, t.tx, value), lerp(from.ty, t.ty, value))
            }
        }
    }

    val ocean = if (u.coral) u.track else u.sf
    val land = androidx.compose.ui.graphics.lerp(ocean, u.ink, if (u.dark) .26f else .30f)
    val dots = remember { DotField() }
    val hot = remember(groups) { hotKeys(groups) }
    val hotIdx = remember(sh, hot) { BooleanArray(sh?.size ?: 0) { sh!![it].key in hot } }
    val pickSet = pickSetFor(sh, cur?.key, groups)
    val memberGroup = remember(groups) { regionOfCountry(groups) }
    val memberGroupNow by rememberUpdatedState(memberGroup)
    val dotPx = with(density) { 3.6.dp.toPx() }
    val pinR = with(density) { 12.dp.toPx() }
    val textMeasurer = rememberTextMeasurer()
    val items = remember(groups, vm.clubs) {
        groups.mapNotNull { g ->
            g.shape?.let { s ->
                PinItem(g.key, s.center.x, s.center.y, vm.clubs.count { c -> g.leagues.any { it.id == c.lid } }.toString(), u.acc, g.leagues.size)
            }
        }
    }
    val itemsNow by rememberUpdatedState(items)
    val shapesNow by rememberUpdatedState(sh)
    val keysNow by rememberUpdatedState(leagueKeys)

    val mapH = 330.dp + (if (edge) topInset else 0.dp)
    Box(Modifier.fillMaxWidth().height(mapH).background(ocean).onSizeChanged { box = it }) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectTapGestures { p ->
                    val c = cam ?: return@detectTapGestures
                    val hit = pinsFor(itemsNow, c, pinR * 2.1f).minByOrNull { hypot(it.x - p.x, it.y - p.y) }
                        ?.takeIf { hypot(it.x - p.x, it.y - p.y) <= pinR * 1.5f }
                    if (hit != null && hit.items.size == 1) { vm.homeCountry = hit.items[0].id; vm.homeLeague = ""; return@detectTapGestures }
                    val lon = (p.x - c.tx) / c.s; val lat = -(p.y - c.ty) / c.s
                    val s = shapesNow?.filter { val b = it.bbox; lon >= b[0] && lon <= b[2] && lat >= b[1] && lat <= b[3] && it.test(lon, lat) }
                        ?.minByOrNull { (it.bbox[2] - it.bbox[0]) * (it.bbox[3] - it.bbox[1]) }
                    val gk = s?.let { if (it.key in keysNow) it.key else memberGroupNow[it.key] }
                    if (gk != null) { vm.homeCountry = gk; vm.homeLeague = "" }
                }
            },
        ) {
            val c = cam ?: return@Canvas
            val list = sh ?: return@Canvas
            drawDots(dots, list, c, dotPx, land, u.acc.copy(alpha = .8f), u.acc, hotIdx, pickSet)
            for (pv in pinsFor(items, c, pinR * 2.1f)) {
                if (pv.x < -pinR || pv.y < -pinR || pv.x > size.width + pinR || pv.y > size.height + pinR) continue
                val single = pv.items.size == 1
                val it0 = pv.items[0]
                val on = single && it0.id == cur?.key
                val fill = if (on) u.acc else u.menuBg
                val fg = if (on) u.on else u.ink
                if (on) drawCircle(u.acc, pinR + 5.dp.toPx(), Offset(pv.x, pv.y), style = Stroke(2.dp.toPx()))
                drawCircle(Color.Black.copy(alpha = .3f), pinR + 1.dp.toPx(), Offset(pv.x, pv.y + 1.dp.toPx()))
                drawCircle(fill, pinR, Offset(pv.x, pv.y))
                if (!on) drawCircle(u.ln, pinR, Offset(pv.x, pv.y), style = Stroke(1.dp.toPx()))
                val label = if (single) it0.label else pv.items.size.toString()
                val txt = textMeasurer.measure(label, TextStyle(fontSize = if (label.length > 2) 9.sp else 11.sp, fontWeight = FontWeight.Bold, color = fg))
                drawText(txt, topLeft = Offset(pv.x - txt.size.width / 2f, pv.y - txt.size.height / 2f))
            }
        }
        if (sh == null) Box(Modifier.fillMaxSize().padding(top = 120.dp), contentAlignment = Alignment.TopCenter) {
            Tx("Loading the map...", 13 * u.fs, 600, u.mu)
        }
        // header buttons floating over the map
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = (if (edge) topInset else 0.dp) + 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(48.dp)) {
                if (u.coral || u.s.navs == "drawer") CircleBtn("menu", { if (u.s.navs == "drawer") vm.navOpen = true else vm.openMenu() })
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(Modifier.clip(CircleShape).background(u.menuBg.copy(alpha = .9f)).padding(horizontal = 18.dp, vertical = 10.dp)) {
                    Tx("matchbook", 16 * u.fs, 600, u.ink)
                }
            }
            Box(Modifier.width(48.dp), contentAlignment = Alignment.CenterEnd) {
                CircleBtn("search", { vm.selectTab("clubs"); vm.toggleSearch() })
            }
        }
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 46.dp).size(44.dp).clip(CircleShape).background(u.menuBg)
                .clickable { vm.worldCountry = cur?.key ?: ""; vm.worldLeague = ""; vm.openWorld() },
            contentAlignment = Alignment.Center,
        ) { Ico("globe", 20.dp, u.ink, 1.9f) }
    }

    // ---- sheet
    Column(
        Modifier.fillMaxWidth().offset(y = (-34).dp).clip(SheetShape).background(u.sf).padding(start = 20.dp, end = 20.dp, top = 10.dp),
    ) {
        Box(Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(5.dp).clip(CircleShape).background(u.mu.copy(alpha = .35f)))
        if (u.coral && u.s.navs == "tabs") Box(Modifier.padding(top = 4.dp).offset(x = (-24).dp)) { HeaderTabs(vm) }
        Spacer(Modifier.height(16.dp))

        if (cur == null) {
            EmptyBlock("No leagues yet. Add a league with a country and it appears on the map.") {
                SmallBtn("Create a league") { vm.newLeague() }
                SmallBtn("Load sample data", "s") { vm.loadSample() }
            }
        } else {
            val nClubs = vm.clubs.count { c -> cur.leagues.any { it.id == c.lid } }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Hd(flag(cur.label) + cur.label, 26f, modifier = Modifier.weight(1f, false), maxLines = 1)
                Tx("${cur.leagues.size} ${if (cur.leagues.size == 1) "league" else "leagues"} · $nClubs clubs", 13 * u.fs, 600, u.mu, Modifier.padding(bottom = 4.dp), maxLines = 1)
            }
            if (groups.size > 1) Row(Modifier.padding(top = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                groups.forEach { g -> HomeChip(g.label, g.key == cur.key) { vm.homeCountry = g.key; vm.homeLeague = "" } }
            }
            val lg = cur.leagues.firstOrNull { it.id == vm.homeLeague } ?: cur.leagues.first()
            if (cur.leagues.size > 1) Row(Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cur.leagues.forEach { l -> HomeChip(l.name, l.id == lg.id, small = true) { vm.homeLeague = l.id } }
            }

            // clubs of the country
            val clubs = cur.leagues.flatMap { l -> vm.table(l.id) }.take(40)
            if (clubs.isEmpty()) {
                Tx("No clubs in ${cur.label} yet.", 14 * u.fs, 500, u.mu, Modifier.padding(top = 18.dp))
                Row(Modifier.padding(top = 4.dp)) { SmallBtn("Add a club") { vm.newClub(lg.id) } }
            } else Row(Modifier.padding(top = 18.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                clubs.forEach { c ->
                    Column(
                        Modifier.width(64.dp).clip(RoundedCornerShape(14.dp)).clickable { vm.openClub(c.id) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        Crest(c.color, c.c2, c.logo, ab(c.name, c.short), 56.dp, backdrop = c.logoBg)
                        Tx(vm.nm(c), 12 * u.fs, 600, u.ink.copy(alpha = .85f), align = TextAlign.Center, maxLines = 1)
                    }
                }
            }

            // next match
            val fx = cur.leagues.mapNotNull { vm.nextFixture(it.id) }.minByOrNull { it.at }
            Row(
                Modifier.padding(top = 18.dp).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(u.bg)
                    .clickable { if (fx != null) vm.openFixtures(fx.lid) else vm.newFixture(lg.id) }.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Column(Modifier.weight(1f)) {
                    if (fx != null) {
                        Tx("NEXT UP · " + fmtFixture(fx.at).uppercase(), 11 * u.fs, 700, u.acc, maxLines = 1)
                        val a = vm.cl(fx.home)?.let { vm.nm(it) } ?: "?"
                        val b = vm.cl(fx.away)?.let { vm.nm(it) } ?: "?"
                        Tx("$a vs $b", 16 * u.fs, 700, u.ink, Modifier.padding(top = 4.dp), maxLines = 1)
                    } else {
                        Tx("NEXT UP", 11 * u.fs, 700, u.acc)
                        Tx("Nothing scheduled. Tap to add a fixture.", 14 * u.fs, 500, u.mu, Modifier.padding(top = 4.dp), maxLines = 2)
                    }
                }
                Ico(if (fx != null) "chev" else "plus", 16.dp, u.mu, 2.2f)
            }

            // top of the table
            val quals = remember(lg.quals) { parseQuals(lg.quals) }
            val rows = vm.table(lg.id).take(4)
            Column(Modifier.padding(top = 12.dp).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(u.bg).padding(horizontal = 16.dp, vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx(lg.name, 14 * u.fs, 800, modifier = Modifier.weight(1f), maxLines = 1)
                    Tx("Full table", 12.5f * u.fs, 700, u.acc, Modifier.clip(CircleShape).clickable { vm.openTable(lg.id) }.padding(horizontal = 8.dp, vertical = 8.dp))
                }
                if (rows.isEmpty()) Tx("No clubs yet", 13 * u.fs, 500, u.mu, Modifier.padding(bottom = 14.dp))
                rows.forEachIndexed { i, c ->
                    val q = quals.at(i + 1)
                    Row(
                        Modifier.fillMaxWidth().height(52.dp).clickable { vm.openClub(c.id) }
                            .drawBehind { drawLine(u.ln, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx()) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (q != null) Box(Modifier.width(3.dp).height(28.dp).clip(CircleShape).background(hex(q.color)))
                        Spacer(Modifier.width(if (q != null) 9.dp else 12.dp))
                        Tx("${i + 1}", 14 * u.fs, 800, modifier = Modifier.width(22.dp))
                        Crest(c.color, c.c2, c.logo, ab(c.name, c.short), 32.dp, backdrop = c.logoBg)
                        Tx(vm.nm(c), 15 * u.fs, 700, modifier = Modifier.weight(1f).padding(start = 12.dp), maxLines = 1)
                        Tx("${vm.pts(c)}", 15 * u.fs, 800)
                    }
                }
            }
        }
        Spacer(Modifier.height(150.dp))
    }
}
