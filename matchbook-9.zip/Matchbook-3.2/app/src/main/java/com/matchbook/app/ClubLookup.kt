package com.matchbook.app

import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

// =====================================================================================================
// Club lookup (2.8): type "Liverpool", pick the club, and the form fills itself in.
//   TheSportsDB   name, short name, nickname, founded, stadium, capacity, city, colours, crest, league, description
//   Wikipedia     the "About" text (first paragraphs of the article), found by searching the club name
//   Wikidata      current manager and chairman (head coach / chairperson), founding year when TheSportsDB has none
// Everything lands in the normal form fields, so it stays editable. Missing data is simply left blank.
// =====================================================================================================

data class OlClub(
    val id: String, val name: String, val short: String, val nick: String, val city: String, val country: String,
    val founded: String, val stadium: String, val cap: String, val league: String,
    val c1: String, val c2: String, val badge: String, val desc: String, val web: String,
)

data class OlClubExtra(val about: String, val mgr: String, val chair: String, val founded: String, val thumb: String = "")

object OlClubs {
    private const val KEY = "123"

    private fun JSONObject.t(k: String): String = if (isNull(k)) "" else optString(k, "").trim().let { if (it == "null") "" else it }

    /** TheSportsDB first; if it is down, refuses us or knows nothing, fall back to Wikipedia so the lookup still works. */
    fun search(q: String): List<OlClub> {
        var err: Exception? = null
        val a = try { searchDb(q) } catch (e: Exception) { err = e; emptyList() }
        if (a.isNotEmpty()) return a
        val b = try { searchWiki(q) } catch (e: Exception) { if (err == null) err = e; emptyList() }
        if (b.isEmpty() && err != null) throw err
        return b
    }

    private fun searchWiki(q: String): List<OlClub> {
        val j = OlNet.json("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=8&format=json&srsearch=${OlNet.enc("$q football club")}")
        val a = j.getJSONObject("query").getJSONArray("search")
        val out = ArrayList<OlClub>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val t = o.optString("title")
            if (t.isBlank() || !Regex("(?i)(f\\.?c\\.?|a\\.?f\\.?c|football|calcio|club|united|city|town|real|sporting|athletic|\\b(sc|cf|fk|sk|ac|as)\\b)").containsMatchIn(t)) continue
            val snip = o.optString("snippet").replace(Regex("<[^>]*>"), "").replace("&quot;", "\"").replace("&amp;", "&")
            out.add(OlClub("wp:$t", t.replace(Regex(" (A\\.?F\\.?C\\.?|F\\.?C\\.?)$"), ""), "", "", "", "", "", "", "", snip.take(60), "", "", "", "", ""))
        }
        return out
    }

    private fun searchDb(q: String): List<OlClub> {
        val j = OlNet.json("https://www.thesportsdb.com/api/v1/json/$KEY/searchteams.php?t=${OlNet.enc(q)}")
        val arr = j.optJSONArray("teams") ?: return emptyList()
        val out = ArrayList<OlClub>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sport = o.t("strSport")
            if (sport.isNotEmpty() && !sport.equals("Soccer", true)) continue
            val alt = o.t("strAlternate").split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
            val short = o.t("strTeamShort").ifBlank { alt.firstOrNull { it.length <= 4 && it.uppercase() == it }.orEmpty() }
            val nick = alt.firstOrNull { it != short && !it.equals(o.t("strTeam"), true) && it.length > 4 }.orEmpty()
            out.add(
                OlClub(
                    id = o.t("idTeam"), name = o.t("strTeam"), short = short, nick = nick,
                    city = o.t("strLocation").substringBefore(',').trim(), country = o.t("strCountry"),
                    founded = o.t("intFormedYear").takeIf { it.length == 4 && it != "0000" }.orEmpty(),
                    stadium = o.t("strStadium"), cap = o.t("intStadiumCapacity").takeIf { it != "0" }.orEmpty(), league = o.t("strLeague"),
                    c1 = o.t("strColour1"), c2 = o.t("strColour2"),
                    badge = o.t("strBadge").ifBlank { o.t("strTeamBadge") }, desc = o.t("strDescriptionEN"), web = o.t("strWebsite"),
                ),
            )
        }
        return out
    }

    /** Wikipedia text plus Wikidata facts for a club. Every step is allowed to fail on its own. */
    fun extra(c: OlClub): OlClubExtra {
        var about = ""; var mgr = ""; var chair = ""; var founded = ""; var thumb = ""
        val title = if (c.id.startsWith("wp:")) c.id.removePrefix("wp:") else runCatching {
            val j = OlNet.json("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=3&format=json&srsearch=${OlNet.enc(c.name + " football club")}")
            val a = j.getJSONObject("query").getJSONArray("search")
            (0 until a.length()).map { a.getJSONObject(it).getString("title") }
                .firstOrNull { t -> c.name.split(' ').first().let { w -> t.contains(w, true) } } ?: a.getJSONObject(0).getString("title")
        }.getOrNull()
        if (title != null) {
            runCatching {
                val s = OlNet.json("https://en.wikipedia.org/api/rest_v1/page/summary/${OlNet.enc(title.replace(' ', '_')).replace("+", "%20")}")
                about = s.t("extract")
                thumb = s.optJSONObject("thumbnail")?.optString("source").orEmpty()
            }
            runCatching {
                val pp = OlNet.json("https://en.wikipedia.org/w/api.php?action=query&prop=pageprops&ppprop=wikibase_item&format=json&titles=${OlNet.enc(title)}")
                val pages = pp.getJSONObject("query").getJSONObject("pages")
                val qid = pages.getJSONObject(pages.keys().next()).getJSONObject("pageprops").getString("wikibase_item")
                val ent = OlNet.json("https://www.wikidata.org/wiki/Special:EntityData/$qid.json").getJSONObject("entities").getJSONObject(qid).getJSONObject("claims")
                fun ids(p: String): List<String> {
                    val a = ent.optJSONArray(p) ?: return emptyList()
                    val r = ArrayList<String>()
                    for (i in 0 until a.length()) {
                        val st = a.getJSONObject(i)
                        if (st.optJSONObject("qualifiers")?.has("P582") == true) continue   // has an end date: not current
                        val v = st.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value") ?: continue
                        v.optString("id").takeIf { it.isNotEmpty() }?.let { r.add(it) }
                    }
                    return r
                }
                val m = ids("P286").lastOrNull(); val ch = ids("P488").lastOrNull()
                val want = listOfNotNull(m, ch)
                if (want.isNotEmpty()) {
                    val labels = OlNet.json("https://www.wikidata.org/w/api.php?action=wbgetentities&props=labels&languages=en&format=json&ids=${want.joinToString("|")}").getJSONObject("entities")
                    fun label(id: String?) = id?.let { labels.optJSONObject(it)?.optJSONObject("labels")?.optJSONObject("en")?.optString("value") }.orEmpty()
                    mgr = label(m); chair = label(ch)
                }
                ent.optJSONArray("P571")?.optJSONObject(0)?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.optString("time")
                    ?.let { Regex("""\+?(\d{4})""").find(it)?.groupValues?.get(1) }?.let { founded = it }
            }
        }
        return OlClubExtra(about, mgr, chair, founded, thumb)
    }

    /** The most common saturated colour of the crest, for clubs whose colours the database doesn't know. */
    fun crestColors(b: Bitmap): List<String> {
        val s = Bitmap.createScaledBitmap(b, 48, 48, true)
        val tally = HashMap<Int, Float>()
        val hsv = FloatArray(3)
        for (y in 0 until 48) for (x in 0 until 48) {
            val p = s.getPixel(x, y)
            if (android.graphics.Color.alpha(p) < 200) continue
            android.graphics.Color.colorToHSV(p, hsv)
            if (hsv[1] < .35f || hsv[2] < .25f) continue
            val key = ((hsv[0] / 24f).toInt() shl 8) or ((hsv[1] * 3).toInt() shl 4) or (hsv[2] * 3).toInt()
            tally[key] = (tally[key] ?: 0f) + hsv[1] * hsv[2]
        }
        return tally.entries.sortedByDescending { it.value }.take(2).map { e ->
            val h = (e.key shr 8) * 24f + 12f
            val c = android.graphics.Color.HSVToColor(floatArrayOf(h, ((e.key shr 4) and 15) / 3f + .17f, (e.key and 15) / 3f + .17f).also { it[1] = it[1].coerceAtMost(1f); it[2] = it[2].coerceAtMost(1f) })
            String.format("#%06x", c and 0xFFFFFF)
        }
    }
}

private fun cleanHex(s: String): String {
    val t = s.trim().let { if (it.startsWith("#")) it else "#$it" }
    return if (Regex("^#[0-9a-fA-F]{6}$").matches(t)) t.lowercase() else ""
}

/** A short About text: whole sentences, at most about 700 characters. */
private fun trimAbout(s: String, max: Int = 700): String {
    val t = s.replace(Regex("\\s+\\n"), "\n").trim()
    if (t.length <= max) return t
    val cut = t.take(max)
    val end = cut.lastIndexOf(". ")
    return if (end > 200) cut.take(end + 1) else cut.trimEnd() + "..."
}

/** Button for the club form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun ClubLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a club name, pick it, and details, crest, colours and an About text are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) ClubLookupSheet(d) { open = false }
}

@Composable
private fun ClubLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    val res = olLoad<List<OlClub>>(query to tick) { if (query.isBlank()) emptyList() else OlClubs.search(query) }

    fun apply(c: OlClub) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val (extra, bmp) = withContext(Dispatchers.IO) {
                val e = runCatching { OlClubs.extra(c) }.getOrDefault(OlClubExtra("", "", "", ""))
                val url = c.badge.ifBlank { e.thumb }
                val b = if (url.isNotBlank()) OlImages.load(url, 512, useCache = false) else null
                e to b
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", c.name); put("short", c.short.take(4)); put("nick", c.nick); put("city", c.city)
            put("founded", c.founded.ifBlank { extra.founded }); put("stadium", c.stadium); put("cap", c.cap.filter { it.isDigit() })
            put("mgr", extra.mgr); put("chair", extra.chair)
            put("info", trimAbout(extra.about.ifBlank { c.desc }))
            var c1 = cleanHex(c.c1); var c2 = cleanHex(c.c2)
            if (bmp != null && (c1.isEmpty() || c2.isEmpty())) {
                val found = OlClubs.crestColors(bmp)
                if (c1.isEmpty()) c1 = found.getOrNull(0).orEmpty()
                if (c2.isEmpty()) c2 = found.getOrNull(1).orEmpty()
            }
            put("color", c1); put("c2", c2)
            if (bmp != null && (replace || d["logo"].isBlank())) {
                d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, bmp) }
            } else if (bmp == null && (c.badge.isNotBlank())) note = "Filled in, but the crest couldn't be downloaded."
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("Club name", q, { q = it }, ph = "e.g. Liverpool")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a club name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the English name.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { c ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(c) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (c.badge.isNotBlank()) OlThumb(c.badge, Modifier.size(46.dp))
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(c.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(listOf(c.league, c.country).filter { it.isNotBlank() }.joinToString(" · "), 12 * u.fs, 500, u.mu, maxLines = 1)
                                }
                                if (c.founded.isNotBlank()) Tx(c.founded, 12 * u.fs, 600, u.mu)
                            }
                        }
                    }
                }
            }
        }
    }
}
