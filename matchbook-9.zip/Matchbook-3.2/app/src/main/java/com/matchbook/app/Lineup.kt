package com.matchbook.app

import androidx.compose.foundation.*
import android.graphics.BitmapFactory
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

// =============================================================== formations (ported from the lineup builder mockup)
private val FM = linkedMapOf(
    "4-4-2" to listOf(4, 4, 2), "4-3-3" to listOf(4, 3, 3), "4-2-3-1" to listOf(4, 2, 3, 1), "4-1-4-1" to listOf(4, 1, 4, 1),
    "4-4-1-1" to listOf(4, 4, 1, 1), "4-3-2-1" to listOf(4, 3, 2, 1), "4-5-1" to listOf(4, 5, 1), "4-2-2-2" to listOf(4, 2, 2, 2),
    "4-1-2-1-2" to listOf(4, 1, 2, 1, 2), "3-5-2" to listOf(3, 5, 2), "3-4-3" to listOf(3, 4, 3), "3-4-2-1" to listOf(3, 4, 2, 1),
    "3-4-1-2" to listOf(3, 4, 1, 2), "5-3-2" to listOf(5, 3, 2), "5-4-1" to listOf(5, 4, 1), "5-2-3" to listOf(5, 2, 3),
)
val FORMATIONS: List<String> = FM.keys.toList()
private val SPREAD = mapOf(1 to 0f, 2 to 34f, 3 to 56f, 4 to 72f, 5 to 82f)
private fun mentShift(m: String) = when (m) { "D" -> 7f; "A" -> -7f; else -> 0f }
private fun widthScale(w: String) = when (w) { "N" -> .8f; "W" -> 1.15f; else -> 1f }

class PSlot(val x: Float, val y: Float, val role: String)

private fun roleLabels(r: List<Int>, i: Int): List<String> {
    val c = r[i]; val n = r.size; val k = n - 1 - i
    if (i == 0) return when (c) { 3 -> listOf("CB", "CB", "CB"); 4 -> listOf("LB", "CB", "CB", "RB"); else -> listOf("LWB", "CB", "CB", "CB", "RWB") }
    if (k == 0) return when (c) { 1 -> listOf("ST"); 2 -> listOf("ST", "ST"); else -> listOf("LW", "ST", "RW") }
    if (c == 1) return listOf(if (k == 1) "CAM" else "CDM")
    if (c == 2) return if (k == 1 && n >= 4) listOf("CAM", "CAM") else if (i == 1 && n >= 4) listOf("CDM", "CDM") else listOf("CM", "CM")
    if (c == 3) return if (k == 1 && r[n - 1] == 1) listOf("LW", "CAM", "RW") else listOf("CM", "CM", "CM")
    return if (c == 4) listOf("LM", "CM", "CM", "RM") else listOf("LM", "CM", "CM", "CM", "RM")
}

fun baseSlots(fm: String): List<PSlot> {
    val r = FM[fm] ?: FM.getValue("4-3-3")
    val n = r.size
    val out = ArrayList<PSlot>()
    out.add(PSlot(50f, 91f, "GK"))
    r.forEachIndexed { i, c ->
        val y = 76f - i * (60f / (n - 1))
        val sp = SPREAD[c] ?: 0f
        val labels = roleLabels(r, i)
        for (j in 0 until c) out.add(PSlot(if (c == 1) 50f else 50f - sp / 2f + j * sp / (c - 1), y, labels[j]))
    }
    return out
}

fun lineupSlots(l: Lineup): List<PSlot> {
    val base = baseSlots(l.fm)
    return if (l.px.size == 11 && l.py.size == 11) base.mapIndexed { i, s -> PSlot(l.px[i], l.py[i], s.role) } else base
}

private fun disp(s: PSlot, l: Lineup): Pair<Float, Float> {
    val x = (50f + (s.x - 50f) * widthScale(l.wd)).coerceIn(10f, 90f)
    val y = if (s.role == "GK") s.y else (s.y + mentShift(l.mn)).coerceIn(9f, 93f)
    return x to y
}

private fun roleGroup(role: String) = when (role) {
    "GK" -> "GK"; "LB", "RB", "CB", "LWB", "RWB" -> "DEF"; "CDM", "CM", "CAM", "LM", "RM" -> "MID"; else -> "FWD"
}

private fun slotOf(l: Lineup, key: String): LineSlot = if (key.startsWith("p")) l.xi[key.drop(1).toInt()] else l.bench[key.drop(1).toInt()]

private fun withSlot(l: Lineup, key: String, s: LineSlot): Lineup {
    val i = key.drop(1).toInt()
    return if (key.startsWith("p")) l.copy(xi = l.xi.mapIndexed { n, o -> if (n == i) s else o })
    else l.copy(bench = l.bench.mapIndexed { n, o -> if (n == i) s else o })
}

private fun swapSlots(l: Lineup, a: String, b: String): Lineup {
    val sa = slotOf(l, a); val sb = slotOf(l, b)
    return withSlot(withSlot(l, a, sb), b, sa)
}

private fun fromPlayer(p: Player) = LineSlot(p.id, p.name, if (p.num > 0) p.num.toString() else "", p.img)

private fun autoFill(vm: AppVM, l: Lineup): Lineup {
    val squad = vm.playersOf(l.cid)
    val used = HashSet<String>()
    val slots = lineupSlots(l)
    val xi = slots.mapIndexed { i, s ->
        val g = roleGroup(s.role)
        val p = squad.firstOrNull { it.id !in used && it.pos == g } ?: squad.firstOrNull { it.id !in used }
        if (p != null) { used.add(p.id); fromPlayer(p) } else LineSlot(num = (i + 1).toString())
    }
    val bench = List(7) { i ->
        val p = squad.firstOrNull { it.id !in used }
        if (p != null) { used.add(p.id); fromPlayer(p) } else LineSlot(num = (i + 12).toString())
    }
    return l.copy(xi = xi, bench = bench)
}

private fun styleSummary(l: Lineup): String {
    val tempo = when (l.tempo) { "S" -> "Slow tempo"; "F" -> "Fast tempo"; else -> "Normal tempo" }
    val press = when (l.press) { "L" -> "Low press"; "H" -> "High press"; else -> "Mid press" }
    val line = when (l.line) { "D" -> "Deep line"; "H" -> "High line"; else -> "Normal line" }
    val ment = when (l.mn) { "D" -> "Defensive"; "A" -> "Attacking"; else -> "Balanced" }
    return "$ment · $tempo · $press · $line"
}

private val RunColor = Color.White
private val PassColor = Color(0xFFFFE066)
private val PressColor = Color(0xFFF46C4E)

private fun DrawScope.drawArrow(from: Offset, to: Offset, color: Color, dashed: Boolean, width: Float) {
    drawLine(color, from, to, strokeWidth = width, cap = StrokeCap.Round, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(18f, 12f)) else null)
    val ang = atan2(to.y - from.y, to.x - from.x)
    val len = 16.dp.toPx()
    for (da in listOf(Math.PI.toFloat() + .5f, Math.PI.toFloat() - .5f)) {
        val a = ang + da
        drawLine(color, to, Offset(to.x + len * cos(a), to.y + len * sin(a)), strokeWidth = width, cap = StrokeCap.Round)
    }
}

private fun arrowColor(kind: String) = when (kind) { "pass" -> PassColor; "press" -> PressColor; else -> RunColor }

// =============================================================== images
/** Small copies of the renders, kept in memory: the 2048 px originals are far too big to draw eleven times per frame. */
private object TokenImages {
    private val cache = android.util.LruCache<String, ImageBitmap>(40)
    fun peek(path: String): ImageBitmap? = cache.get(path)
    fun load(path: String, target: Int = 360): ImageBitmap? {
        cache.get(path)?.let { return it }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching { BitmapFactory.decodeFile(path, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
        val bmp = runCatching { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) }.getOrNull()
            ?.asImageBitmap() ?: return null
        cache.put(path, bmp)
        return bmp
    }
}

/** null while loading, false when there is nothing to show, otherwise the (small) picture. */
@Composable
private fun rememberTokenImage(path: String): Any? {
    if (path.isBlank()) return false
    val st = produceState<Any?>(TokenImages.peek(path), path) {
        value = TokenImages.peek(path) ?: withContext(Dispatchers.IO) { TokenImages.load(path) } ?: false
    }
    return st.value
}

// =============================================================== tokens
private val TokenW = 84.dp
private val AnchorX = 42.dp   // the point of a token that sits on its pitch position, measured from its top-left
private val AnchorY = 30.dp

/** How a player looks on the pitch or bench. No gestures here: the board handles touches for every token at once. */
@Composable
private fun TokenView(
    slot: LineSlot, role: String, gk: Boolean, selected: Boolean, duty: String, kit: Color, modifier: Modifier = Modifier, lifted: Boolean = true,
) {
    val u = LocalU.current
    val label = slot.name.ifBlank { role }
    val shirt = if (gk) Color(0xFFF6C945) else kit
    // With a render the token is just the player (no circle), like a team-sheet graphic. No render, or one that can't be read: numbered circle.
    val loaded = rememberTokenImage(slot.img)
    val bmp = loaded as? ImageBitmap
    val render = slot.img.isNotBlank() && loaded != false
    Column(
        modifier.width(TokenW).then(if (render && lifted) Modifier.offset(y = (-15).dp) else Modifier),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (render) {
            Box(Modifier.width(TokenW).height(94.dp)) {
                Box(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().height(84.dp)
                        .then(if (selected) Modifier.clip(RoundedCornerShape(18.dp)).background(u.acc.copy(alpha = .30f)) else Modifier),
                ) {
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, alignment = Alignment.BottomCenter)
                }
                TokenLabel(label, selected, Modifier.align(Alignment.BottomCenter))
                if (duty.isNotEmpty()) DutyBadge(duty, Modifier.align(Alignment.TopEnd).padding(end = 4.dp))
            }
        } else {
            Box(contentAlignment = Alignment.Center) {
                if (selected) Box(Modifier.size(66.dp).clip(CircleShape).background(u.acc.copy(alpha = .28f)))
                Box(
                    Modifier.size(54.dp).shadow(5.dp, CircleShape).clip(CircleShape).background(shirt)
                        .border(if (selected) 3.dp else 2.5.dp, if (selected) u.acc else Color.White, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Tx(slot.num, 18f, 800, inkOn(shirt), maxLines = 1) }
                if (duty.isNotEmpty()) DutyBadge(duty, Modifier.align(Alignment.TopEnd))
            }
            Spacer(Modifier.height(4.dp))
            TokenLabel(label, false, Modifier)
        }
    }
}

@Composable
private fun TokenLabel(label: String, ring: Boolean, modifier: Modifier) {
    val u = LocalU.current
    Box(
        modifier.shadow(3.dp, CircleShape).clip(CircleShape).background(Color.White)
            .then(if (ring) Modifier.border(2.dp, u.acc, CircleShape) else Modifier)
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) { Tx(label, 11f, 700, Color(0xFF1B1B1B), maxLines = 1, modifier = Modifier.widthIn(max = 70.dp)) }
}

@Composable
private fun DutyBadge(duty: String, modifier: Modifier) {
    Box(
        modifier.size(20.dp).clip(CircleShape).background(PressColor).border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Tx(duty, 10f, 800, Color.White) }
}

// =============================================================== the pitch
private fun DrawScope.drawPitch() {
    val w = size.width; val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF34A85F), Color(0xFF278A4A))))
    for (i in 0 until 10 step 2) drawRect(Color.White.copy(alpha = .05f), Offset(0f, h / 10f * i), Size(w, h / 10f))
    val line = Color.White.copy(alpha = .85f)
    val sw = 2.dp.toPx(); val inset = 10.dp.toPx()
    drawRect(line, Offset(inset, inset), Size(w - 2 * inset, h - 2 * inset), style = Stroke(sw))
    drawLine(line, Offset(inset, h / 2f), Offset(w - inset, h / 2f), strokeWidth = sw)
    drawCircle(line, w * .12f, Offset(w / 2f, h / 2f), style = Stroke(sw))
    drawCircle(line, 3.dp.toPx(), Offset(w / 2f, h / 2f))
    val bw = w * .5f; val bh = h * .15f
    val gw = w * .24f; val gh = h * .06f
    // boxes, six-yard boxes, penalty spots and the arcs outside the boxes
    for (top in listOf(true, false)) {
        val by = if (top) inset else h - inset - bh
        val gy = if (top) inset else h - inset - gh
        drawRect(line, Offset((w - bw) / 2f, by), Size(bw, bh), style = Stroke(sw))
        drawRect(line, Offset((w - gw) / 2f, gy), Size(gw, gh), style = Stroke(sw))
        val spotY = if (top) inset + bh * .72f else h - inset - bh * .72f
        drawCircle(line, 2.5.dp.toPx(), Offset(w / 2f, spotY))
        val r = w * .095f
        drawArc(line, if (top) 37f else 217f, 106f, false, Offset(w / 2f - r, spotY - r), Size(2 * r, 2 * r), style = Stroke(sw))
    }
    val cr = 8.dp.toPx()
    drawArc(line, 0f, 90f, false, Offset(inset - cr, inset - cr), Size(2 * cr, 2 * cr), style = Stroke(sw))
    drawArc(line, 90f, 90f, false, Offset(w - inset - cr, inset - cr), Size(2 * cr, 2 * cr), style = Stroke(sw))
    drawArc(line, 270f, 90f, false, Offset(inset - cr, h - inset - cr), Size(2 * cr, 2 * cr), style = Stroke(sw))
    drawArc(line, 180f, 90f, false, Offset(w - inset - cr, h - inset - cr), Size(2 * cr, 2 * cr), style = Stroke(sw))
    drawRect(Color.Black.copy(alpha = .12f), Offset.Zero, size, style = Stroke(3.dp.toPx()))
}

/** Where a token is touched, dragged and dropped. Everything the finger moves is read in the layout / draw phase, so a drag does not recompose anything. */
private class DragState {
    var key by mutableStateOf<String?>(null)
    var pos by mutableStateOf(Offset.Zero)        // finger, in board coordinates
    var grab by mutableStateOf(Offset.Zero)       // finger minus the token's anchor, kept constant while dragging
    var over by mutableStateOf<String?>(null)     // token under the finger that a drop would swap with
}

@Composable
private fun Board(vm: AppVM, c: Club, l: Lineup, slots: List<PSlot>, tactics: Boolean, sel: String) {
    val u = LocalU.current
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val kit = remember(c.color) { hex(c.color) }
    val ds = remember { DragState() }
    val coords = remember { HashMap<String, LayoutCoordinates>() }
    val board = remember { arrayOfNulls<LayoutCoordinates>(1) }
    var live by remember { mutableStateOf<Pair<Offset, Offset>?>(null) }     // arrow being drawn, in pitch coordinates
    val lineup by rememberUpdatedState(l)
    val slotsNow by rememberUpdatedState(slots)
    val tacticsNow by rememberUpdatedState(tactics)
    val kindNow by rememberUpdatedState(vm.arrowKind)
    val anchorX = with(density) { AnchorX.toPx() }
    val anchorY = with(density) { AnchorY.toPx() }
    val nearR = with(density) { 40.dp.toPx() }

    fun rectOf(k: String): Rect? {
        val b = board[0] ?: return null
        val lc = coords[k] ?: return null
        return if (lc.isAttached && b.isAttached) b.localBoundingBoxOf(lc, false) else null
    }
    /** The token touched at [p] (the whole token counts). */
    fun hit(p: Offset): String? {
        var best: String? = null; var bd = Float.MAX_VALUE
        for (k in coords.keys) {
            if (k == "pitch") continue
            val r = rectOf(k) ?: continue
            if (r.contains(p)) { val d = (Offset(r.left + anchorX, r.top + anchorY) - p).getDistance(); if (d < bd) { bd = d; best = k } }
        }
        return best
    }
    /** The token a drop at [p] would swap with: the finger has to be close to its middle, so placing a player beside another one just moves him. */
    fun swapTarget(p: Offset, self: String): String? {
        var best: String? = null; var bd = nearR
        for (k in coords.keys) {
            if (k == "pitch" || k == self) continue
            val r = rectOf(k) ?: continue
            val d = (Offset(r.left + anchorX, r.top + anchorY) - p).getDistance()
            if (d < bd) { bd = d; best = k }
        }
        return best
    }
    fun select(k: String) { vm.lineupSel = k }

    Box(Modifier.fillMaxWidth()) {
    Column(
        Modifier.fillMaxWidth()
            .onGloballyPositioned { board[0] = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val k = hit(down.position)
                    val pr = rectOf("pitch")
                    if (tacticsNow) {
                        // tactics: a drag on the pitch draws an arrow; a tap picks a player
                        if (pr == null || !pr.contains(down.position)) {
                            if (k != null) { val up = waitForUpOrCancellation(); if (up != null) select(k) }
                            return@awaitEachGesture
                        }
                        val slop = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                        if (slop == null) {
                            if (currentEvent.changes.none { it.pressed }) select(k ?: "")
                            return@awaitEachGesture
                        }
                        val from = down.position - pr.topLeft
                        live = from to from
                        drag(slop.id) { change -> change.consume(); live = from to (change.position - pr.topLeft) }
                        val a = live
                        if (a != null && (a.second - a.first).getDistance() > 24f) {
                            val w = pr.width; val h = pr.height
                            val arrow = Arrow(a.first.x / w * 100f, a.first.y / h * 100f, a.second.x / w * 100f, a.second.y / h * 100f, kindNow)
                            vm.editLineup(l.cid) { it.copy(arrows = it.arrows + arrow) }
                        }
                        live = null
                        return@awaitEachGesture
                    }
                    if (k == null) {
                        // empty ground: a tap clears the selection, a scroll is left to the page
                        val up = waitForUpOrCancellation()
                        if (up != null) select("")
                        return@awaitEachGesture
                    }
                    val slop = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                    if (slop == null) {
                        if (currentEvent.changes.none { it.pressed }) select(k)
                        return@awaitEachGesture
                    }
                    // ---- a player is picked up
                    val rect = rectOf(k) ?: return@awaitEachGesture
                    val onPitch = k.startsWith("p")
                    val idx = k.drop(1).toInt()
                    val anchor0 = if (onPitch && pr != null) {
                        val (dx, dy) = disp(slotsNow[idx], lineup)
                        Offset(pr.left + pr.width * dx / 100f, pr.top + pr.height * dy / 100f)
                    } else Offset(rect.left + anchorX, rect.top + anchorY)
                    select(k)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    ds.grab = slop.position - anchor0
                    ds.pos = slop.position
                    ds.over = null
                    ds.key = k
                    val finished = drag(slop.id) { change ->
                        change.consume()
                        ds.pos = change.position
                        val t = swapTarget(change.position, k)
                        if (t != ds.over) { ds.over = t; if (t != null) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                    }
                    val target = if (finished) swapTarget(ds.pos, k) else null
                    if (finished) {
                        if (target != null) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            vm.editLineup(l.cid) { swapSlots(it, k, target) }
                        } else if (onPitch && pr != null) {
                            // free placement: the token's anchor is where the player now stands
                            val a = ds.pos - ds.grab
                            val fx = ((a.x - pr.left) / pr.width * 100f).coerceIn(10f, 90f)
                            val fy = ((a.y - pr.top) / pr.height * 100f).coerceIn(9f, 93f)
                            val cur = lineup
                            val s = slotsNow[idx]
                            val xs = 50f + (fx - 50f) / widthScale(cur.wd)
                            val ys = if (s.role == "GK") fy else fy - mentShift(cur.mn)
                            val nx = slotsNow.mapIndexed { n, o -> if (n == idx) xs else o.x }
                            val ny = slotsNow.mapIndexed { n, o -> if (n == idx) ys else o.y }
                            vm.editLineup(l.cid) { it.copy(px = nx, py = ny) }
                        }
                    }
                    ds.key = null
                    ds.over = null
                }
            },
    ) {
        // ---- pitch
        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(.74f).shadow(10.dp, RoundedCornerShape(minOf(u.r, 28.dp))).clip(RoundedCornerShape(minOf(u.r, 28.dp)))
                .onGloballyPositioned { coords["pitch"] = it },
        ) {
            val wPx = constraints.maxWidth.toFloat()
            val hPx = constraints.maxHeight.toFloat()
            Canvas(Modifier.fillMaxSize()) {
                drawPitch()
                val w = size.width; val h = size.height
                l.arrows.forEach { a ->
                    drawArrow(Offset(a.x1 / 100f * w, a.y1 / 100f * h), Offset(a.x2 / 100f * w, a.y2 / 100f * h), arrowColor(a.kind), a.kind == "run", if (a.kind == "press") 4.dp.toPx() else 3.dp.toPx())
                }
                live?.let { (a, b) -> drawArrow(a, b, arrowColor(kindNow), kindNow == "run", 3.dp.toPx()) }
            }
            slots.forEachIndexed { i, s ->
                val (dx, dy) = disp(s, l)
                val key = "p$i"
                Box(
                    Modifier.offset { IntOffset((wPx * dx / 100f - anchorX).roundToInt(), (hPx * dy / 100f - anchorY).roundToInt()) }
                        .onGloballyPositioned { coords[key] = it }
                        .graphicsLayer {
                            alpha = if (ds.key == key) 0f else 1f
                            val big = if (ds.over == key) 1.14f else 1f
                            scaleX = big; scaleY = big
                        },
                ) { TokenView(l.xi[i], s.role, s.role == "GK", sel == key, l.duty[i], kit) }
            }
        }

        // ---- bench
        H3("Bench")
        Glass(Modifier.fillMaxWidth(), pad = PaddingValues(horizontal = 6.dp, vertical = 12.dp)) {
            l.bench.chunked(4).forEachIndexed { row, group ->
                Row(Modifier.fillMaxWidth().padding(bottom = if (row == 0) 8.dp else 0.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    group.forEachIndexed { j, s ->
                        val idx = row * 4 + j
                        val key = "b$idx"
                        Box(
                            Modifier.onGloballyPositioned { coords[key] = it }
                                .graphicsLayer {
                                    alpha = if (ds.key == key) .3f else 1f
                                    val big = if (ds.over == key) 1.14f else 1f
                                    scaleX = big; scaleY = big
                                },
                        ) { TokenView(s, "Sub ${idx + 1}", false, sel == key, "", kit, lifted = false) }
                    }
                    repeat(4 - group.size) { Spacer(Modifier.width(TokenW)) }
                }
            }
        }
        Tx(
            if (tactics) "Drag on the pitch to draw an arrow. Tap a player to give a duty."
            else "Drag a player anywhere on the pitch. Drop him on another to swap, bench included.",
            12 * u.fs, 500, u.mu, Modifier.padding(start = 6.dp, top = 10.dp),
        )
    }

    // ---- the player in the finger (drawn above everything, positioned in the layout phase)
    val k = ds.key
    if (k != null) {
        val ghostSlot = slotOf(l, k)
        val onPitch = k.startsWith("p")
        val role = if (onPitch) slots[k.drop(1).toInt()].role else "Sub ${k.drop(1).toInt() + 1}"
        Box(
            Modifier.offset {
                var a = ds.pos - ds.grab
                if (onPitch) rectOf("pitch")?.let { pr ->
                    a = Offset(a.x.coerceIn(pr.left + pr.width * .10f, pr.left + pr.width * .90f), a.y.coerceIn(pr.top + pr.height * .09f, pr.top + pr.height * .93f))
                }
                IntOffset((a.x - anchorX).roundToInt(), (a.y - anchorY).roundToInt())
            }.zIndex(5f).graphicsLayer { scaleX = 1.12f; scaleY = 1.12f; alpha = .96f },
        ) { TokenView(ghostSlot, role, onPitch && slots[k.drop(1).toInt()].role == "GK", true, if (onPitch) l.duty[k.drop(1).toInt()] else "", kit, lifted = onPitch) }
    }
    }
}

// =============================================================== the page
@Composable
fun LineupPage(vm: AppVM, cid: String) {
    val u = LocalU.current
    val c = vm.cl(cid) ?: return
    val l = vm.lineupOf(cid)
    val tactics = vm.lineupTactics
    val slots = lineupSlots(l)
    val squad = vm.playersOf(cid)
    val sel = vm.lineupSel

    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)

    TopRow(vm.backLabel, { vm.goBack() }) { CircleBtn("users", { vm.openSquad(cid) }) }
    Tp(if (tactics) "Tactics" else "Lineup", c.name)
    HChips(FORMATIONS.map { it to it }, l.fm) { f -> edit { it.copy(fm = f, px = emptyList(), py = emptyList()) } }

    Column(Modifier.bd(top = 14.dp)) {
        SegRow(listOf("L" to "Lineup", "T" to "Tactics"), if (tactics) "T" else "L") { vm.lineupTactics = it == "T"; vm.lineupSel = "" }
        Spacer(Modifier.height(10.dp))
        Lbl("Mentality")
        SegRow(listOf("D" to "Defensive", "B" to "Balanced", "A" to "Attacking"), l.mn) { m -> edit { it.copy(mn = m) } }
        Lbl("Width")
        SegRow(listOf("N" to "Narrow", "M" to "Normal", "W" to "Wide"), l.wd) { w -> edit { it.copy(wd = w) } }
        Spacer(Modifier.height(16.dp))

        Board(vm, c, l, slots, tactics, sel)

        // ---- editor for the selected player
        Spacer(Modifier.height(6.dp))
        val validSel = sel.length > 1 && (sel.startsWith("p") || sel.startsWith("b")) && sel.drop(1).toIntOrNull() != null
        Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
            if (!validSel) {
                Tx(
                    if (tactics) "Drag on the pitch to draw an arrow (from a player to show a run). Tap a player to give them a duty."
                    else "Tap a player to rename them or pick one from the squad. Drag players to position them. Drop one on another to swap, bench included.",
                    13 * u.fs, 500, u.mu, lh = 13 * u.fs * 1.5f,
                )
            } else {
                val slot = slotOf(l, sel)
                val isPitch = sel.startsWith("p")
                val idx = sel.drop(1).toInt()
                val d = remember(sel, slot.img) { Draft(null, mapOf("img" to slot.img)) }
                val img = d["img"]
                LaunchedEffect(img) { if (img != slot.img) edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(img = img)) } }
                Tx(if (isPitch) "Starter · ${slots[idx].role}" else "Bench · Sub ${idx + 1}", 15 * u.fs, 800)
                if (tactics && isPitch) {
                    Lbl("Duty")
                    SegRow(listOf("" to "None", "A" to "Attack", "S" to "Support", "D" to "Defend"), l.duty[idx]) { v ->
                        edit { it.copy(duty = it.duty.mapIndexed { n, o -> if (n == idx) v else o }) }
                    }
                } else {
                    FRow {
                        Fld("Name", slot.name, { v -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(name = v, pid = "")) } }, Modifier.weight(1.6f), ph = "Player name")
                        Fld("No.", slot.num, { v -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(num = v)) } }, Modifier.weight(1f), number = true)
                    }
                    if (squad.isNotEmpty()) DropSelect(
                        "Pick from squad", "", squad.map { it.id to (if (it.num > 0) "${it.num}  ${it.name}" else it.name) },
                        { pid -> squad.find { it.id == pid }?.let { p -> edit { cur -> withSlot(cur, sel, fromPlayer(p)) } } },
                    )
                    OnlineLookup(
                        slot.name,
                        { n, _ -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(name = n, pid = "")) } },
                        { d["img"] = it },
                    )
                    Upload("Render", d, "img")
                    val others = (l.xi.indices.map { "p$it" } + l.bench.indices.map { "b$it" }).filter { it != sel }
                    DropSelect(
                        "Swap with", "", others.map { k -> k to (slotOf(l, k).name.ifBlank { if (k.startsWith("p")) slots[k.drop(1).toInt()].role else "Sub ${k.drop(1).toInt() + 1}" }) },
                        { k -> edit { swapSlots(it, sel, k) } },
                    )
                    Spacer(Modifier.height(10.dp))
                    Btn("Clear player", "red", 0.dp, 0.dp) {
                        val fresh = LineSlot(num = (if (isPitch) idx + 1 else idx + 12).toString())
                        edit { cur -> withSlot(cur, sel, fresh) }
                    }
                }
            }
        }

        // ---- tactics tools
        if (tactics) {
            Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                Tx("Arrows", 15 * u.fs, 800)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("run" to "Run", "pass" to "Pass", "press" to "Press").forEach { (k, t) -> Chip(t, vm.arrowKind == k) { vm.arrowKind = k } }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Undo", false) { edit { it.copy(arrows = it.arrows.dropLast(1)) } }
                    Chip("Clear arrows", false) { edit { it.copy(arrows = emptyList()) } }
                }
            }
            Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                Tx("Team instructions", 15 * u.fs, 800)
                Lbl("Tempo")
                SegRow(listOf("S" to "Slow", "N" to "Normal", "F" to "Fast"), l.tempo) { v -> edit { it.copy(tempo = v) } }
                Lbl("Pressing")
                SegRow(listOf("L" to "Low", "M" to "Mid", "H" to "High"), l.press) { v -> edit { it.copy(press = v) } }
                Lbl("Defensive line")
                SegRow(listOf("D" to "Deep", "N" to "Normal", "H" to "High"), l.line) { v -> edit { it.copy(line = v) } }
                Tx(styleSummary(l), 13 * u.fs, 700, u.mu, Modifier.padding(top = 14.dp))
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassBtn("Auto-fill", "users", Modifier.weight(1f)) { edit { autoFill(vm, it) } }
            GlassBtn("Reset", "swap", Modifier.weight(1f)) { vm.resetLineup(cid) }
        }
        Spacer(Modifier.height(120.dp))
    }
}
