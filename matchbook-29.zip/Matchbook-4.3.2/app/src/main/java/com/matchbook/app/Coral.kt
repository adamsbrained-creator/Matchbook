package com.matchbook.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Coral look (2.5): round white buttons, the "matchbook" wordmark, a black floating action button and a menu page.

@Composable
fun Wordmark() {
    val u = LocalU.current
    Tx("matchbook", 24f, 600, u.ink)
}

/** Top bar: a round button on each side and the wordmark in the middle. */
@Composable
fun CoralBar(left: @Composable () -> Unit, right: (@Composable () -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(48.dp)) { left() }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Wordmark() }
        Box(Modifier.width(48.dp), contentAlignment = Alignment.CenterEnd) { right?.invoke() }
    }
}

@Composable
fun CoralFab(label: String, icon: String, onClick: () -> Unit) {
    val u = LocalU.current
    Row(
        Modifier.height(56.dp)
            .shadow(12.dp, CircleShape, ambientColor = Color.Black.copy(alpha = .3f), spotColor = Color.Black.copy(alpha = .3f))
            .clip(CircleShape).background(u.pri).clickable(onClick = onClick).padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Ico(icon, 20.dp, u.onPri, 1.9f)
        Tx(label, 16 * u.fs, 500, u.onPri)
    }
}

/** The floating action button of the current Coral page (New club, Add club, ...). */
@Composable
fun CoralOverlay(vm: AppVM) {
    val sc = vm.screen
    val spec: Triple<String, String, () -> Unit>? = when {
        sc == null && vm.tab == "clubs" -> Triple("New club", "edit", { vm.newClub(vm.clubFilter.takeIf { it != "all" }) })
        sc == null && vm.tab == "leagues" -> Triple("New league", "edit", { vm.newLeague() })
        sc is Screen.LeagueS -> Triple("Add club", "plus", { vm.newClub(sc.id) })
        sc is Screen.SquadS -> Triple("Add player", "plus", { vm.newPlayer(sc.cid) })
        else -> null
    }
    if (spec != null) Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars).padding(end = 20.dp, bottom = 24.dp),
        contentAlignment = Alignment.BottomEnd,
    ) { CoralFab(spec.first, spec.second, spec.third) }
}

@Composable
private fun FilterText(label: String, onClick: () -> Unit) {
    val u = LocalU.current
    Row(
        Modifier.clip(CircleShape).clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Tx(label, 16 * u.fs, 500, u.mu, Modifier.widthIn(max = 160.dp), maxLines = 1)
        Ico("chevd", 18.dp, u.mu, 2f)
    }
}

/** Coral clubs page filter row: league menu, sort menu and a list / grid switch. */
@Composable
fun CoralClubFilter(vm: AppVM) {
    val u = LocalU.current
    var lOpen by remember { mutableStateOf(false) }
    var sOpen by remember { mutableStateOf(false) }
    val leagueName = if (vm.clubFilter == "all") "All leagues" else (vm.lg(vm.clubFilter)?.name ?: "All leagues")
    val sortName = when (vm.clubSort) { "pts" -> "Points"; "lg" -> "League"; else -> "A–Z" }
    val asList = u.s.cg == "list" || u.s.cg == "comp" || u.s.cg == "plain"
    val plainNow = u.s.cg == "plain" || u.s.cg == "gplain"
    fun layoutOf(list: Boolean, plain: Boolean) = when { list && plain -> "plain"; list -> "list"; plain -> "gplain"; else -> "g2" }
    var cOpen by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box {
            FilterText(leagueName) { lOpen = true }
            DropdownMenu(lOpen, { lOpen = false }) {
                DropdownMenuItem(text = { Text("All leagues") }, onClick = { vm.clubFilter = "all"; lOpen = false })
                vm.leagues.forEach { l -> DropdownMenuItem(text = { Text(l.name) }, onClick = { vm.clubFilter = l.id; lOpen = false }) }
            }
        }
        Box {
            FilterText(sortName) { sOpen = true }
            DropdownMenu(sOpen, { sOpen = false }) {
                listOf("az" to "A–Z", "pts" to "Points", "lg" to "League").forEach { (k, t) ->
                    DropdownMenuItem(text = { Text(t) }, onClick = { vm.clubSort = k; sOpen = false })
                }
            }
        }
        Box {
            FilterText(if (plainNow) "Plain" else "Cards") { cOpen = true }
            DropdownMenu(cOpen, { cOpen = false }) {
                listOf(false to "Cards", true to "Plain").forEach { (p, t) ->
                    DropdownMenuItem(text = { Text(t) }, onClick = { vm.update { it.copy(cg = layoutOf(asList, p)) }; cOpen = false })
                }
            }
        }
        Spacer(Modifier.weight(1f))
        listOf("list" to true, "grid" to false).forEach { (icon, isList) ->
            val on = asList == isList
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(if (on) u.sf else Color.Transparent)
                    .clickable { vm.update { it.copy(cg = layoutOf(isList, plainNow)) } },
                contentAlignment = Alignment.Center,
            ) { Ico(icon, 22.dp, if (on) u.ink else u.mu, 1.9f) }
        }
    }
}

/** Round "more" button that opens a small menu. */
@Composable
fun MoreMenu(items: List<Pair<String, () -> Unit>>) {
    var open by remember { mutableStateOf(false) }
    Box {
        CircleBtn("more", { open = true })
        DropdownMenu(open, { open = false }) {
            items.forEach { (t, f) -> DropdownMenuItem(text = { Text(t) }, onClick = { open = false; f() }) }
        }
    }
}

private class MenuRow(val icon: String, val label: String, val value: String, val tab: String?, val go: () -> Unit)

/** One rounded card of menu rows with hairlines between them, like Paperback's settings groups. */
@Composable
private fun MenuGroup(vm: AppVM, label: String?, rows: List<MenuRow>) {
    val u = LocalU.current
    if (label != null) Cap(label) else Spacer(Modifier.height(24.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(u.sf)) {
        rows.forEachIndexed { i, r ->
            val here = r.tab != null && vm.tab == r.tab
            Row(
                Modifier.fillMaxWidth().height(64.dp).clickable(onClick = r.go)
                    .then(if (i == 0) Modifier else Modifier.drawBehind {
                        drawLine(u.ln, Offset(70.dp.toPx(), 0f), Offset(size.width - 16.dp.toPx(), 0f), 1.dp.toPx())
                    })
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(u.fieldFill), contentAlignment = Alignment.Center) {
                    Ico(r.icon, 22.dp, u.ink, 1.9f)
                }
                Tx(r.label, 16 * u.fs, 500, modifier = Modifier.weight(1f), maxLines = 1)
                if (here) Box(Modifier.size(8.dp).clip(CircleShape).background(u.acc))
                if (r.value.isNotEmpty()) Tx(r.value, 14 * u.fs, 500, u.mu, maxLines = 1)
                Ico("chev", 18.dp, u.mu, 2f)
            }
        }
    }
}

/** Coral menu page: jump to any section. */
@Composable
fun MenuPage(vm: AppVM) {
    val u = LocalU.current
    CoralBar(
        left = { CircleBtn("close", { vm.goBack() }) },
        right = null,
    )
    Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 0.dp)) {
        Hd("Menu", 38f, maxLines = 1)
        Tx("Jump to any section", 14 * u.fs, 500, u.mu)
    }
    Column(Modifier.padding(horizontal = 20.dp)) {
        MenuGroup(vm, "Browse", listOf(
            MenuRow("home", "Home", "", "home") { vm.selectTab("home") },
            MenuRow("shield", "Clubs", "${vm.clubs.size}", "clubs") { vm.selectTab("clubs") },
            MenuRow("trophy", "Leagues", "${vm.leagues.size}", "leagues") { vm.selectTab("leagues") },
            MenuRow("cal", "Fixtures", "${vm.fixtures.size}", null) { vm.selectTab("clubs"); vm.openFixtures(null) },
            MenuRow("compare", "Compare", "", null) { vm.selectTab("clubs"); vm.openCompare() },
            MenuRow("globe", "World map", "", null) { vm.openWorld() },
            MenuRow("trophy", "Superleagues", "${vm.supers.size}", null) { vm.openSupers() },
        ))
        MenuGroup(vm, "Create and review", listOf(
            MenuRow("plus", "Add", "", "add") { vm.selectTab("add") },
            MenuRow("bars", "Stats", "", "stats") { vm.selectTab("stats") },
        ))
        MenuGroup(vm, null, listOf(MenuRow("gear", "Settings", "", null) { vm.openSettings() }))
        Tx("Matchbook ${vm.appVersion()}", 13 * u.fs, 500, u.mu, Modifier.fillMaxWidth().padding(top = 18.dp), align = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(40.dp))
    }
}

/** Short message pill at the bottom of the screen (Coral's replacement for the system toast). */
@Composable
fun CoralToast(text: String) {
    val u = LocalU.current
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars).padding(start = 20.dp, end = 20.dp, bottom = 100.dp),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Box(Modifier.shadow(12.dp, shape).clip(shape).background(u.ink).padding(horizontal = 20.dp, vertical = 14.dp)) {
            Tx(text, 14 * u.fs, 500, u.bg)
        }
    }
}
