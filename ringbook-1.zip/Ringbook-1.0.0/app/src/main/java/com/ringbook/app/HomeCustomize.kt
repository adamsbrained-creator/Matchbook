package com.ringbook.app

import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// =====================================================================================================
// Customize Home (3.9): choose which sections the Home page shows, put them in your order, add the ones
// that are off by default, and bring back clubs or countries that were hidden with a long press.
// =====================================================================================================

/** One section of the Home sheet: id, name, what it shows. The map on top is "map" and always comes first. */
class HomeSection(val id: String, val name: String, val about: String)

val HOME_SECTIONS = listOf(
    HomeSection("title", "Country title", "The name of the country with its numbers of promotions and wrestlers"),
    HomeSection("countries", "Country chips", "Switch between your countries"),
    HomeSection("leagues", "Promotion chips", "Switch between the promotions of the country"),
    HomeSection("clubs", "Wrestler strip", "The pictures of the country's wrestlers"),
    HomeSection("next", "Next match", "The next match of the country"),
    HomeSection("table", "Rankings", "The top of the rankings"),
    HomeSection("upcoming", "Upcoming matches", "The next four matches of the country"),
    HomeSection("quick", "Quick add", "Buttons to add a wrestler, a match or a promotion, and to open the world map"),
    HomeSection("stats", "Numbers", "Promotions, wrestlers, members and matches of the country"),
)

const val DEFAULT_HOME = "map,title,countries,leagues,clubs,next,table"

fun homeIds(s: String): List<String> = s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()

/** Hides an item from Home when it is shown, shows it again when it is hidden. [key] is "c:<wrestler id>" or "g:<country key>". */
fun AppVM.toggleHomeHide(key: String) = update { it.copy(homeHide = if (key in it.homeHide) it.homeHide - key else it.homeHide + key) }

private fun AppVM.hiddenLabel(key: String): String {
    val v = key.drop(2)
    return if (key.startsWith("c:")) (cl(v)?.name ?: "A wrestler")
    else flag(v.removePrefix("region:")) + (if (v.startsWith("region:")) (regions.find { it.id == v.removePrefix("region:") }?.name ?: v) else v)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeCustomizeDialog(vm: AppVM) {
    val u = LocalU.current
    val s = vm.settings
    val on = homeIds(s.home).filter { it == "map" || HOME_SECTIONS.any { x -> x.id == it } }
    fun save(list: List<String>) = vm.update { it.copy(home = list.joinToString(",")) }
    fun move(id: String, by: Int) {
        val l = on.toMutableList()
        val i = l.indexOf(id)
        val j = i + by
        // the map always stays first, so a section can never move above it
        if (i < 0 || j < 0 || j >= l.size || l[j] == "map") return
        l.removeAt(i); l.add(j, id); save(l)
    }
    fun flip(id: String) {
        if (id in on) save(on - id)
        else save(if (id == "map") listOf("map") + on else on + id)
    }
    // sections that are on come first, in your order, then the ones that are off
    val rows = on.filter { it != "map" }.mapNotNull { id -> HOME_SECTIONS.find { it.id == id } } +
        HOME_SECTIONS.filter { it.id !in on }

    val sheet = if (u.coral) u.menuBg else if (u.dark) Color(0xFF1B1D22) else Color(0xFFF7F7F5)
    val top = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
    Dialog(onDismissRequest = { vm.homeEdit = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        // draw under both system bars, so no black strip is left under the sheet
        val view = LocalView.current
        DisposableEffect(view) {
            val w = (view.parent as? DialogWindowProvider)?.window
            if (w != null) {
                WindowCompat.setDecorFitsSystemWindows(w, false)
                w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
                w.setBackgroundDrawableResource(android.R.color.transparent)
                w.navigationBarColor = android.graphics.Color.TRANSPARENT
                w.statusBarColor = android.graphics.Color.TRANSPARENT
                if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            }
            onDispose { }
        }
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.homeEdit = false },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier.fillMaxWidth().widthIn(max = 640.dp).fillMaxHeight(.9f)
                    .shadow(24.dp, top, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(top).background(sheet)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            ) {
                // grab handle and title
                Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(40.dp, 5.dp).clip(CircleShape).background(u.mu.copy(alpha = .35f)))
                }
                Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Hd("Customize Home", 26f)
                        Tx("Sections, order, spacing and depth", 13 * u.fs, 500, u.mu, Modifier.padding(top = 2.dp))
                    }
                    SmallBtn("Done") { vm.homeEdit = false }
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GroupLabel("Sections")
                    SectionRow("Map", "The dotted world map at the top", "map" in on, false, false, {}, {}) { flip("map") }
                    rows.forEach { sec ->
                        val isOn = sec.id in on
                        val sections = on.filter { it != "map" }
                        val idx = sections.indexOf(sec.id)
                        SectionRow(
                            sec.name, sec.about, isOn, isOn && idx > 0, isOn && idx in 0 until sections.size - 1,
                            { move(sec.id, -1) }, { move(sec.id, 1) },
                        ) { flip(sec.id) }
                    }

                    GroupLabel("Spacing")
                    Panel {
                        Tx("Space between sections", 14 * u.fs, 700)
                        Spacer(Modifier.height(8.dp))
                        SegRow(listOf("0" to "Tight", "1" to "Cozy", "2" to "Roomy", "3" to "Airy"), s.homeGap.toString()) { v -> vm.update { it.copy(homeGap = v.toInt()) } }
                        Tx("Rows in the rankings", 14 * u.fs, 700, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
                        SegRow(listOf("3", "4", "6", "8", "10").map { it to it }, s.homeRows.toString()) { v -> vm.update { it.copy(homeRows = v.toInt()) } }
                    }

                    GroupLabel("Depth")
                    Panel {
                        Tx("Cards on Home", 14 * u.fs, 700)
                        Spacer(Modifier.height(8.dp))
                        SegRow(listOf("F" to "Flat", "S" to "Soft", "R" to "Raised"), s.homeDepth) { v -> vm.update { it.copy(homeDepth = v) } }
                        Tx(
                            "Next match, the rankings and upcoming matches. Soft adds a light shadow, Raised lifts them off the page.",
                            12 * u.fs, 500, u.mu, Modifier.padding(top = 10.dp), lh = 12 * u.fs * 1.5f,
                        )
                        // a small live sample of the chosen depth
                        Box(Modifier.padding(top = 14.dp, bottom = 4.dp).fillMaxWidth().homeCard().padding(horizontal = 16.dp, vertical = 14.dp)) {
                            Tx("Sample card", 15 * u.fs, 700)
                        }
                    }

                    if (s.homeHide.isNotEmpty()) {
                        GroupLabel("Hidden on Home")
                        Panel {
                            Tx("Tap to show again", 12 * u.fs, 500, u.mu, Modifier.padding(bottom = 8.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                s.homeHide.sorted().forEach { k -> Chip(vm.hiddenLabel(k) + "  ×", false) { vm.toggleHomeHide(k) } }
                            }
                        }
                    }
                    Row(Modifier.padding(top = 6.dp)) {
                        SmallBtn("Reset", "s") { vm.update { it.copy(home = DEFAULT_HOME, homeRows = 4, homeGap = 1, homeDepth = "S", homeHide = emptySet()) } }
                    }
                    Spacer(Modifier.navigationBarsPadding().height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun GroupLabel(t: String) {
    val u = LocalU.current
    Tx(t.uppercase(), 11.5f * u.fs, 800, u.mu, Modifier.padding(start = 6.dp, top = 12.dp, bottom = 2.dp))
}

/** A raised panel that holds a group of controls. */
@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    val u = LocalU.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().shadow(5.dp, shape, ambientColor = Color.Black.copy(alpha = .35f), spotColor = Color.Black.copy(alpha = .35f))
            .clip(shape).background(if (u.dark) Color(0xFF24272D) else Color.White)
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (u.dark) .09f else .0f), Color.Transparent)), shape)
            .padding(16.dp),
        content = content,
    )
}

@Composable
private fun SectionRow(
    name: String, about: String, on: Boolean, canUp: Boolean, canDown: Boolean,
    up: () -> Unit, down: () -> Unit, flip: () -> Unit,
) {
    val u = LocalU.current
    Row(
        Modifier.fillMaxWidth().shadow(if (on) 5.dp else 1.dp, RoundedCornerShape(20.dp), ambientColor = Color.Black.copy(alpha = .3f), spotColor = Color.Black.copy(alpha = .3f))
            .clip(RoundedCornerShape(20.dp)).background(if (u.dark) Color(0xFF24272D) else Color.White)
            .padding(start = 16.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Column(Modifier.weight(1f).clickable(onClick = flip)) {
            Tx(name, 15 * u.fs, 700, if (on) u.ink else u.mu, maxLines = 1)
            Tx(about, 11.5f * u.fs, 500, u.mu, Modifier.padding(top = 2.dp), lh = 11.5f * u.fs * 1.4f)
        }
        Arrow(true, canUp, up)
        Arrow(false, canDown, down)
        Toggle(on, flip)
    }
}

/** A small up / down button; it is dimmed and does nothing when the section cannot move that way. */
@Composable
private fun Arrow(up: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val u = LocalU.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.rotate(if (up) -90f else 90f)) { Ico("chev", 16.dp, if (enabled) u.ink else u.mu.copy(alpha = .25f), 2.2f) }
    }
}
