package com.ringbook.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

// =====================================================================================================
// Online catalog (1.0): wrestlers, tag teams, stables and promotions from free sources.
//   Wikipedia          search, summary text, lead photo and the wrestler infobox (debut, trainer, billed height)
//   Wikidata           birthplace with its map coordinates, country, height, birth year, founding year
//   TheSportsDB        extra cut-outs / renders when it knows the wrestler (free test key)
//   Wikimedia Commons  dated photos, so one wrestler gets a catalog by year (free licences)
// Nothing here is stored except the picture you choose, which goes through the normal crop dialog and
// ImageStore, so it lives in the backup ZIP like any uploaded image.
// =====================================================================================================

data class OlRender(val url: String, val label: String, val sub: String = "", val big: String = url)

/** A search hit. [team] holds the short description ("American professional wrestler"), [wiki] the Wikipedia title. */
data class OlPlayer(
    val name: String, val team: String, val pos: String, val nationality: String, val born: String,
    val renders: List<OlRender>, val wiki: String = "",
)

/** What the detail page shows: [facts] are label / value rows, [about] the opening paragraphs of the article. */
data class OlStats(
    val who: String, val desc: String, val photo: String,
    val facts: List<Pair<String, String>>, val about: String,
)

/** Everything the web lookups know about one article. Missing parts stay blank. */
data class OlProfile(
    val title: String = "", val desc: String = "", val about: String = "", val thumb: String = "",
    val birthPlace: String = "", val geo: String = "", val country: String = "", val debut: String = "",
    val trainer: String = "", val billed: String = "", val heightCm: String = "", val born: String = "",
    val inception: String = "", val ringNames: String = "",
)

sealed interface OlState<out T> {
    data object Busy : OlState<Nothing>
    data class Ok<T>(val v: T) : OlState<T>
    data class Err(val msg: String) : OlState<Nothing>
}

/** Reads a card position out of a free-text description. Only managers can be told apart reliably, so others return "". */
fun olPos(p: String): String {
    val s = p.lowercase()
    return when {
        "manager" in s || "valet" in s || "executive" in s -> "MG"
        else -> ""
    }
}

private fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "").trim()

private fun olMsg(e: Exception): String = when {
    e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException ->
        "Can't reach the server. Check your connection and try again."
    e.message?.startsWith("HTTP 429") == true -> "The free service is rate limiting. Wait a minute and try again."
    else -> e.message ?: "Something went wrong."
}

/** Country names from Wikidata mapped onto the names the app uses ("United States of America" -> "USA"). */
fun olCountry(label: String): String {
    val t = label.trim()
    if (t.isEmpty()) return ""
    val alias = mapOf(
        "united states of america" to "USA", "united states" to "USA", "united kingdom" to "England",
        "czech republic" to "Czechia", "republic of ireland" to "Ireland", "kingdom of the netherlands" to "Netherlands",
        "people's republic of china" to "China", "republic of korea" to "South Korea", "korea, south" to "South Korea",
    )
    alias[t.lowercase()]?.let { return it }
    return COUNTRIES.find { it.first.equals(t, true) }?.first ?: t
}

// ------------------------------------------------------------------------------------------ network
object OlNet {
    private const val UA = "Ringbook/1.0.0 (Android; personal pro wrestling notes app)"

    fun bytes(url: String, tries: Int = 1): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "*/*")
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } catch (e: java.io.IOException) {
            // a free service that says "too many requests" or is busy for a moment: wait and try once more
            if (tries > 0 && (e.message ?: "").let { it.contains("429") || it.contains("503") || it.contains("502") }) {
                Thread.sleep(1600)
                return bytes(url, tries - 1)
            }
            throw e
        } finally {
            c.disconnect()
        }
    }

    fun json(url: String): JSONObject = JSONObject(String(bytes(url), Charsets.UTF_8))
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

object OlImages {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(url: String, maxSide: Int, useCache: Boolean = true): Bitmap? {
        val key = "$maxSide|$url"
        if (useCache) cache.get(key)?.let { return it }
        val data = runCatching { OlNet.bytes(url) }.getOrNull() ?: return null
        val bmp = decode(data, maxSide) ?: return null
        if (useCache) cache.put(key, bmp)
        return bmp
    }

    private fun decode(data: ByteArray, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    }
}

// -------------------------------------------------------------------------------- Wikipedia + Wikidata
object OlWiki {
    private const val API = "https://en.wikipedia.org/w/api.php"
    private val WRESTLING = Regex("(?i)(wrestl|tag team|stable|faction|promotion|lucha|puroresu|sumo|valet|manager)")

    /** A hit from the Wikipedia search: title, the short description and a lead photo. */
    class Hit(val title: String, val desc: String, val thumb: String)

    private fun wikiPath(title: String) = OlNet.enc(title.replace(' ', '_')).replace("+", "%20")

    /** Articles matching [q] that look like wrestling. If none do, everything found is returned so nothing is hidden. */
    fun search(q: String, extra: String): List<Hit> {
        val url = "$API?action=query&format=json&generator=search&gsrlimit=12&gsrsearch=${OlNet.enc("$q $extra")}" +
            "&prop=pageimages%7Cdescription&piprop=thumbnail&pithumbsize=500&pilimit=12"
        val pages = OlNet.json(url).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val all = ArrayList<Pair<Int, Hit>>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val title = p.s("title")
            if (title.isBlank()) continue
            all.add(
                p.optInt("index", 99) to Hit(title, p.s("description"), p.optJSONObject("thumbnail")?.s("source") ?: ""),
            )
        }
        val sorted = all.sortedBy { it.first }.map { it.second }
        val good = sorted.filter { WRESTLING.containsMatchIn(it.desc) }
        return if (good.isNotEmpty()) good else sorted.take(6)
    }

    /** Cuts the markup out of an infobox value: links, templates, references, line breaks. */
    private fun clean(s: String): String {
        var t = s
        t = t.replace(Regex("(?s)<ref[^>/]*>.*?</ref>"), "").replace(Regex("<ref[^>]*/>"), "")
        t = t.replace(Regex("(?i)<br\\s*/?>"), ", ").replace(Regex("<[^>]+>"), "")
        t = t.replace(Regex("(?i)\\{\\{\\s*(plainlist|ubl|unbulleted list|hlist|flatlist)\\s*\\|"), "").replace("*", ", ")
        var guard = 0
        while (guard++ < 6 && t.contains("{{")) t = t.replace(Regex("\\{\\{[^{}]*\\}\\}"), "")
        t = t.replace("}}", "")
        t = t.replace(Regex("\\[\\[[^\\]|]*\\|([^\\]]*)\\]\\]"), "$1").replace(Regex("\\[\\[([^\\]]*)\\]\\]"), "$1")
        t = t.replace("'''", "").replace("''", "").replace("&nbsp;", " ")
        t = t.replace(Regex("\\s*\\n\\s*"), " ").replace(Regex("(,\\s*)+"), ", ").trim().trim(',').trim()
        return t
    }

    private fun field(wt: String, key: String): String {
        val m = Regex("(?im)^\\s*\\|\\s*$key\\s*=\\s*(.*?)(?=\\n\\s*\\|[^\\n=]*=|\\n\\s*\\}\\})", RegexOption.DOT_MATCHES_ALL).find(wt) ?: return ""
        return clean(m.groupValues[1])
    }

    /** Wikitext of the opening section (it holds the infobox). */
    private fun lead(title: String): String = runCatching {
        val j = OlNet.json("$API?action=query&format=json&formatversion=2&prop=revisions&rvprop=content&rvslots=main&rvsection=0&titles=${OlNet.enc(title)}")
        j.getJSONObject("query").getJSONArray("pages").getJSONObject(0).getJSONArray("revisions").getJSONObject(0)
            .getJSONObject("slots").getJSONObject("main").getString("content")
    }.getOrDefault("")

    private fun qidOf(title: String): String? = runCatching {
        val pp = OlNet.json("$API?action=query&prop=pageprops&ppprop=wikibase_item&format=json&titles=${OlNet.enc(title)}")
        val pages = pp.getJSONObject("query").getJSONObject("pages")
        pages.getJSONObject(pages.keys().next()).getJSONObject("pageprops").getString("wikibase_item")
    }.getOrNull()

    /** The full profile of one Wikipedia article. Every step is allowed to fail on its own. */
    fun profile(title: String): OlProfile {
        var about = ""; var thumb = ""; var desc = ""; var shown = title
        runCatching {
            val s = OlNet.json("https://en.wikipedia.org/api/rest_v1/page/summary/${wikiPath(title)}")
            about = s.s("extract"); desc = s.s("description"); shown = s.s("title").ifBlank { title }
            thumb = s.optJSONObject("thumbnail")?.s("source") ?: ""
        }
        var debut = ""; var trainer = ""; var billed = ""; var ringNames = ""; var birthPlaceWt = ""
        val wt = lead(title)
        if (wt.isNotBlank()) {
            Regex("(?:19|20)\\d{2}").find(field(wt, "debut"))?.value?.let { debut = it }
            trainer = field(wt, "trainer").take(80)
            billed = field(wt, "billed_from").ifBlank { field(wt, "billed") }.take(80)
            ringNames = field(wt, "names").take(120)
            birthPlaceWt = field(wt, "birth_place").substringBefore(",").trim()
        }
        var birthPlace = ""; var geo = ""; var country = ""; var height = ""; var born = ""; var inception = ""
        runCatching {
            val qid = qidOf(title) ?: return@runCatching
            val ent = OlNet.json("https://www.wikidata.org/wiki/Special:EntityData/$qid.json")
                .getJSONObject("entities").getJSONObject(qid).getJSONObject("claims")
            fun first(p: String): JSONObject? = ent.optJSONArray(p)?.optJSONObject(0)?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")
            first("P2048")?.let { v ->
                val amt = v.s("amount").replace("+", "").toDoubleOrNull()
                if (amt != null && amt > 0) {
                    val cm = if (v.s("unit").endsWith("/Q11573") || amt < 3) amt * 100 else amt
                    if (cm in 100.0..260.0) height = cm.toInt().toString()
                }
            }
            first("P569")?.s("time")?.let { Regex("\\d{4}").find(it)?.value?.let { y -> born = y } }
            first("P571")?.s("time")?.let { Regex("\\d{4}").find(it)?.value?.let { y -> inception = y } }
            val placeId = first("P19")?.s("id").orEmpty()
            val countryId = (first("P27") ?: first("P495") ?: first("P17"))?.s("id").orEmpty()
            val hqId = if (countryId.isEmpty()) first("P159")?.s("id").orEmpty() else ""
            val ids = listOf(placeId, countryId, hqId).filter { it.isNotEmpty() }.distinct()
            if (ids.isNotEmpty()) {
                val ents = OlNet.json("https://www.wikidata.org/w/api.php?action=wbgetentities&props=labels%7Cclaims&languages=en&format=json&ids=${ids.joinToString("%7C")}")
                    .getJSONObject("entities")
                fun label(id: String) = ents.optJSONObject(id)?.optJSONObject("labels")?.optJSONObject("en")?.s("value").orEmpty()
                if (placeId.isNotEmpty()) {
                    birthPlace = label(placeId)
                    val c = ents.optJSONObject(placeId)?.optJSONObject("claims")?.optJSONArray("P625")?.optJSONObject(0)
                        ?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")
                    if (c != null && c.has("latitude") && c.has("longitude")) {
                        geo = String.format(java.util.Locale.US, "%.4f, %.4f", c.getDouble("latitude"), c.getDouble("longitude"))
                    }
                }
                if (countryId.isNotEmpty()) country = olCountry(label(countryId))
                else if (hqId.isNotEmpty()) {
                    // headquarters is a city: take its own country
                    val cid = ents.optJSONObject(hqId)?.optJSONObject("claims")?.optJSONArray("P17")?.optJSONObject(0)
                        ?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.s("id").orEmpty()
                    if (cid.isNotEmpty()) {
                        val l = OlNet.json("https://www.wikidata.org/w/api.php?action=wbgetentities&props=labels&languages=en&format=json&ids=$cid")
                            .getJSONObject("entities").optJSONObject(cid)?.optJSONObject("labels")?.optJSONObject("en")?.s("value").orEmpty()
                        country = olCountry(l)
                    }
                }
            }
        }
        if (birthPlace.isBlank()) birthPlace = birthPlaceWt
        return OlProfile(
            title = shown, desc = desc, about = about, thumb = thumb, birthPlace = birthPlace, geo = geo, country = country,
            debut = debut, trainer = trainer, billed = billed, heightCm = height, born = born, inception = inception, ringNames = ringNames,
        )
    }

    /** Wikipedia article thumbnail of a given width, for a stored thumb URL ("/500px-" is swapped). */
    fun bigger(url: String): String = url.replace("/500px-", "/960px-").replace("/320px-", "/960px-")
}

// ------------------------------------------------------------------------------------- TheSportsDB
object OlSportsDb {
    private const val KEY = "123" // free test key; fine for one-wrestler-at-a-time lookups

    fun search(q: String): List<OlPlayer> {
        val j = OlNet.json("https://www.thesportsdb.com/api/v1/json/$KEY/searchplayers.php?p=${OlNet.enc(q)}")
        val arr = j.optJSONArray("player") ?: return emptyList()
        val out = ArrayList<OlPlayer>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sport = o.s("strSport")
            if (!sport.contains("wrest", true) && !sport.contains("fight", true)) continue
            val rs = ArrayList<OlRender>()
            fun add(k: String, label: String) {
                val u = o.s(k).replace("http://", "https://")
                if (u.startsWith("https://")) rs.add(OlRender(u, label, "TheSportsDB"))
            }
            add("strCutout", "Cut-out")
            add("strRender", "Render")
            add("strThumb", "Photo")
            for (n in 1..4) add("strFanart$n", "Fan art $n")
            out.add(
                OlPlayer(
                    o.s("strPlayer"), o.s("strTeam"), olPos(o.s("strPosition")), o.s("strNationality"), o.s("dateBorn").take(10),
                    rs.distinctBy { it.url },
                ),
            )
        }
        return out.filter { it.name.isNotBlank() }
    }
}

// ------------------------------------------------------------------ all the sources, merged
object OlAll {
    private fun key(n: String) = Normalizer.normalize(n, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().replace(Regex("[^a-z ]"), "").trim()

    /** Every source is tried on its own, so one that is refused or down never hides the others. */
    fun search(q: String): List<OlPlayer> {
        val errs = ArrayList<Throwable>()
        fun <T> tryIt(f: () -> List<T>): List<T> = try { f() } catch (e: Exception) { errs.add(e); emptyList() }
        val wiki = tryIt { OlWiki.search(q, "professional wrestler") }.map { h ->
            val r = if (h.thumb.isNotBlank()) listOf(OlRender(h.thumb, "Photo", "Wikipedia", OlWiki.bigger(h.thumb))) else emptyList()
            OlPlayer(h.title.replace(Regex(" \\([^)]*\\)$"), ""), h.desc, olPos(h.desc), "", Regex("\\b(19|20)\\d{2}\\b").find(h.desc)?.value ?: "", r, h.title)
        }
        val db = tryIt { OlSportsDb.search(q) }
        if (wiki.isEmpty() && db.isEmpty() && errs.size == 2) throw errs.first()
        val merged = LinkedHashMap<String, OlPlayer>()
        for (p in wiki + db) {
            val k = key(p.name)
            val old = merged[k]
            merged[k] = if (old == null) p else old.copy(
                team = old.team.ifBlank { p.team }, pos = old.pos.ifBlank { p.pos },
                nationality = old.nationality.ifBlank { p.nationality }, born = old.born.ifBlank { p.born },
                renders = (old.renders + p.renders).distinctBy { it.url }, wiki = old.wiki.ifBlank { p.wiki },
            )
        }
        // transparent renders first, plain photos last
        return merged.values.map { p -> p.copy(renders = p.renders.sortedBy { if (it.label == "Photo" || it.label.startsWith("Fan")) 1 else 0 }) }
    }

    /** The profile page for the detail view (facts and about text). */
    fun stats(p: OlPlayer): OlStats? {
        val title = p.wiki.ifBlank { OlWiki.search(p.name, "professional wrestler").firstOrNull()?.title.orEmpty() }
        if (title.isBlank()) return null
        val pr = OlWiki.profile(title)
        if (pr.about.isBlank() && pr.birthPlace.isBlank()) return null
        val facts = ArrayList<Pair<String, String>>()
        if (pr.ringNames.isNotBlank()) facts.add("Ring names" to pr.ringNames)
        if (pr.born.isNotBlank()) facts.add("Born" to pr.born)
        if (pr.birthPlace.isNotBlank()) facts.add("Birthplace" to pr.birthPlace)
        if (pr.country.isNotBlank()) facts.add("Country" to pr.country)
        if (pr.heightCm.isNotBlank()) facts.add("Height" to "${pr.heightCm} cm")
        if (pr.billed.isNotBlank()) facts.add("Billed from" to pr.billed)
        if (pr.trainer.isNotBlank()) facts.add("Trained by" to pr.trainer)
        if (pr.debut.isNotBlank()) facts.add("Debut" to pr.debut)
        return OlStats(pr.title, pr.desc, pr.thumb, facts, pr.about)
    }
}

// --------------------------------------------------------------------------------- Wikimedia Commons
object OlCommons {
    private class Hit(val year: Int, val idx: Int, val r: OlRender)

    /** Photos of a person from Commons, newest first, each labelled with the year it was taken. */
    fun photos(name: String): List<OlRender> {
        val q = "\"" + name.replace("\"", "") + "\" filetype:bitmap"
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrsearch=${OlNet.enc(q)}&gsrnamespace=6&gsrlimit=40&prop=imageinfo" +
            "&iiprop=url%7Csize%7Cmime%7Cextmetadata&iiextmetadatafilter=DateTimeOriginal%7CDateTime%7CLicenseShortName" +
            "&iiurlwidth=500"
        val pages = OlNet.json(url).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val hits = ArrayList<Hit>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val mime = ii.s("mime")
            if (mime != "image/jpeg" && mime != "image/png") continue
            if (ii.optInt("width") < 400) continue
            val thumb = ii.s("thumburl").ifBlank { ii.s("url") }
            if (thumb.isBlank()) continue
            val meta = ii.optJSONObject("extmetadata")
            val date = (meta?.optJSONObject("DateTimeOriginal")?.s("value") ?: "")
                .ifBlank { meta?.optJSONObject("DateTime")?.s("value") ?: "" }
            val year = Regex("(19|20)\\d{2}").find(date)?.value ?: ""
            val lic = meta?.optJSONObject("LicenseShortName")?.s("value") ?: ""
            hits.add(
                Hit(
                    year.toIntOrNull() ?: 0, p.optInt("index", 999),
                    OlRender(thumb, year.ifEmpty { "Photo" }, lic, thumb.replace("/500px-", "/960px-")),
                ),
            )
        }
        return hits.sortedWith(compareByDescending<Hit> { it.year }.thenBy { it.idx }).take(30).map { it.r }
    }
}

// ================================================================================================ UI
@Composable
fun <T> olLoad(key: Any?, block: () -> T): OlState<T> {
    val st = produceState<OlState<T>>(OlState.Busy, key) {
        value = OlState.Busy
        value = withContext(Dispatchers.IO) {
            val r: OlState<T> = try {
                OlState.Ok(block())
            } catch (e: Exception) {
                OlState.Err(olMsg(e))
            }
            r
        }
    }
    return st.value
}

/** A picture from a URL, downloaded once and kept in a small memory cache. */
@Composable
fun OlThumb(url: String, modifier: Modifier = Modifier, round: Boolean = false) {
    val u = LocalU.current
    val st = produceState<Any?>(null, url) { value = withContext(Dispatchers.IO) { OlImages.load(url, 400) ?: false } }
    val shape: Shape = if (round) CircleShape else u.rs(10)
    Box(modifier.clip(shape).background(u.fieldFill), contentAlignment = Alignment.Center) {
        when (val v = st.value) {
            is Bitmap -> Image(
                v.asImageBitmap(), null, Modifier.fillMaxSize(),
                contentScale = if (round) ContentScale.Crop else ContentScale.Fit,
                alignment = if (round) Alignment.TopCenter else Alignment.Center,
            )
            is Boolean -> Tx("-", 16f, 700, u.mu)
            else -> {}
        }
    }
}

/** Button + sheet. [onPlayer] gets the chosen name and card position (MG or ""), [onImage] gets a saved image path. */
@Composable
fun OnlineLookup(
    name: String,
    onPlayer: (String, String) -> Unit,
    onImage: (String) -> Unit,
) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    Lbl("Online catalog")
    SmallBtn("Find online", "s") { open = true }
    Tx(
        "Names, photos by year and a short profile from Wikipedia and other free sources.", 12 * u.fs, 500, u.mu,
        Modifier.padding(start = 4.dp, top = 8.dp),
    )
    if (open) OnlineSheet(name, onPlayer, onImage) { open = false }
}

@Composable
fun OnlineSheet(initial: String, onPlayer: (String, String) -> Unit, onImage: (String) -> Unit, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf<OlPlayer?>(null) }
    var pending by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }

    fun choose(r: OlRender) {
        if (busy) return
        busy = true
        note = ""
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { OlImages.load(r.big, 2048, useCache = false) }
            busy = false
            if (bmp == null) note = "Couldn't download that image." else pending = bmp
        }
    }

    val p = picked
    Dialog(
        onDismissRequest = { if (picked != null) picked = null else onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd(if (p == null) "Find online" else p.name, 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip(if (p == null) "Close" else "Back", false) { if (p == null) onClose() else picked = null }
            }
            if (busy) Tx("Downloading...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
            if (note.isNotBlank()) Tx(note, 13 * u.fs, 600, u.red, Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
            if (p == null) {
                OlSearchPane(initial) { found ->
                    picked = found
                    onPlayer(found.name, found.pos)
                }
            } else {
                OlDetailPane(p, ::choose)
            }
        }
    }

    pending?.let { bmp ->
        ImageEditor(
            bmp, 1f,
            onDone = { out ->
                pending = null
                scope.launch {
                    val path = withContext(Dispatchers.IO) { ImageStore.save(ctx, out) }
                    onImage(path)
                    onClose()
                }
            },
            onCancel = { pending = null },
        )
    }
}

@Composable
private fun ColumnScope.OlSearchPane(initial: String, onFound: (OlPlayer) -> Unit) {
    val u = LocalU.current
    var q by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf(initial.trim()) }
    var tick by remember { mutableIntStateOf(0) }
    val res = olLoad<List<OlPlayer>>(query to tick) { if (query.isBlank()) emptyList() else OlAll.search(query) }

    Column(Modifier.padding(horizontal = 16.dp)) {
        Fld("Wrestler name", q, { q = it }, ph = "e.g. Rey Mysterio")
        SmallBtn("Search") { query = q.trim(); tick++ }
    }
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
        when (val r = res) {
            OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
            is OlState.Err -> item {
                Column(Modifier.padding(vertical = 12.dp)) {
                    Tx(r.msg, 14 * u.fs, 600, u.red)
                    SmallBtn("Try again", "s") { tick++ }
                }
            }
            is OlState.Ok -> {
                if (query.isBlank()) {
                    item { Tx("Type a name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                } else if (r.v.isEmpty()) {
                    item { Tx("Nothing found for \"$query\". Try the ring name in English.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                }
                items(r.v) { p0 ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onFound(p0) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        val face = p0.renders.firstOrNull { it.label == "Photo" } ?: p0.renders.firstOrNull()
                        if (face != null) OlThumb(face.url, Modifier.size(46.dp), round = true)
                        else Box(Modifier.size(46.dp).clip(CircleShape).background(u.fieldFill))
                        Column(Modifier.weight(1f)) {
                            Tx(p0.name, 15 * u.fs, 700, maxLines = 1)
                            Tx(
                                listOf(p0.team, p0.nationality).filter { it.isNotBlank() }.joinToString(" · "),
                                12 * u.fs, 500, u.mu, maxLines = 1,
                            )
                        }
                        if (p0.born.length >= 4) Tx(p0.born.take(4), 12 * u.fs, 600, u.mu)
                    }
                }
            }
        }
        if (query.isNotBlank()) item {
            SmallBtn("Browse photos and profile for \"$query\" anyway", "s") { onFound(OlPlayer(query, "", "", "", "", emptyList())) }
        }
    }
}

private fun LazyListScope.olGrid(list: List<OlRender>, onPick: (OlRender) -> Unit) {
    items(list.chunked(3)) { row ->
        val u = LocalU.current
        Row(
            Modifier.fillMaxWidth().padding(vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            row.forEach { r ->
                Column(Modifier.weight(1f).clickable { onPick(r) }) {
                    OlThumb(r.url, Modifier.fillMaxWidth().aspectRatio(1f))
                    Tx(r.label, 12 * u.fs, 700, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                    if (r.sub.isNotBlank()) Tx(r.sub, 11 * u.fs, 500, u.mu, maxLines = 1)
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun ColumnScope.OlDetailPane(p: OlPlayer, onPick: (OlRender) -> Unit) {
    val u = LocalU.current
    val stats = olLoad<OlStats?>("s:" + p.name + p.wiki) { OlAll.stats(p) }
    val photos = olLoad<List<OlRender>>("c:" + p.name) { OlCommons.photos(p.name) }
    val lead = (stats as? OlState.Ok<OlStats?>)?.v?.photo?.takeIf { it.isNotBlank() }?.let { OlRender(it, "Photo", "Wikipedia", OlWiki.bigger(it)) }
    val renders = (p.renders + listOfNotNull(lead)).distinctBy { it.url }
    val tight = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)

    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 0.dp, end = 16.dp, bottom = 40.dp)) {
        val sub = listOf(p.team, p.nationality, if (p.born.isNotBlank()) "b. ${p.born}" else "").filter { it.isNotBlank() }
        if (sub.isNotEmpty()) item { Tx(sub.joinToString(" · "), 13 * u.fs, 500, u.mu, tight) }
        item { Tx("Tap a picture to crop it and use it as the render.", 13 * u.fs, 500, u.mu, tight) }

        item { H3("Renders and cut-outs", 4.dp) }
        if (renders.isEmpty()) {
            item {
                val wait = stats is OlState.Busy
                Tx(
                    if (wait) "Looking for renders..." else "No renders for this wrestler yet.",
                    13 * u.fs, 500, u.mu, tight,
                )
            }
        } else olGrid(renders, onPick)

        item { H3("Photos by year", 4.dp) }
        item { Tx("Real photos from Wikimedia Commons (free licences), newest first. Not cut-outs.", 12 * u.fs, 500, u.mu, tight) }
        when (val r = photos) {
            OlState.Busy -> item { Tx("Loading photos...", 13 * u.fs, 500, u.mu, tight) }
            is OlState.Err -> item { Tx(r.msg, 13 * u.fs, 600, u.red, tight) }
            is OlState.Ok -> if (r.v.isEmpty()) item { Tx("No photos found for this name.", 13 * u.fs, 500, u.mu, tight) } else olGrid(r.v, onPick)
        }

        item { H3("Profile", 4.dp) }
        when (val r = stats) {
            OlState.Busy -> item { Tx("Loading profile...", 13 * u.fs, 500, u.mu, tight) }
            is OlState.Err -> item { Tx(r.msg, 13 * u.fs, 600, u.red, tight) }
            is OlState.Ok -> {
                val s = r.v
                if (s == null) {
                    item { Tx("No Wikipedia profile found for this name.", 13 * u.fs, 500, u.mu, tight) }
                } else {
                    item {
                        Tx(s.who, 14 * u.fs, 700, modifier = tight)
                        if (s.desc.isNotBlank()) Tx(s.desc, 12 * u.fs, 500, u.mu, Modifier.padding(horizontal = 4.dp))
                    }
                    items(s.facts) { (k, v) ->
                        KvRow(false, Modifier.padding(horizontal = 4.dp)) {
                            Tx(k, 14 * u.fs, 500, u.mu)
                            Tx(v, 14 * u.fs, 700)
                        }
                    }
                    if (s.about.isNotBlank()) {
                        item { H3("About", 4.dp) }
                        item { Tx(s.about, 13 * u.fs, 500, modifier = tight) }
                    }
                }
            }
        }
    }
}
