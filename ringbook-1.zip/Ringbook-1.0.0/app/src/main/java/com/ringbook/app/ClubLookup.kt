package com.ringbook.app

import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

// =====================================================================================================
// Wrestler lookup (1.0): type "Rey Mysterio", pick the wrestler, and the form fills itself in.
//   Wikipedia   search, the "About" text, the lead photo, debut year, trainer
//   Wikidata    birthplace (and its map position), height, country
// Everything lands in the normal form fields, so it stays editable. Missing data is simply left blank.
// =====================================================================================================

data class OlClub(val title: String, val name: String, val desc: String, val thumb: String)

object OlClubs {
    /** Wrestlers, tag teams and stables matching [q]. */
    fun search(q: String): List<OlClub> =
        OlWiki.search(q, "professional wrestling").map { h ->
            OlClub(h.title, h.title.replace(Regex(" \\([^)]*\\)$"), ""), h.desc, h.thumb)
        }

    /** The most common saturated colour of the crest, for clubs whose colours the database doesn't know. */
    fun crestColors(b: Bitmap): List<String> {
        val s = Bitmap.createScaledBitmap(b, 48, 48, true)
        val tally = HashMap<Int, Float>()
        val hsv = FloatArray(3)
        for (y in 0 until 48) for (x in 0 until 48) {
            val p = s.getPixel(x, y)
            if (android.graphics.Color.alpha(p) < 200) continue
            android.graphics.Color.colorToHSV(p, hsv)
            if (hsv[1] < .35f || hsv[2] < .25f) continue
            val key = ((hsv[0] / 24f).toInt() shl 8) or ((hsv[1] * 3).toInt() shl 4) or (hsv[2] * 3).toInt()
            tally[key] = (tally[key] ?: 0f) + hsv[1] * hsv[2]
        }
        return tally.entries.sortedByDescending { it.value }.take(2).map { e ->
            val h = (e.key shr 8) * 24f + 12f
            val c = android.graphics.Color.HSVToColor(floatArrayOf(h, ((e.key shr 4) and 15) / 3f + .17f, (e.key and 15) / 3f + .17f).also { it[1] = it[1].coerceAtMost(1f); it[2] = it[2].coerceAtMost(1f) })
            String.format("#%06x", c and 0xFFFFFF)
        }
    }
}

/** A short About text: whole sentences, at most about 700 characters. */
private fun trimAbout(s: String, max: Int = 700): String {
    val t = s.replace(Regex("\\s+\\n"), "\n").trim()
    if (t.length <= max) return t
    val cut = t.take(max)
    val end = cut.lastIndexOf(". ")
    return if (end > 200) cut.take(end + 1) else cut.trimEnd() + "..."
}

/** Button for the wrestler form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun ClubLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a ring name, pick the wrestler, and hometown, map position, height, debut, trainer, photo and an About text are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) ClubLookupSheet(d) { open = false }
}

@Composable
private fun ClubLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    val res = olLoad<List<OlClub>>(query to tick) { if (query.isBlank()) emptyList() else OlClubs.search(query) }

    fun apply(c: OlClub) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val (pr, bmp) = withContext(Dispatchers.IO) {
                val e = runCatching { OlWiki.profile(c.title) }.getOrDefault(OlProfile())
                val url = e.thumb.ifBlank { c.thumb }
                val b = if (url.isNotBlank()) OlImages.load(OlWiki.bigger(url), 1024, useCache = false) ?: OlImages.load(url, 1024, useCache = false) else null
                e to b
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", c.name)
            put("nick", pr.ringNames.split(",").firstOrNull { it.isNotBlank() && !it.trim().equals(c.name, true) }?.trim().orEmpty().take(30))
            put("city", pr.birthPlace.ifBlank { pr.billed })
            put("geo", pr.geo)
            put("founded", pr.debut)
            put("cap", pr.heightCm)
            put("chair", pr.trainer)
            put("info", trimAbout(pr.about))
            if (bmp != null && (replace || d["logo"].isBlank())) {
                d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, bmp) }
            } else if (bmp == null && (pr.thumb.isNotBlank() || c.thumb.isNotBlank())) note = "Filled in, but the photo couldn't be downloaded."
            if (pr.about.isBlank() && pr.birthPlace.isBlank() && pr.debut.isBlank()) note = "Only the name was found. Wikipedia had no details for this one."
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("Wrestler or team name", q, { q = it }, ph = "e.g. Rey Mysterio")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a ring name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the ring name in English.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { c ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(c) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (c.thumb.isNotBlank()) OlThumb(c.thumb, Modifier.size(46.dp), round = true)
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(c.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(c.desc, 12 * u.fs, 500, u.mu, maxLines = 2)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
