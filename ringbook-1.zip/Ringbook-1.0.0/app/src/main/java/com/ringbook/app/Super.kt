package com.ringbook.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// =====================================================================================================
// Tournaments and alliances: a Royal Rumble, a G1 Climax, a Forbidden Door show. It only lists wrestlers from your
// promotions, so it never touches their own rankings, matches or feeder links.
// =====================================================================================================

private fun Super.leagueIds(vm: AppVM) = clubs.mapNotNull { vm.cl(it)?.lid }.distinct()

/** All tournaments, as cards. */
@Composable
fun SupersPage(vm: AppVM) {
    val u = LocalU.current
    TopRow(vm.backLabel, { vm.goBack() })
    Tp("Tournaments", "Tournaments and alliances")
    Column(Modifier.bd(top = 18.dp)) {
        Tx(
            "A tournament is a bracket, block or show of wrestlers from different promotions, like the Royal Rumble or the G1 Climax. It is separate from your promotions: a wrestler can enter one without leaving their own promotion.",
            13 * u.fs, 500, u.mu, Modifier.padding(bottom = 16.dp), lh = 13 * u.fs * 1.5f,
        )
        if (vm.supers.isEmpty()) EmptyBlock("No tournaments yet.") { SmallBtn("Create a tournament") { vm.editSuper(null) } }
        vm.supers.forEach { s ->
            Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(18.dp), onClick = { vm.openSuper(s.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Crest(s.color, "", s.logo, s.short.ifBlank { s.name.take(3).uppercase() }, 56.dp, xl = true)
                    Column(Modifier.weight(1f)) {
                        Tx(s.name, 17 * u.fs, 800, maxLines = 1)
                        Tx(
                            listOf(s.cont.ifBlank { "Worldwide" }, "${s.clubs.size} wrestlers", "${s.leagueIds(vm).size} promotions").joinToString(" · "),
                            13 * u.fs, 500, u.mu, Modifier.padding(top = 2.dp), maxLines = 1,
                        )
                    }
                    Ico("chev", 18.dp, u.mu, 2f)
                }
            }
        }
        if (vm.supers.isNotEmpty()) DashedBtn("New tournament", "plus", Modifier.fillMaxWidth()) { vm.editSuper(null) }
    }
}

/** One tournament: its wrestlers grouped by country, and a picker to add more. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SuperPage(vm: AppVM, id: String) {
    val u = LocalU.current
    val s = vm.supers.find { it.id == id } ?: return
    var q by remember(id) { mutableStateOf("") }
    var all by remember(id) { mutableStateOf(false) }
    val members = s.clubs.mapNotNull { vm.cl(it) }
    // wrestlers that may be added: the continent's own, or everyone when the tournament is worldwide
    fun leagueOk(lid: String): Boolean {
        val l = vm.lg(lid) ?: return false
        return all || s.cont.isBlank() || Continents.ofLeague(vm, l) == s.cont
    }
    val pool = vm.clubs.filter { it.id !in s.clubs && leagueOk(it.lid) }
    val hits = pool.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.city.contains(q.trim(), true) }
        .sortedWith(compareBy({ vm.lg(it.lid)?.country ?: "" }, { it.name })).take(40)
    val leaguesHere = vm.leagues.filter { leagueOk(it.id) && vm.clubs.any { c -> c.lid == it.id && c.id !in s.clubs } }

    TopRow(vm.backLabel, { vm.goBack() }) { CircleBtn("edit", { vm.editSuper(id) }) }
    Tp(s.name, s.cont.ifBlank { "Worldwide" })
    Column(Modifier.bd(top = 16.dp)) {
        Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Crest(s.color, "", s.logo, s.short.ifBlank { s.name.take(3).uppercase() }, 64.dp, xl = true)
                Column(Modifier.weight(1f)) {
                    Tx("${members.size} wrestlers · ${members.map { it.lid }.distinct().size} promotions", 15 * u.fs, 800)
                    Tx(
                        s.note.ifBlank { "Add the wrestlers who qualified. Their own promotions stay untouched." },
                        13 * u.fs, 500, u.mu, Modifier.padding(top = 4.dp), lh = 13 * u.fs * 1.45f,
                    )
                }
            }
        }

        H3("Wrestlers")
        if (members.isEmpty()) Tx("No wrestlers yet. Add some below.", 14 * u.fs, 500, u.mu, Modifier.padding(horizontal = 6.dp, vertical = 8.dp))
        else {
            // grouped by the country of the wrestler's promotion
            val byCountry = members.groupBy { vm.lg(it.lid)?.country?.ifBlank { null } ?: "Other" }.toSortedMap()
            byCountry.forEach { (country, cs) ->
                Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
                    Tx("${if (country == "Other") "" else flag(country)}$country · ${cs.size}", 12.5f * u.fs, 800, u.mu, Modifier.padding(top = 8.dp, bottom = 2.dp))
                    cs.sortedBy { it.name }.forEachIndexed { i, c ->
                        KvRow(i == cs.lastIndex) {
                            Row(
                                Modifier.weight(1f).clickable { vm.openClub(c.id) },
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Crest(c.color, c.c2, c.logo, c.short, 34.dp)
                                Column(Modifier.weight(1f)) {
                                    Tx(c.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(vm.lg(c.lid)?.name ?: "", 12 * u.fs, 500, u.mu, maxLines = 1)
                                }
                            }
                            Box(Modifier.size(34.dp).clip(CircleShape).clickable { vm.superRemove(id, c.id) }, contentAlignment = Alignment.Center) {
                                Ico("close", 16.dp, u.mu, 2f)
                            }
                        }
                    }
                }
            }
        }

        H3("Add wrestlers")
        if (s.cont.isNotBlank()) {
            Row(Modifier.padding(start = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("${s.cont} only", !all) { all = false }
                Chip("Any continent", all) { all = true }
            }
        }
        if (leaguesHere.isNotEmpty()) {
            Tx("Add the top wrestlers of a promotion", 12 * u.fs, 600, u.mu, Modifier.padding(start = 6.dp, bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                leaguesHere.forEach { l ->
                    Chip("${flag(l.country)}${l.name} top 4", false) { vm.superAdd(id, vm.table(l.id).filter { it.id !in s.clubs }.take(4).map { it.id }) }
                }
            }
        }
        Fld("Search a wrestler", q, { q = it }, ph = "Name or hometown")
        Spacer(Modifier.height(8.dp))
        if (pool.isEmpty()) Tx(
            if (vm.clubs.isEmpty()) "You have no wrestlers yet." else "Every wrestler of ${if (all || s.cont.isBlank()) "your promotions" else s.cont} is already in.",
            13 * u.fs, 500, u.mu, Modifier.padding(6.dp),
        ) else Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            if (hits.isEmpty()) Tx("No wrestler matches.", 13 * u.fs, 500, u.mu, Modifier.padding(vertical = 14.dp))
            hits.forEachIndexed { i, c ->
                KvRow(i == hits.lastIndex, Modifier.clickable { vm.superAdd(id, listOf(c.id)) }) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Crest(c.color, c.c2, c.logo, c.short, 34.dp)
                        Column(Modifier.weight(1f)) {
                            Tx(c.name, 15 * u.fs, 700, maxLines = 1)
                            Tx(vm.lg(c.lid)?.let { flag(it.country) + it.name } ?: "", 12 * u.fs, 500, u.mu, maxLines = 1)
                        }
                    }
                    Ico("plus", 18.dp, u.acc, 2.2f)
                }
            }
        }
        Tx(
            "Wrestlers show here by the continent of their promotion's country. A promotion whose country is not recognised only appears under Any continent.",
            12 * u.fs, 500, u.mu, Modifier.padding(horizontal = 6.dp, vertical = 4.dp), lh = 12 * u.fs * 1.5f,
        )
    }
}

/** Create or edit a tournament. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SuperDialog(vm: AppVM, d: Draft) {
    val u = LocalU.current
    var err by remember { mutableStateOf("") }
    Dialog(onDismissRequest = { vm.superEdit = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(.94f).heightIn(max = 700.dp).clip(RoundedCornerShape(32.dp))
                .background(if (u.coral) u.menuBg else if (u.dark) Color(0xFF16181D) else Color.White)
                .verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Hd(if (d.eid == null) "New tournament" else "Edit tournament", 26f)
            Fld("Name", d["name"], { d["name"] = it; err = "" }, ph = "Royal Rumble")
            Fld("Short name", d["short"], { d["short"] = it }, ph = "RR")
            Lbl("Continent")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                (Continents.ALL + "").forEach { c -> Chip(c.ifBlank { "Worldwide" }, d["cont"] == c) { d["cont"] = c } }
            }
            if (d.eid == null && d["name"].isBlank()) {
                Lbl("Quick start")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        Triple("Royal Rumble", "RR", ""), Triple("G1 Climax", "G1", ""),
                        Triple("Money in the Bank", "MITB", ""), Triple("King of the Ring", "KOTR", ""),
                        Triple("Forbidden Door", "FD", ""), Triple("Survivor Series", "SS", ""),
                        Triple("Elimination Chamber", "EC", ""), Triple("Best of the Super Juniors", "BOSJ", ""),
                    ).forEach { (n, sh, c) -> Chip(n, false) { d["name"] = n; d["short"] = sh; d["cont"] = c } }
                }
            }
            ColorField("Colour", d["color"]) { d["color"] = it }
            Upload("Logo", d, "logo")
            Fld("Note", d["note"], { d["note"] = it }, multi = true, ph = "Format, date, anything to remember")
            if (err.isNotEmpty()) Tx(err, 13 * u.fs, 700, u.red)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallBtn("Save") { val e = vm.saveSuper(d); if (e == null) vm.superEdit = null else err = e }
                SmallBtn("Cancel", "s") { vm.superEdit = null }
            }
            d.eid?.let { id -> DeleteBtn("Delete tournament", 0.dp) { vm.deleteSuper(id); vm.superEdit = null } }
        }
    }
}
