package com.ringbook.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp

/**
 * Lets a whole screen be swiped sideways (Paperback's SwipeHost): right for [onSwipeRight] (usually Back), left for
 * [onSwipeLeft]. Anything inside that scrolls or drags sideways (tables, chip rows, sliders, the lineup pitch)
 * takes the swipe first, so those keep working; only a free horizontal swipe of about 80 dp counts.
 */
@Composable
fun SwipeHost(
    enabled: Boolean,
    onSwipeRight: (() -> Unit)?,
    onSwipeLeft: (() -> Unit)?,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val right by rememberUpdatedState(onSwipeRight)
    val left by rememberUpdatedState(onSwipeLeft)
    Box(
        modifier.pointerInput(enabled) {
            if (!enabled) return@pointerInput
            val threshold = 80.dp.toPx()
            var total = 0f
            detectHorizontalDragGestures(
                onDragStart = { total = 0f },
                onDragCancel = { total = 0f },
                onDragEnd = {
                    if (total > threshold) right?.invoke() else if (total < -threshold) left?.invoke()
                    total = 0f
                },
                onHorizontalDrag = { _, amount -> total += amount },
            )
        },
        content = content,
    )
}

/** A tap target that also opens a small menu on long press (with a buzz), like Paperback's book covers. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PressMenu(
    items: List<Pair<String, () -> Unit>>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    Box(modifier.combinedClickable(onClick = onClick, onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); open = true })) {
        content()
        DropdownMenu(open, { open = false }) {
            items.forEach { (t, f) -> DropdownMenuItem(text = { Text(t) }, onClick = { open = false; f() }) }
        }
    }
}
