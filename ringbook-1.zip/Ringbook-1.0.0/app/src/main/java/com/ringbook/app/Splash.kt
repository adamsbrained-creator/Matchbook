package com.ringbook.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Gold of the app icon, used for the glow behind the launch screen. */
val BrandGreen = Color(0xFFFFC23D)

/** The Ringbook logo: the app icon (a thin ring in perspective on black), drawn from the launcher icon's own vector. */
@Composable
fun PitchMark(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(percent = 24)
    Box(modifier.clip(shape).background(Color(0xFF161616)).border(1.dp, Color.White.copy(alpha = .10f), shape), contentAlignment = Alignment.Center) {
        // the launcher layer keeps a safe margin for round masks, so it is enlarged a little here
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.fillMaxSize().scale(1.25f))
    }
}

// ---------------------------------------------------------------- launch screen
@Composable
fun LaunchSplash(onDone: () -> Unit) {
    val pop = remember { Animatable(0f) }
    val word = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
            launch { delay(380); word.animateTo(1f, tween(520)) }
        }
        delay(520)
        fade.animateTo(0f, tween(320))
        onDone()
    }

    Box(
        Modifier.fillMaxSize().alpha(fade.value).background(Color(0xFF0B0C0F))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.radialGradient(
                    listOf(BrandGreen.copy(alpha = .16f), BrandGreen.copy(alpha = .05f), Color.Transparent),
                    center = Offset(size.width / 2f, size.height * .42f), radius = size.width * .9f,
                ),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            PitchMark(Modifier.size(132.dp).scale(.55f + .45f * pop.value).alpha(pop.value.coerceIn(0f, 1f)))
            Spacer(Modifier.height(22.dp))
            Column(Modifier.alpha(word.value), horizontalAlignment = Alignment.CenterHorizontally) {
                Hd("Ringbook", 38f, Color.White, align = TextAlign.Center)
                Tx("Your wrestling, organised", 14f, 600, Color.White.copy(alpha = .65f), Modifier.padding(top = 6.dp), align = TextAlign.Center)
            }
        }
    }
}
