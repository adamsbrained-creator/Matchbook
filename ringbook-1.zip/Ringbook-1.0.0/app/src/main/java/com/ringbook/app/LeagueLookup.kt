package com.ringbook.app

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

// =====================================================================================================
// Promotion lookup (1.0): type "New Japan Pro-Wrestling", pick the promotion, and the form fills itself in.
//   Wikipedia   search, the logo (lead image of the article)
//   Wikidata    country and founding year
// The colour is taken from the logo. Everything lands in the normal form fields, so it stays editable.
// =====================================================================================================

data class OlLeague(
    val id: String, val name: String, val country: String, val season: String,
    val badge: String, val banner: String, val formed: String,
)

object OlLeagues {
    /** Promotions matching [q]. The Founded year and country are added when one is picked. */
    fun search(@Suppress("UNUSED_PARAMETER") ctx: Context, q: String): List<OlLeague> =
        OlWiki.search(q, "professional wrestling promotion").map { h ->
            OlLeague("wp:${h.title}", h.title.replace(Regex(" \\([^)]*\\)$"), ""), "", "", h.thumb, "", "")
        }

    /** A result that only has its name gets country and founding year when it is picked. */
    fun complete(l: OlLeague): OlLeague {
        if (l.country.isNotBlank() && l.formed.isNotBlank()) return l
        val title = l.id.removePrefix("wp:")
        val p = runCatching { OlWiki.profile(title) }.getOrNull() ?: return l
        return l.copy(
            country = p.country, formed = p.inception, season = p.inception,
            badge = l.badge.ifBlank { p.thumb },
        )
    }

    /** The logo of a Wikipedia article, for results that came without one. */
    fun wikiThumb(title: String): String = runCatching { OlWiki.profile(title).thumb }.getOrDefault("")

    /** "2025-2026" -> "2025/26", "2026" stays. */
    fun season(s: String): String {
        val m = Regex("""^(\d{4})\s*[-/]\s*(\d{4})$""").find(s.trim()) ?: return s.trim()
        return m.groupValues[1] + "/" + m.groupValues[2].takeLast(2)
    }
}

/** Button for the league form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun LeagueLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a promotion name, pick it, and country, founding year, logo and colour are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) LeagueLookupSheet(d) { open = false }
}

@Composable
private fun LeagueLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    // search while typing: a moment after the last key
    LaunchedEffect(q) { if (q.trim() != query) { delay(600); query = q.trim() } }
    val res = olLoad<List<OlLeague>>(query to tick) { if (query.isBlank()) emptyList() else OlLeagues.search(ctx, query) }

    fun apply(picked: OlLeague) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val l = withContext(Dispatchers.IO) { OlLeagues.complete(picked) }
            val (logo, banner) = withContext(Dispatchers.IO) {
                val url = l.badge.ifBlank { if (l.id.startsWith("wp:")) OlLeagues.wikiThumb(l.name) else "" }
                val b = if (url.isNotBlank()) OlImages.load(url, 512, useCache = false) else null
                val bn = if (l.banner.isNotBlank()) OlImages.load(l.banner, 1400, useCache = false) else null
                b to bn
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", l.name); put("country", l.country); put("season", l.formed.ifBlank { l.season })
            if (logo != null) {
                if (replace || d["color"].isBlank() || d["color"] == "#2da678") OlClubs.crestColors(logo).firstOrNull()?.let { d["color"] = it }
                if (replace || d["logo"].isBlank()) d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, logo) }
            } else if (l.badge.isNotBlank()) note = "Filled in, but the logo couldn't be downloaded."
            if (banner != null && (replace || d["banner"].isBlank())) d["banner"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, banner) }
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("Promotion name", q, { q = it }, ph = "e.g. All Elite Wrestling")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a promotion name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the English name.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { l ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(l) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (l.badge.isNotBlank()) OlThumb(l.badge, Modifier.size(46.dp))
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(l.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(listOf(l.country, OlLeagues.season(l.season)).filter { it.isNotBlank() }.joinToString(" · "), 12 * u.fs, 500, u.mu, maxLines = 1)
                                }
                                if (l.formed.isNotBlank()) Tx(l.formed, 12 * u.fs, 600, u.mu)
                            }
                        }
                    }
                }
            }
        }
    }
}
