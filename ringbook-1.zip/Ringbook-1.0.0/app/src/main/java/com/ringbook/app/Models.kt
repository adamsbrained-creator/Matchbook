package com.ringbook.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Version of the saved-data / backup format. Bump when the JSON layout changes (and add a migration). Ringbook starts at 3 (the layout it was built from). */
const val DATA_FORMAT = 3

val ALL_COLS = listOf("w" to "Wins", "d" to "Draws", "l" to "Losses", "gf" to "Falls for", "ga" to "Falls against", "gd" to "Fall difference")
val ALL_FIELDS = listOf(
    "stadium" to "Finisher", "nick" to "Nickname", "mgr" to "Manager", "chair" to "Trainer",
    "cap" to "Height", "hon" to "Championships", "about" to "About",
)
val PRESETS = listOf("Gold", "Coral", "Light", "Mono", "Pop", "Classic")

class BlockDef(val key: String, val label: String, val def: Boolean)
class BlockGroup(val page: String, val items: List<BlockDef>)

/** Optional cards and blocks that can be switched on or off per page (Settings > Page blocks). */
val BLOCK_GROUPS = listOf(
    BlockGroup("Wrestlers", listOf(
        BlockDef("c_fixture", "Next match card", true),
        BlockDef("c_actions", "Add wrestler and Compare buttons", true),
        BlockDef("c_leaders", "Ranking leaders card", false),
    )),
    BlockGroup("Promotions", listOf(
        BlockDef("l_summary", "Promotion summary strip", true),
        BlockDef("l_tables", "Mini rankings", false),
        BlockDef("l_pyramid", "Feeder ladder", false),
        BlockDef("l_add", "Add promotion button", true),
    )),
    BlockGroup("Promotion page", listOf(
        BlockDef("g_table", "Rankings card", true),
        BlockDef("g_rules", "Rule tiles", true),
        BlockDef("g_fixture", "Next match card", true),
        BlockDef("g_links", "Call-up and send-down links", true),
        BlockDef("g_leaders", "Most falls and fewest falls leaders", false),
    )),
    BlockGroup("Wrestler page", listOf(
        BlockDef("k_strip", "Stat strip", true),
        BlockDef("k_stripx", "Extra strip stats (falls for, against, difference)", false),
        BlockDef("k_glow", "Colour glow", true),
        BlockDef("k_info", "Info card", true),
        BlockDef("k_squad", "Stable, ring board and storylines card", true),
        BlockDef("k_tiles", "Stat tiles", true),
        BlockDef("k_tiles2", "More stat tiles", false),
        BlockDef("k_details", "Wrestler details card", true),
        BlockDef("k_neighbours", "Ranking neighbours", false),
    )),
    BlockGroup("Stats", listOf(
        BlockDef("s_overview", "Overview tiles", true),
        BlockDef("s_top", "Top lists", true),
    )),
)
/** Blocks that did not exist in data format 2: switched on for upgraded settings. */
val BLOCKS_ADDED_V3: Set<String> = setOf("k_squad")
val DEFAULT_BLOCKS: Set<String> = BLOCK_GROUPS.flatMap { it.items }.filter { it.def }.map { it.key }.toSet()
val DEFAULT_FIELDS: Set<String> = ALL_FIELDS.map { it.first }.toSet()

data class Settings(
    val ui: String = "glass",         // glass (2.0 look) | coral (2.5 look)
    val theme: String = "dark",       // auto | dark | light
    val acc: String = "#ffc23d",
    val g: String = "bold",           // header glow: bold | soft | mono
    val gh: String = "m",             // header glow height: s | m | l
    val surf: String = "glass",       // glass | solid | outline
    val r: Int = 28,                  // card corner radius
    val ring: Int = 8,
    val c: String = "circle",         // crest shape
    val f: String = "manrope",        // manrope | condensed | rounded | serif | mono
    val fs: String = "m",
    val d: String = "cozy",
    val nm: String = "full",          // wrestler names: full | short
    val navs: String = "float",       // menu (Coral only) | float | labeled | capsule | tabs | dial | pill | rail | bubble | arc | dots | drawer | islands
    val lbl: String = "off",          // nav labels: on | off
    val cg: String = "g2",            // wrestlers layout: list | g2 | g3 | comp | plain | gplain
    val lg: String = "cards",         // promotions layout: cards | list | g2
    val sg: String = "list",          // stats layout: list | g2
    val tc: String = "3",             // tile columns: 2 | 3
    val splash: Boolean = true,
    val swipeBack: Boolean = true,    // swipe right anywhere to go back
    val tlogo: Boolean = false,       // wrestler photos instead of colour dots in rankings
    val swipeTabs: Boolean = false,   // swipe left / right to move between the main pages
    val fullscreen: Boolean = false,  // hide the status bar and the navigation bar
    val home: String = DEFAULT_HOME,  // Home page: the sections that are shown, in order ("map" = the map on top)
    val homeRows: Int = 4,            // Home page: rows of the mini table
    val homeGap: Int = 1,             // Home page: space between sections, 0 tight .. 3 airy
    val homeDepth: String = "S",      // Home page cards: F flat | S soft shadow | R raised
    val homeHide: Set<String> = emptySet(), // Home page: hidden items ("c:<wrestler id>" or "g:<country key>")
    val cols: Set<String> = emptySet(),
    val fields: Set<String> = DEFAULT_FIELDS,
    val blocks: Set<String> = DEFAULT_BLOCKS,
)

fun Settings.at(k: String) = when (k) {
    "ui" -> ui; "theme" -> theme; "acc" -> acc; "g" -> g; "gh" -> gh; "surf" -> surf; "c" -> c; "f" -> f; "fs" -> fs; "d" -> d
    "nm" -> nm; "navs" -> navs; "lbl" -> lbl; "cg" -> cg; "lg" -> lg; "sg" -> sg; "tc" -> tc; else -> ""
}

fun Settings.put(k: String, v: String) = when (k) {
    "ui" -> copy(ui = v); "theme" -> copy(theme = v); "acc" -> copy(acc = v); "g" -> copy(g = v); "gh" -> copy(gh = v); "surf" -> copy(surf = v)
    "c" -> copy(c = v); "f" -> copy(f = v); "fs" -> copy(fs = v); "d" -> copy(d = v); "nm" -> copy(nm = v)
    "navs" -> copy(navs = v); "lbl" -> copy(lbl = v); "cg" -> copy(cg = v); "lg" -> copy(lg = v); "sg" -> copy(sg = v)
    "tc" -> copy(tc = v); else -> this
}

/** Presets only change the look, never your data or your block / column / layout choices. */
fun Settings.preset(id: String): Settings {
    val b = Settings(cols = cols, fields = fields, blocks = blocks, splash = splash, swipeBack = swipeBack, swipeTabs = swipeTabs, fullscreen = fullscreen, home = home, homeRows = homeRows, homeGap = homeGap, homeDepth = homeDepth, homeHide = homeHide, tlogo = tlogo, cg = cg, lg = lg, sg = sg, tc = tc, navs = if (navs == "menu") "float" else navs, lbl = lbl)
    return when (id) {
        "Coral" -> b.copy(ui = "coral", theme = "light", acc = "#f46c4e", f = "outfit", r = 28, ring = 0, c = "circle", navs = "menu")
        "Light" -> b.copy(theme = "light", acc = "#16a34a", g = "soft")
        "Mono" -> b.copy(acc = "#ffffff", g = "mono", r = 22, ring = 3, surf = "outline")
        "Pop" -> b.copy(acc = "#ff5ca8", r = 32, f = "rounded", c = "hex")
        "Classic" -> b.copy(acc = "#e5c07b", r = 18, f = "serif", c = "shield", g = "soft", surf = "solid")
        else -> b
    }
}

/** A wrestling promotion (WWE, AEW, NJPW...). [season] holds the year it was founded. */
data class League(
    val id: String, val name: String, val country: String = "", val season: String = "",
    val color: String = "#2da678", val logo: String = "", val banner: String = "",
    val pw: Int = 3, val pd: Int = 1, val promo: Int = 1, val rel: Int = 1,   // points for a win / draw, call-up spots, send-down spots
    val promoTo: String = "", val relTo: String = "",                         // promotion that call-ups / send-downs go to
    val quals: String = "",           // rank tiers (title picture, contenders...), one per line: name|from|to|#colour
    val groups: String = "",          // brands or blocks (Raw / SmackDown, Block A / B), one name per line (empty = a single table)
)

/** A custom rank tier ("Title picture", places 1 to 3). */
class Qual(val name: String, val from: Int, val to: Int, val color: String)

fun parseQuals(s: String): List<Qual> = s.lines().mapNotNull { ln ->
    val p = ln.split("|")
    if (p.size < 4) null else Qual(p[0], p[1].trim().toIntOrNull() ?: 1, p[2].trim().toIntOrNull() ?: 1, p[3].trim().ifBlank { "#3b82f6" })
}

fun encodeQuals(l: List<Qual>): String = l.joinToString("\n") { "${it.name.replace("|", " ").replace("\n", " ")}|${it.from}|${it.to}|${it.color}" }

fun List<Qual>.at(rank: Int): Qual? = firstOrNull { rank in minOf(it.from, it.to)..maxOf(it.from, it.to) }

/**
 * A wrestler, tag team or stable (the field names come from the football app this was built from).
 * [city] hometown, [founded] debut year, [stadium] finisher, [cap] height in cm, [mgr] manager, [chair] trainer,
 * [titles] title reigns, [gf]/[ga] falls won / lost, [hon] championships, [info] about, [grp] brand or block.
 */
data class Club(
    val id: String, val lid: String, val name: String, val short: String = "", val nick: String = "",
    val city: String = "", val founded: String = "", val stadium: String = "", val cap: Int = 0,
    val mgr: String = "", val chair: String = "", val color: String = "#f5d400", val c2: String = "#1a7a2e",
    val logo: String = "", val titles: Int = 0, val w: Int = 0, val d: Int = 0, val l: Int = 0,
    val gf: Int = 0, val ga: Int = 0, val hon: String = "", val info: String = "", val logoBg: Boolean = false,
    val geo: String = "",             // map position as "lat, lon" (empty = looked up from the hometown)
    val grp: String = "",             // brand or block of the promotion this wrestler is in (empty = none)
) {
    fun played() = w + d + l
}

/** A match between two wrestlers or teams. [ev] is the show it is on, [st] the match type or stipulation. */
data class Fixture(
    val id: String, val lid: String, val home: String, val away: String, val at: Long, val venue: String = "",
    val ev: String = "", val st: String = "",
)

/** A member of a wrestler's stable or team. [pos] is the card position: ME main event, UC upper card, MC mid card, LC lower card, MG manager. */
data class Player(val id: String, val cid: String, val name: String, val num: Int = 0, val pos: String = "MC", val img: String = "")

/** One place on the ring board (in the ring or backstage). Either linked to a stable member ([pid]) or typed in freely. */
data class LineSlot(val pid: String = "", val name: String = "", val num: String = "", val img: String = "")

/** A storyline arrow drawn on the ring (coordinates are percentages of the board). kind: run (attack) | pass (alliance) | press (betrayal). */
data class Arrow(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val kind: String)

data class Lineup(
    val cid: String, val fm: String = "4-3-3", val mn: String = "B", val wd: String = "M",
    val xi: List<LineSlot> = List(11) { LineSlot(num = (it + 1).toString()) },
    val bench: List<LineSlot> = List(7) { LineSlot(num = (it + 12).toString()) },
    val px: List<Float> = emptyList(), val py: List<Float> = emptyList(),      // dragged positions (empty = formation layout)
    val duty: List<String> = List(11) { "" },                                 // per wrestler: "" | F (face) | H (heel) | T (tweener)
    val arrows: List<Arrow> = emptyList(),
    val tempo: String = "N", val press: String = "M", val line: String = "N",
    val pitch: String = "grass",      // mat look: grass (arena blue) | mowed (crimson) | night (black) | chalk | paper (canvas) | blueprint
    val snap: String = "S",           // dragging: O (free) | G (grid) | S (smart guides)
    val depth: String = "M",          // distance between the lines: T (tight) | M | L (stretched)
    val label: String = "N",          // text under a player: N name | S surname | B number and surname | R role
    val tokens: String = "R",         // R render when there is one | C always a numbered circle
    val view: String = "P",           // P perspective ring | F flat top-down ring
)

/** A group of countries that share one promotion (for example Scandinavia). A promotion whose country is the region's name belongs to it. */
class Region(val id: String, val name: String, val countries: List<String>)

/** A tournament or alliance with wrestlers from many promotions (G1 Climax, Royal Rumble, Forbidden Door). It only lists wrestlers; it is not a promotion. */
data class Super(
    val id: String, val name: String, val short: String = "", val cont: String = "",
    val color: String = "#1d4ed8", val logo: String = "", val clubs: List<String> = emptyList(), val note: String = "",
)

fun leagueGroups(l: League): List<String> = l.groups.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()

data class Data(
    val s: Settings, val leagues: List<League>, val clubs: List<Club>,
    val fixtures: List<Fixture> = emptyList(), val pick: String = "",
    val players: List<Player> = emptyList(), val lineups: List<Lineup> = emptyList(),
    val regions: List<Region> = emptyList(),
    val supers: List<Super> = emptyList(),
)

fun String.i() = toIntOrNull() ?: 0
fun ab(name: String, short: String) = short.ifBlank { name.take(3) }.uppercase()

val COUNTRIES = listOf(
    "USA" to "US", "Japan" to "JP", "Mexico" to "MX", "England" to "GB", "Scotland" to "GB", "Wales" to "GB", "Northern Ireland" to "GB",
    "Ireland" to "IE", "Canada" to "CA", "Germany" to "DE", "Australia" to "AU", "Puerto Rico" to "PR", "Dominican Republic" to "DO",
    "France" to "FR", "Spain" to "ES", "Italy" to "IT", "Austria" to "AT", "Switzerland" to "CH", "Netherlands" to "NL", "Belgium" to "BE",
    "Sweden" to "SE", "Norway" to "NO", "Denmark" to "DK", "Finland" to "FI", "Poland" to "PL", "Czechia" to "CZ", "Hungary" to "HU",
    "Romania" to "RO", "Serbia" to "RS", "Croatia" to "HR", "Greece" to "GR", "Turkey" to "TR", "Portugal" to "PT", "Ukraine" to "UA",
    "Brazil" to "BR", "Argentina" to "AR", "Chile" to "CL", "Colombia" to "CO", "Cuba" to "CU", "Jamaica" to "JM",
    "South Korea" to "KR", "China" to "CN", "India" to "IN", "Philippines" to "PH", "Singapore" to "SG", "New Zealand" to "NZ",
    "Samoa" to "WS", "Tonga" to "TO", "Fiji" to "FJ", "Saudi Arabia" to "SA", "Egypt" to "EG", "Morocco" to "MA",
    "Nigeria" to "NG", "South Africa" to "ZA",
)

/** Flag emoji for a known country name (with a trailing space), or "". */
fun flag(name: String): String {
    val code = COUNTRIES.find { it.first.equals(name.trim(), true) }?.second ?: return ""
    return buildString { code.forEach { appendCodePoint(127397 + it.code) } } + " "
}

/** "Today 19:00", "Tomorrow 19:00", "Sun 19:00" within a week, otherwise "12 Oct 19:00". */
fun fmtFixture(at: Long): String {
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(at).atZone(zone)
    val days = ChronoUnit.DAYS.between(LocalDate.now(zone), dt.toLocalDate())
    val time = dt.format(DateTimeFormatter.ofPattern("HH:mm"))
    return when {
        days == 0L -> "Today $time"
        days == 1L -> "Tomorrow $time"
        days in 2..6 -> dt.format(DateTimeFormatter.ofPattern("EEE", Locale.getDefault())) + " " + time
        else -> dt.format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault())) + " " + time
    }
}

fun fmtDateTime(at: Long): String =
    Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", Locale.getDefault()))

fun League.toMap() = mapOf(
    "name" to name, "country" to country, "season" to season, "color" to color, "logo" to logo, "banner" to banner,
    "pw" to pw.toString(), "pd" to pd.toString(), "promo" to promo.toString(), "rel" to rel.toString(),
    "promoTo" to promoTo, "relTo" to relTo, "quals" to quals, "groups" to groups,
)

fun Club.toMap() = mapOf(
    "lid" to lid, "name" to name, "short" to short, "nick" to nick, "city" to city, "founded" to founded,
    "stadium" to stadium, "cap" to cap.toString(), "mgr" to mgr, "chair" to chair, "color" to color, "c2" to c2,
    "logo" to logo, "titles" to titles.toString(), "w" to w.toString(), "d" to d.toString(), "l" to l.toString(),
    "gf" to gf.toString(), "ga" to ga.toString(), "hon" to hon, "info" to info,
    "logoBg" to if (logoBg) "1" else "0", "geo" to geo, "grp" to grp,
)

fun Player.toMap() = mapOf("name" to name, "num" to num.toString(), "pos" to pos, "img" to img, "cid" to cid)

fun Fixture.toMap() = mapOf("lid" to lid, "home" to home, "away" to away, "at" to at.toString(), "venue" to venue, "ev" to ev, "st" to st)

fun seed(): Data {
    val sunday = LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.SUNDAY)).atTime(19, 0)
        .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    return Data(
        Settings(),
        listOf(
            League("a", "Iron Ring Pro", "USA", "1998", "#d62828", pw = 2, pd = 1, promo = 2, rel = 1, relTo = "b",
                quals = "Title picture|1|2|#f5b301\nContenders|3|4|#38bdf8", groups = "Thunder\nLightning"),
            League("b", "Sol y Lucha", "Mexico", "2003", "#0ea5a4", pw = 2, pd = 1, promo = 1, rel = 0, promoTo = "a"),
        ),
        listOf(
            Club("1", "a", "Marcus Steel", "MST", "The Iron Tribune", "Pittsburgh", "2011", "Steel Driver", 191, "Dana Holt", "Walt Brennan",
                "#d62828", "#ffffff", "", 3, 8, 1, 2, 9, 4, "3x Iron Ring World champion\n1x Tag Team champion",
                "A veteran powerhouse who built his name on long main events and a loud home crowd.", grp = "Thunder"),
            Club("2", "a", "Ava Locke", "AVL", "The Locksmith", "Chicago", "2015", "Lock Pick", 173, "Pete Vance", "Mei Sato",
                "#7c3aed", "#ffffff", "", 2, 7, 2, 1, 8, 3, "2x Women's champion\nKing of the Ring winner",
                "A submission specialist known for slow, clinical matches.", grp = "Lightning"),
            Club("3", "a", "Dante Cole", "DAC", "Bruiser", "Detroit", "2009", "Pit Stop Powerbomb", 198, "", "Gus Marlow",
                "#15803d", "#111111", "", 1, 5, 2, 3, 6, 6, "1x Intercontinental champion", "A brawler who is never far from a chair.", grp = "Thunder"),
            Club("4", "a", "Jin Takeda", "JTA", "The Comet", "Osaka", "2018", "Comet Drop", 178, "", "Ken Mori",
                "#0ea5e9", "#ffffff", "", 0, 4, 1, 4, 7, 8, "", "A high flyer on a hot streak.", grp = "Lightning"),
            Club("5", "b", "El Relampago", "ELR", "Rey del Trueno", "Guadalajara", "2012", "Rayo Final", 170, "Tio Chuy", "Don Marcelo",
                "#facc15", "#0f172a", "", 4, 6, 1, 1, 10, 3, "4x Sol y Lucha champion", "A masked legend of the Mexican scene."),
        ),
        listOf(Fixture("f1", "a", "1", "2", sunday, "Harbor Dome", "Iron Ring: Showdown", "Steel cage")),
        "",
    )
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("ringbook", Context.MODE_PRIVATE)
    private fun JSONArray?.objs(): List<JSONObject> = if (this == null) emptyList() else List(length()) { getJSONObject(it) }

    fun load(c: Context): Data = runCatching { fromJson(JSONObject(prefs(c).getString("data", null)!!)) }.getOrElse { seed() }
    fun save(c: Context, d: Data) { prefs(c).edit().putString("data", toJson(d).toString()).apply() }

    // safety copy taken right before a backup is restored, so the restore can be undone
    fun savePrev(c: Context, d: Data) { prefs(c).edit().putString("prev", toJson(d).toString()).apply() }
    fun loadPrev(c: Context): Data? = runCatching { fromJson(JSONObject(prefs(c).getString("prev", null)!!)) }.getOrNull()
    fun hasPrev(c: Context) = prefs(c).getString("prev", null) != null
    fun clearPrev(c: Context) { prefs(c).edit().remove("prev").apply() }
    fun lastBackup(c: Context) = prefs(c).getLong("lastBackup", 0L)
    fun setLastBackup(c: Context, t: Long) { prefs(c).edit().putLong("lastBackup", t).apply() }

    fun settingsToJson(s: Settings) = JSONObject()
        .put("ui", s.ui).put("theme", s.theme).put("acc", s.acc).put("g", s.g).put("gh", s.gh).put("surf", s.surf)
        .put("r", s.r).put("ring", s.ring).put("c", s.c).put("f", s.f).put("fs", s.fs).put("d", s.d)
        .put("nm", s.nm).put("navs", s.navs).put("lbl", s.lbl).put("cg", s.cg).put("lg", s.lg).put("sg", s.sg)
        .put("tc", s.tc).put("splash", s.splash).put("navCoral", true).put("swipeBack", s.swipeBack).put("swipeTabs", s.swipeTabs).put("fullscreen", s.fullscreen).put("tlogo", s.tlogo)
        .put("home", s.home).put("homeRows", s.homeRows).put("homeGap", s.homeGap).put("homeDepth", s.homeDepth).put("homeHide", s.homeHide.joinToString("|"))
        .put("cols", s.cols.joinToString(",")).put("fields", s.fields.joinToString(","))
        .put("blocks", s.blocks.joinToString(","))

    /** Reads settings from either format. [v] is the data format the JSON was written with. */
    fun settingsFromJson(s: JSONObject, v: Int): Settings {
        val b = Settings()
        fun set(k: String, def: Set<String>) = if (s.has(k)) s.optString(k).split(",").filter { it.isNotEmpty() }.toSet() else def
        val validNav = setOf("menu", "float", "labeled", "capsule", "tabs", "dial", "pill", "rail", "bubble", "arc", "dots", "drawer", "islands")
        if (v >= 2) return Settings(
            ui = s.optString("ui", b.ui), theme = s.optString("theme", b.theme), acc = s.optString("acc", b.acc), g = s.optString("g", b.g),
            gh = s.optString("gh", b.gh), surf = s.optString("surf", b.surf), r = s.optInt("r", b.r),
            ring = s.optInt("ring", b.ring), c = s.optString("c", b.c), f = s.optString("f", b.f), fs = s.optString("fs", b.fs),
            d = s.optString("d", b.d), nm = s.optString("nm", b.nm),
            // 2.0 "dock" was removed in 2.5. Before 2.6 Coral ignored the navigation choice, so a saved Coral look keeps its menu button.
            navs = s.optString("navs", b.navs).let { if (it in validNav) it else b.navs }
                .let { if (s.optString("ui", b.ui) == "coral" && !s.has("navCoral")) "menu" else it },
            lbl = s.optString("lbl", b.lbl), cg = s.optString("cg", b.cg), lg = s.optString("lg", b.lg),
            sg = s.optString("sg", b.sg), tc = s.optString("tc", b.tc), splash = s.optBoolean("splash", b.splash),
            swipeBack = s.optBoolean("swipeBack", b.swipeBack), swipeTabs = s.optBoolean("swipeTabs", b.swipeTabs), fullscreen = s.optBoolean("fullscreen", b.fullscreen), tlogo = s.optBoolean("tlogo", b.tlogo),
            home = s.optString("home", b.home), homeRows = s.optInt("homeRows", b.homeRows).coerceIn(2, 12),
            homeGap = s.optInt("homeGap", b.homeGap).coerceIn(0, 3), homeDepth = s.optString("homeDepth", b.homeDepth),
            homeHide = s.optString("homeHide", "").split("|").filter { it.isNotEmpty() }.toSet(),
            cols = set("cols", b.cols), fields = set("fields", b.fields),
            blocks = set("blocks", b.blocks).let { if (v < 3) it + BLOCKS_ADDED_V3 else it },
        )
        // ---- migration from the oldest settings layout
        val oldAcc = s.optString("acc", "#ffffff")
        val oldF = s.optString("f", "sans")
        val oldR = s.optInt("r", 22)
        val oldNav = s.optString("navs", "float")
        return Settings(
            theme = s.optString("theme", b.theme),
            acc = if (oldAcc.equals("#ffffff", true)) b.acc else oldAcc,
            g = s.optString("g", b.g),
            r = if (oldR == 22) b.r else oldR,
            ring = s.optInt("ring", b.ring),
            c = s.optString("c", b.c),
            f = if (oldF == "sans") "manrope" else oldF,
            fs = s.optString("fs", b.fs),
            d = s.optString("d", b.d),
            nm = s.optString("nm", b.nm),
            navs = "float",
            cg = if (s.optString("cl", "list") == "grid") "g2" else "list",
            lg = s.optString("lay", "cards"),
            cols = set("cols", b.cols).filter { k -> ALL_COLS.any { it.first == k } }.toSet(),
            fields = set("fields", b.fields).filter { k -> ALL_FIELDS.any { it.first == k } }.toSet(),
        )
    }

    fun toJson(d: Data, imageName: (String) -> String = { it }): JSONObject = JSONObject()
        .put("app", "Ringbook").put("v", DATA_FORMAT)
        .put("s", settingsToJson(d.s)).put("pick", d.pick)
        .put("leagues", JSONArray(d.leagues.map {
            JSONObject().put("id", it.id).put("name", it.name).put("country", it.country).put("season", it.season)
                .put("color", it.color).put("logo", imageName(it.logo)).put("banner", imageName(it.banner))
                .put("pw", it.pw).put("pd", it.pd).put("promo", it.promo).put("rel", it.rel)
                .put("promoTo", it.promoTo).put("relTo", it.relTo).put("quals", it.quals).put("groups", it.groups)
        }))
        .put("clubs", JSONArray(d.clubs.map {
            JSONObject().put("id", it.id).put("lid", it.lid).put("name", it.name).put("short", it.short).put("nick", it.nick)
                .put("city", it.city).put("founded", it.founded).put("stadium", it.stadium).put("cap", it.cap)
                .put("mgr", it.mgr).put("chair", it.chair).put("color", it.color).put("c2", it.c2).put("logo", imageName(it.logo))
                .put("titles", it.titles).put("w", it.w).put("d", it.d).put("l", it.l).put("gf", it.gf).put("ga", it.ga)
                .put("hon", it.hon).put("info", it.info).put("logoBg", it.logoBg).put("geo", it.geo).put("grp", it.grp)
        }))
        .put("fixtures", JSONArray(d.fixtures.map {
            JSONObject().put("id", it.id).put("lid", it.lid).put("home", it.home).put("away", it.away)
                .put("at", it.at).put("venue", it.venue).put("ev", it.ev).put("st", it.st)
        }))
        .put("players", JSONArray(d.players.map {
            JSONObject().put("id", it.id).put("cid", it.cid).put("name", it.name).put("num", it.num)
                .put("pos", it.pos).put("img", imageName(it.img))
        }))
        .put("lineups", JSONArray(d.lineups.map { lineupToJson(it, imageName) }))
        .put("regions", JSONArray(d.regions.map { JSONObject().put("id", it.id).put("name", it.name).put("countries", JSONArray(it.countries)) }))
        .put("supers", JSONArray(d.supers.map {
            JSONObject().put("id", it.id).put("name", it.name).put("short", it.short).put("cont", it.cont).put("color", it.color)
                .put("logo", imageName(it.logo)).put("clubs", JSONArray(it.clubs)).put("note", it.note)
        }))

    /** Reads current data. Unknown or missing fields fall back to defaults. */
    fun fromJson(o: JSONObject, imagePath: (String) -> String = { it }): Data {
        val v = o.optInt("v", 1)
        val sObj = o.optJSONObject("s") ?: JSONObject()
        return Data(
            settingsFromJson(sObj, v),
            o.optJSONArray("leagues").objs().map {
                League(it.getString("id"), it.getString("name"), it.optString("country"), it.optString("season"),
                    it.optString("color", "#2da678"), imagePath(it.optString("logo")), imagePath(it.optString("banner")),
                    it.optInt("pw", 3), it.optInt("pd", 1), it.optInt("promo", 1), it.optInt("rel", 1),
                    it.optString("promoTo"), it.optString("relTo"), it.optString("quals"), it.optString("groups"))
            },
            o.optJSONArray("clubs").objs().map {
                Club(it.getString("id"), it.getString("lid"), it.getString("name"), it.optString("short"), it.optString("nick"),
                    it.optString("city"), it.optString("founded"), it.optString("stadium"), it.optInt("cap"), it.optString("mgr"),
                    it.optString("chair"), it.optString("color", "#f5d400"), it.optString("c2", "#1a7a2e"),
                    imagePath(it.optString("logo")), it.optInt("titles"), it.optInt("w"), it.optInt("d"), it.optInt("l"),
                    it.optInt("gf"), it.optInt("ga"), it.optString("hon"), it.optString("info"), it.optBoolean("logoBg"), it.optString("geo"), it.optString("grp"))
            },
            o.optJSONArray("fixtures").objs().map {
                Fixture(it.getString("id"), it.getString("lid"), it.getString("home"), it.getString("away"),
                    it.optLong("at"), it.optString("venue"), it.optString("ev"), it.optString("st"))
            },
            o.optString("pick"),
            o.optJSONArray("players").objs().map {
                Player(it.getString("id"), it.getString("cid"), it.optString("name"), it.optInt("num"),
                    it.optString("pos", "MC"), imagePath(it.optString("img")))
            },
            o.optJSONArray("lineups").objs().map { lineupFromJson(it, imagePath) },
            o.optJSONArray("regions").objs().map { r ->
                val a = r.optJSONArray("countries")
                Region(r.getString("id"), r.optString("name"), if (a == null) emptyList() else List(a.length()) { a.getString(it) })
            },
            o.optJSONArray("supers").objs().map { r ->
                val a = r.optJSONArray("clubs")
                Super(
                    r.getString("id"), r.optString("name"), r.optString("short"), r.optString("cont"), r.optString("color", "#1d4ed8"),
                    imagePath(r.optString("logo")), if (a == null) emptyList() else List(a.length()) { a.getString(it) }, r.optString("note"),
                )
            },
        )
    }

    private fun slotToJson(s: LineSlot, im: (String) -> String) =
        JSONObject().put("pid", s.pid).put("name", s.name).put("num", s.num).put("img", im(s.img))

    private fun slotFromJson(o: JSONObject, ip: (String) -> String) =
        LineSlot(o.optString("pid"), o.optString("name"), o.optString("num"), ip(o.optString("img")))

    fun lineupToJson(l: Lineup, im: (String) -> String = { it }): JSONObject = JSONObject()
        .put("cid", l.cid).put("fm", l.fm).put("mn", l.mn).put("wd", l.wd)
        .put("xi", JSONArray(l.xi.map { slotToJson(it, im) })).put("bench", JSONArray(l.bench.map { slotToJson(it, im) }))
        .put("px", JSONArray(l.px.map { it.toDouble() })).put("py", JSONArray(l.py.map { it.toDouble() }))
        .put("duty", JSONArray(l.duty))
        .put("arrows", JSONArray(l.arrows.map {
            JSONObject().put("x1", it.x1.toDouble()).put("y1", it.y1.toDouble()).put("x2", it.x2.toDouble())
                .put("y2", it.y2.toDouble()).put("kind", it.kind)
        }))
        .put("tempo", l.tempo).put("press", l.press).put("line", l.line)
        .put("pitch", l.pitch).put("snap", l.snap).put("depth", l.depth).put("label", l.label).put("tokens", l.tokens).put("view", l.view)

    fun lineupFromJson(o: JSONObject, ip: (String) -> String = { it }): Lineup {
        fun floats(k: String): List<Float> = o.optJSONArray(k)?.let { a -> List(a.length()) { a.optDouble(it).toFloat() } } ?: emptyList()
        val xiRaw = o.optJSONArray("xi").objs().map { slotFromJson(it, ip) }
        val benchRaw = o.optJSONArray("bench").objs().map { slotFromJson(it, ip) }
        val dutyRaw = o.optJSONArray("duty")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList()
        val px = floats("px"); val py = floats("py")
        return Lineup(
            cid = o.getString("cid"), fm = o.optString("fm", "4-3-3"), mn = o.optString("mn", "B"), wd = o.optString("wd", "M"),
            xi = List(11) { xiRaw.getOrNull(it) ?: LineSlot(num = (it + 1).toString()) },
            bench = List(7) { benchRaw.getOrNull(it) ?: LineSlot(num = (it + 12).toString()) },
            px = if (px.size == 11 && py.size == 11) px else emptyList(), py = if (px.size == 11 && py.size == 11) py else emptyList(),
            duty = List(11) { dutyRaw.getOrNull(it) ?: "" },
            arrows = o.optJSONArray("arrows").objs().map {
                Arrow(it.optDouble("x1").toFloat(), it.optDouble("y1").toFloat(), it.optDouble("x2").toFloat(), it.optDouble("y2").toFloat(), it.optString("kind", "run"))
            },
            tempo = o.optString("tempo", "N"), press = o.optString("press", "M"), line = o.optString("line", "N"),
            pitch = o.optString("pitch", "grass"), snap = o.optString("snap", "S"), depth = o.optString("depth", "M"),
            label = o.optString("label", "N"), tokens = o.optString("tokens", "R"), view = o.optString("view", "P"),
        )
    }
}
