package com.ringbook.app

// =====================================================================================================
// Continents: which continent a country belongs to, so a tournament can offer the wrestlers of its
// own continent. Countries that are not in the list simply have no continent and show under "Other".
// =====================================================================================================

object Continents {
    const val EUROPE = "Europe"
    const val ASIA = "Asia"
    const val AFRICA = "Africa"
    const val NA = "North America"
    const val SA = "South America"
    const val OCEANIA = "Oceania"
    val ALL = listOf(EUROPE, ASIA, AFRICA, NA, SA, OCEANIA)

    private fun m(c: String, names: String) = names.split(",").map { it.trim().lowercase() to c }

    private val MAP: Map<String, String> = (
        m(EUROPE, "Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bosnia, Bulgaria, Croatia, Cyprus, Czechia, Czech Republic, Denmark, England, Estonia, Faroe Islands, Finland, France, Georgia, Germany, Gibraltar, Greece, Hungary, Iceland, Ireland, Republic of Ireland, Northern Ireland, Israel, Italy, Kazakhstan, Kosovo, Latvia, Liechtenstein, Lithuania, Luxembourg, Malta, Moldova, Monaco, Montenegro, Netherlands, North Macedonia, Macedonia, Norway, Poland, Portugal, Romania, Russia, San Marino, Scotland, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Türkiye, Ukraine, United Kingdom, Wales, Vatican City") +
        m(ASIA, "Afghanistan, Bahrain, Bangladesh, Bhutan, Brunei, Cambodia, China, Hong Kong, India, Indonesia, Iran, Iraq, Japan, Jordan, Kuwait, Kyrgyzstan, Laos, Lebanon, Malaysia, Maldives, Mongolia, Myanmar, Nepal, North Korea, Oman, Pakistan, Palestine, Philippines, Qatar, Saudi Arabia, Singapore, South Korea, Korea Republic, Sri Lanka, Syria, Taiwan, Tajikistan, Thailand, Timor-Leste, Turkmenistan, United Arab Emirates, UAE, Uzbekistan, Vietnam, Yemen") +
        m(AFRICA, "Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Cabo Verde, Central African Republic, Chad, Comoros, Congo, DR Congo, Democratic Republic of the Congo, Ivory Coast, Cote d'Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Gabon, Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, South Sudan, Sudan, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe") +
        m(NA, "United States, USA, Canada, Mexico, Costa Rica, Cuba, Dominican Republic, El Salvador, Guatemala, Haiti, Honduras, Jamaica, Nicaragua, Panama, Trinidad and Tobago, Puerto Rico, Bahamas, Barbados, Belize, Curacao, Curaçao, Suriname") +
        m(SA, "Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Uruguay, Venezuela") +
        m(OCEANIA, "Australia, New Zealand, Fiji, Papua New Guinea, Samoa, Solomon Islands, Tahiti, Tonga, Vanuatu, New Caledonia")
        ).toMap()

    /** The continent of a country name, or "" when it is not known. */
    fun of(country: String): String = MAP[country.trim().lowercase()] ?: ""

    /** The continent of a promotion's country; a region counts as the continent of its first country. */
    fun ofLeague(vm: AppVM, l: League): String {
        val r = vm.regionFor(l.country)
        return if (r != null) r.countries.firstNotNullOfOrNull { of(it).ifBlank { null } } ?: "" else of(l.country)
    }
}
