# Ringbook 1.0.0

A pro-wrestling sandbox for Android (Jetpack Compose), built from Matchbook. Add wrestlers, tag teams and
promotions by hand, or fetch them from the web (Wikipedia, Wikidata, TheSportsDB, Wikimedia Commons).

Open in Android Studio, let Gradle sync, press Run. GitHub Actions builds the APK via
.github/workflows (artifact: ringbook-apk).

## What changed from Matchbook
- Wrestlers replace clubs, promotions replace leagues, matches replace fixtures, rankings replace the table
- Brands or blocks (Raw / SmackDown, Block A / B) replace groups; tournaments (Royal Rumble, G1 Climax...) replace superleagues
- A stable (members with a card position) replaces the squad; the ring board replaces the lineup pitch
- Fill from the web: wrestler (hometown with map position, height, debut, trainer, photo, About), promotion (country, founded, logo)
- Photos by year from Wikimedia Commons and cut-outs from TheSportsDB when available
- The world map pins wrestlers at their hometown
- Different app id, so it installs next to Matchbook; backups use the same ZIP format
