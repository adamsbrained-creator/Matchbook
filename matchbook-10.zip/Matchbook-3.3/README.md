# Matchbook 3.3

Track clubs, leagues, tables, fixtures, squads, lineups and tactics. Jetpack Compose app.

Open in Android Studio, let Gradle sync, press Run. GitHub Actions builds the APK via
.github/workflows (artifact: matchbook-apk).

## What's new in 3.3
- Home: the app now starts on a Home page. A dotted map fills the top with a pin for every country that has leagues (the number is its clubs); tap a pin, a lit country or a chip to switch country. The sheet below shows its clubs (tap one to open it), the next match and the top of the league table with its qualification colours. The globe button opens the full World map
- Home is the first item in every navigation style, in the Coral menu and in the swipe order. The Add and Settings pages are unchanged
- The World map is drawn as dots instead of filled shapes. Countries with leagues are lime, the chosen one is bigger, and its border is still outlined
- Crimea is part of Ukraine on the map, so clubs from Simferopol are placed there. The map data is the same file as before, the change is made when it is read
- Labeled dock: the raised Add button now sits in its own slot, since there are six destinations

## What's new in 3.2
- Clubs: new "Plain" look, a list or grid with no card background, just crest, name and league on the page itself. On the Clubs page choose Cards / Plain next to the sort menu; Settings > Pages and grids has "Plain list" and "Plain grid"

## What's new in 3.1
- World map page (Menu > World map in Coral, or the globe button on the Leagues page): real country shapes with borders, pinch to zoom and drag to move
- Countries that have a league light up and carry a pin with the number of leagues; nearby pins merge into a numbered cluster, tap it to zoom in
- Tap a country (or its pin, or its row in the list): its border is outlined, the map zooms to it and its leagues open below. England, Scotland, Wales and Northern Ireland are separate areas
- Tap a league: its table (with qualification badges) opens and its clubs appear on the map, placed by their city. Tap a club pin to open the club
- The map outlines (Natural Earth 1:50m) download once on first use, about 750 KB, and are kept on the phone. Club cities are looked up with Open-Meteo's free geocoding and remembered

## What's new in 3.0
- Tables can show club logos instead of colour dots (switch on the Table page, or Settings > Table columns)
- Qualification spots: in the league form add named badges for places in the table (e.g. Champions League places 1-4, Europa League 5, Conference League 6), each with its own colour. They show as a coloured edge and a small label under the club, plus a legend under the full table. One tap adds the usual three
- Promotion and relegation colours still apply to places no qualification spot covers

## What's new in 2.9.1
- Fixed "HTTP 403" in Fill from the web (and the online player search): TheSportsDB retired its old free key, the app now uses the current one
- If TheSportsDB is unreachable or finds nothing, Fill from the web falls back to Wikipedia (About text, crest, manager, chairman, founded)

## What's new in 2.9
- Screens ease in (short fade and rise) instead of snapping
- Honours show as a tidy bulleted list on the club page
- Fixtures: "Next up" label on the coming match, played matches are softened
- Friendlier empty states with a pitch icon

## What's new in 2.8
- "Fill from the web" on the club form: type a club (e.g. Liverpool), pick it, and name, short name, nickname, city, founded, stadium, capacity, manager, chairman, colours, crest and an About text are filled in. Everything stays editable
- Sources: TheSportsDB (details, crest), Wikipedia (About), Wikidata (manager, chairman). Honours and the titles count are not provided by these sources, so they stay yours to write

## What's new in 2.7
- Gestures from Paperback: swipe right to go back, optional swipe between the main pages, long-press menus on clubs, leagues, fixtures and players
- Lineup builder rebuilt: one touch layer for the whole board, the dragged player floats under the finger, no recomposition while dragging, downsized render cache
- Dropping a player on another swaps them (bench included); dropping on open grass places him exactly where released
- New pitch (stripes, boxes, arcs), rounder tokens, selection halo and a cleaner bench

## What's new in 2.6
- Coral rebuilt on Paperback's design: white page (black in dark), flat soft-grey cards, ink text, coral accent (#f46c4e)
- All twelve navigation styles now work in Coral, in Coral colours. "Menu button" is Coral's own default (Settings > Navigation)
- Paperback-style segmented switch, chips, fields, dialogs, menus, message pill and Menu page
- Existing Coral setups keep their menu button after the update; switching to Coral selects it, switching back selects the floating bar
- Header glow / height / surface options are hidden in Coral (they only apply to Glass)

## What's new in 2.5
- Squad per club, lineup builder (16 formations, drag to position or swap, bench) and a tactics mode (arrows, duties, team instructions)
- Coral interface as an alternative to the Glass look (Settings > Appearance > Interface style, or the "Coral" preset)
- Eleven extra navigation bars (Settings > Navigation); the 2.0 "Docked" option was removed
- Pitch app icon, refreshed icon set, Pitch launch screen
- Data format 3 (squads, lineups, tactics); 2.0 data and backups still load

## Online catalog (added after 2.5)
"Find online" in the player editor and in the lineup slot editor (Online.kt). Needs the INTERNET permission (added to the manifest).
- TheSportsDB (free test key "3"): names, positions, cut-outs / renders / photos
- Wikimedia Commons: real photos labelled by year (free licences), newest first
- Fantasy Premier League (public, unofficial): official PL render, this-season stats, last 5 matches, past seasons. Premier League only
Pick a picture and it goes through the normal crop dialog and ImageStore, so it is saved locally and travels in backups.
Stats are shown, not stored, so the data format is unchanged.

## Lineup renders
A player with a render on the lineup pitch or bench is drawn as the bare render with a name label (no circle); transparent PNG
cut-outs look best. Without a render (or if the file can't be read) the numbered circle is used.

## Settings layout
Settings is a short hub (summary card + grouped rows: LOOK, PAGES, DATA, About), modelled on Paperback's settings. Each row opens its own
page (Screen.SettingsSubS in AppVM, pages in SettingsScreen.kt: look, style, text, nav, pages, blocks, cols, fields, backup, data, about).
To add a setting: put the control on the matching page and, if it should show as the row's value, update the value text in SettingsScreen().

## Upgrading
Same app id (com.matchbook.app): 2.5 installs over 2.0/1.x and keeps your data. Settings and data are migrated
automatically (Store.settingsFromJson / Store.fromJson). Make a backup first (Settings > Backup and restore).

## Backups
One ZIP (data.json + images/). data.json carries a format number (DATA_FORMAT in Models.kt, now 3). New versions read
older formats; a backup from a newer format is refused with a clear message. When you change the JSON layout:
bump DATA_FORMAT and add a migration step.

## Optional fonts
Drop into app/src/main/res/font (lowercase names, picked up automatically):
manrope.ttf (Glass default), outfit.ttf (Coral), anton.ttf (Condensed headings), inter.ttf, nunito.ttf (Rounded).
Variable fonts work. Without them the app uses system fonts.
