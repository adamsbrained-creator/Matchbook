package com.matchbook.app

import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.PathOperation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// =====================================================================================================
// World geometry (3.1): real country shapes for the World map page.
//   Natural Earth 1:50m countries, packaged as TopoJSON by the "world-atlas" project (public domain).
//   Downloaded once on first use (about 750 KB, from jsDelivr, then unpkg) and kept in the app's files,
//   so the map works offline afterwards and is not part of the APK or of your backups.
//   Crimea is moved from Russia to Ukraine.
//   England, Scotland, Wales and Northern Ireland are cut out of the United Kingdom shape, because
//   leagues are filed under them.
// =====================================================================================================

/** One tappable area. Coordinates are degrees: x = longitude, and y = minus latitude, so a Path can be drawn as is. */
class GeoShape(
    val key: String,
    val label: String,
    val path: Path,
    val bbox: FloatArray,        // minLon, minLat, maxLon, maxLat of everything in the shape
    val focus: FloatArray,       // the same for its main landmass (used to zoom to it)
    val center: Offset,          // lon, lat for its pin
    val test: (Float, Float) -> Boolean,
)

object WorldGeo {
    private const val FILE = "world-50m.json"
    private val URLS = listOf(
        "https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-50m.json",
        "https://unpkg.com/world-atlas@2.0.2/countries-50m.json",
    )

    @Volatile private var cache: List<GeoShape>? = null
    fun cached(): List<GeoShape>? = cache

    suspend fun load(ctx: Context): List<GeoShape>? = withContext(Dispatchers.IO) {
        cache?.let { return@withContext it }
        val f = File(ctx.filesDir, FILE)
        var text: String? = if (f.exists() && f.length() > 10_000) runCatching { f.readText() }.getOrNull() else null
        if (text == null) {
            for (u in URLS) {
                text = runCatching { String(OlNet.bytes(u), Charsets.UTF_8) }.getOrNull()
                if (text != null && text.length > 10_000) { runCatching { f.writeText(text!!) }; break } else text = null
            }
        }
        val t = text ?: return@withContext null
        val shapes = runCatching { parse(t) }.getOrNull()
        if (shapes != null) cache = shapes else f.delete()
        shapes
    }

    // ------------------------------------------------------------------------------------ names
    private val ALIASES = mapOf(
        "usa" to "united states of america", "us" to "united states of america", "united states" to "united states of america",
        "america" to "united states of america", "uk" to "england", "great britain" to "england", "britain" to "england",
        "czech republic" to "czechia", "holland" to "netherlands", "ivory coast" to "côte d'ivoire", "cote d'ivoire" to "côte d'ivoire",
        "bosnia" to "bosnia and herz.", "bosnia and herzegovina" to "bosnia and herz.", "macedonia" to "north macedonia",
        "dr congo" to "dem. rep. congo", "congo dr" to "dem. rep. congo", "korea" to "south korea", "korea republic" to "south korea",
        "uae" to "united arab emirates", "russian federation" to "russia", "turkiye" to "turkey", "türkiye" to "turkey",
        "republic of ireland" to "ireland", "eire" to "ireland", "northern ireland" to "northern ireland", "cabo verde" to "cape verde",
        "eswatini" to "eswatini", "swaziland" to "eswatini", "myanmar" to "myanmar", "burma" to "myanmar",
    )

    /** The shape for a country name as typed in a league ("England", "USA", "Czech Republic"), or null. */
    fun find(shapes: List<GeoShape>?, country: String): GeoShape? {
        if (shapes == null) return null
        val n = country.trim().lowercase()
        if (n.isEmpty()) return null
        val want = ALIASES[n] ?: n
        return shapes.firstOrNull { it.key == want } ?: shapes.firstOrNull { it.key.startsWith(want) && want.length >= 5 }
    }

    // ------------------------------------------------------------------------------------ parsing
    private class Feature(val name: String, val polys: List<List<FloatArray>>)

    private fun reversed(a: FloatArray): FloatArray {
        val n = a.size / 2
        val o = FloatArray(a.size)
        for (i in 0 until n) { o[2 * i] = a[2 * (n - 1 - i)]; o[2 * i + 1] = a[2 * (n - 1 - i) + 1] }
        return o
    }

    private fun parse(text: String): List<GeoShape> {
        val root = JSONObject(text)
        val tr = root.getJSONObject("transform")
        val sc = tr.getJSONArray("scale"); val tl = tr.getJSONArray("translate")
        val sx = sc.getDouble(0); val sy = sc.getDouble(1); val tx = tl.getDouble(0); val ty = tl.getDouble(1)
        val aj = root.getJSONArray("arcs")
        val arcs = Array(aj.length()) { i ->
            val a = aj.getJSONArray(i)
            val out = FloatArray(a.length() * 2)
            var x = 0L; var y = 0L
            for (k in 0 until a.length()) {
                val p = a.getJSONArray(k)
                x += p.getLong(0); y += p.getLong(1)
                out[2 * k] = (x * sx + tx).toFloat(); out[2 * k + 1] = (y * sy + ty).toFloat()
            }
            out
        }
        fun ring(idx: JSONArray): FloatArray {
            val parts = ArrayList<FloatArray>()
            var total = 0
            for (j in 0 until idx.length()) {
                val ai = idx.getInt(j)
                val arc = if (ai >= 0) arcs[ai] else reversed(arcs[ai.inv()])
                val use = if (j == 0) arc else arc.copyOfRange(2, arc.size)
                parts.add(use); total += use.size
            }
            val out = FloatArray(total)
            var o = 0
            for (p in parts) { System.arraycopy(p, 0, out, o, p.size); o += p.size }
            return out
        }
        val geoms = root.getJSONObject("objects").getJSONObject("countries").getJSONArray("geometries")
        val feats = ArrayList<Feature>()
        for (i in 0 until geoms.length()) {
            val g = geoms.getJSONObject(i)
            val name = g.optJSONObject("properties")?.optString("name").orEmpty()
            if (name.isBlank() || name == "Antarctica") continue
            val polys = ArrayList<List<FloatArray>>()
            when (g.optString("type")) {
                "Polygon" -> { val a = g.getJSONArray("arcs"); polys.add((0 until a.length()).map { ring(a.getJSONArray(it)) }) }
                "MultiPolygon" -> {
                    val m = g.getJSONArray("arcs")
                    for (k in 0 until m.length()) { val a = m.getJSONArray(k); polys.add((0 until a.length()).map { ring(a.getJSONArray(it)) }) }
                }
                else -> continue
            }
            feats.add(Feature(name, polys))
        }
        val out = ArrayList<GeoShape>()
        for (f in moveCrimea(feats)) {
            if (f.name == "United Kingdom") out.addAll(ukParts(f)) else out.add(shapeOf(f.name.lowercase(), niceName(f.name), f.polys))
        }
        return out
    }

    /** Natural Earth files Crimea under Russia. Here it belongs to Ukraine (clubs like Tavriya are in the Ukrainian league). */
    private fun isCrimea(p: List<FloatArray>): Boolean {
        val b = bboxOf(listOf(p))
        return (b[0] + b[2]) / 2f in 32.3f..36.9f && (b[1] + b[3]) / 2f in 44.3f..46.4f && (b[2] - b[0]) < 6f
    }

    private fun moveCrimea(feats: List<Feature>): List<Feature> {
        val ru = feats.firstOrNull { it.name == "Russia" } ?: return feats
        val ua = feats.firstOrNull { it.name == "Ukraine" } ?: return feats
        val cr = ru.polys.filter { isCrimea(it) }
        if (cr.isEmpty()) return feats
        return feats.map { f ->
            when {
                f === ru -> Feature(f.name, f.polys.filter { p -> cr.none { it === p } })
                f === ua -> Feature(f.name, f.polys + cr)
                else -> f
            }
        }
    }

    private fun niceName(n: String) = when (n) { "United States of America" -> "USA"; else -> n }

    private fun bboxOf(polys: List<List<FloatArray>>): FloatArray {
        var a = 1e9f; var b = 1e9f; var c = -1e9f; var d = -1e9f
        for (p in polys) for (r in p) { var i = 0; while (i < r.size) { a = minOf(a, r[i]); c = maxOf(c, r[i]); b = minOf(b, r[i + 1]); d = maxOf(d, r[i + 1]); i += 2 } }
        return floatArrayOf(a, b, c, d)
    }

    private fun pathOf(polys: List<List<FloatArray>>): Path = Path().apply {
        fillType = PathFillType.EvenOdd
        for (p in polys) for (r in p) {
            if (r.size < 6) continue
            moveTo(r[0], -r[1])
            var i = 2
            while (i < r.size) { lineTo(r[i], -r[i + 1]); i += 2 }
            close()
        }
    }

    private fun inRing(r: FloatArray, x: Float, y: Float): Boolean {
        var c = false
        var j = r.size - 2
        var i = 0
        while (i < r.size) {
            val xi = r[i]; val yi = r[i + 1]; val xj = r[j]; val yj = r[j + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c
            j = i; i += 2
        }
        return c
    }

    private fun inPolys(polys: List<List<FloatArray>>, x: Float, y: Float): Boolean {
        var n = 0
        for (p in polys) for (r in p) if (inRing(r, x, y)) n++
        return n % 2 == 1
    }

    private fun shapeOf(key: String, label: String, polys: List<List<FloatArray>>): GeoShape {
        val box = bboxOf(polys)
        val main = polys.maxByOrNull { p -> val b = bboxOf(listOf(p)); (b[2] - b[0]) * (b[3] - b[1]) } ?: polys.first()
        val focus = bboxOf(listOf(main))
        val center = Offset((focus[0] + focus[2]) / 2f, (focus[1] + focus[3]) / 2f)
        return GeoShape(key, label, pathOf(polys), box, focus, center) { x, y ->
            x >= box[0] && x <= box[2] && y >= box[1] && y <= box[3] && inPolys(polys, x, y)
        }
    }

    // ------------------------------------------------------------------------------------ home nations
    // Rough borders (longitude, latitude) cut through the sea at their ends. Only the land part matters.
    private val SCOT = floatArrayOf(-4.2f, 54.4f, -3.45f, 54.88f, -3.05f, 54.99f, -2.6f, 55.3f, -2.0f, 55.77f, -1.2f, 55.9f, -1.0f, 61.5f, -9.5f, 61.5f, -9.5f, 54.4f)
    private val WALES = floatArrayOf(-6.5f, 53.8f, -3.3f, 53.7f, -3.17f, 53.38f, -2.95f, 53.0f, -3.05f, 52.9f, -3.0f, 52.5f, -3.1f, 52.3f, -2.9f, 52.0f, -2.75f, 51.85f, -2.67f, 51.64f, -3.0f, 51.33f, -4.0f, 51.4f, -6.5f, 51.4f)

    private fun regionPath(r: FloatArray): Path = Path().apply {
        moveTo(r[0], -r[1]); var i = 2
        while (i < r.size) { lineTo(r[i], -r[i + 1]); i += 2 }
        close()
    }

    private fun ukParts(f: Feature): List<GeoShape> {
        fun isNi(p: List<FloatArray>): Boolean { val b = bboxOf(listOf(p)); val cx = (b[0] + b[2]) / 2; val cy = (b[1] + b[3]) / 2; return cx in -8.3f..-5.3f && cy in 54.0f..55.4f && (b[2] - b[0]) > 0.8f }
        val ni = f.polys.filter { isNi(it) }
        val gbPolys = f.polys.filter { !isNi(it) }
        val gb = pathOf(gbPolys)
        val scotRegion = regionPath(SCOT); val walesRegion = regionPath(WALES)
        val scot = Path().also { it.op(gb, scotRegion, PathOperation.Intersect) }
        val wales = Path().also { it.op(gb, walesRegion, PathOperation.Intersect) }
        val both = Path().also { it.op(scotRegion, walesRegion, PathOperation.Union) }
        val england = Path().also { it.op(gb, both, PathOperation.Difference) }
        fun inGb(x: Float, y: Float) = inPolys(gbPolys, x, y)
        fun inScot(x: Float, y: Float) = inRing(SCOT, x, y)
        fun inWales(x: Float, y: Float) = inRing(WALES, x, y)
        val out = ArrayList<GeoShape>()
        out.add(GeoShape("england", "England", england, floatArrayOf(-6.4f, 49.9f, 1.8f, 55.8f), floatArrayOf(-5.8f, 49.9f, 1.8f, 55.8f), Offset(-1.5f, 52.6f)) { x, y -> inGb(x, y) && !inScot(x, y) && !inWales(x, y) })
        out.add(GeoShape("scotland", "Scotland", scot, floatArrayOf(-8.7f, 54.6f, -0.7f, 60.9f), floatArrayOf(-6.4f, 54.6f, -0.7f, 58.7f), Offset(-4.2f, 56.7f)) { x, y -> inGb(x, y) && inScot(x, y) })
        out.add(GeoShape("wales", "Wales", wales, floatArrayOf(-5.4f, 51.3f, -2.6f, 53.5f), floatArrayOf(-5.4f, 51.3f, -2.6f, 53.5f), Offset(-3.7f, 52.3f)) { x, y -> inGb(x, y) && inWales(x, y) })
        if (ni.isNotEmpty()) {
            val b = bboxOf(ni)
            out.add(GeoShape("northern ireland", "Northern Ireland", pathOf(ni), b, b, Offset(-6.7f, 54.6f)) { x, y -> inPolys(ni, x, y) })
        }
        return out
    }

    // ------------------------------------------------------------------------------------ places of clubs
    /** Longitude / latitude of a city (Open-Meteo geocoding, free, no key). Results are remembered on the phone. */
    suspend fun geocode(ctx: Context, city: String, country: String, near: FloatArray?): Pair<Float, Float>? = withContext(Dispatchers.IO) {
        val name = city.trim()
        if (name.isEmpty()) return@withContext null
        val sp = ctx.getSharedPreferences("geo", Context.MODE_PRIVATE)
        val key = name.lowercase() + "|" + country.trim().lowercase()
        sp.getString(key, null)?.let { v ->
            if (v == "none") return@withContext null
            val p = v.split(",")
            if (p.size == 2) return@withContext (p[0].toFloat() to p[1].toFloat())
        }
        val found = try {
            val j = OlNet.json("https://geocoding-api.open-meteo.com/v1/search?name=${OlNet.enc(name)}&count=10&language=en&format=json")
            val arr = j.optJSONArray("results")
            var pick: Pair<Float, Float>? = null
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lon = o.optDouble("longitude").toFloat(); val lat = o.optDouble("latitude").toFloat()
                val ok = near == null || (lon >= near[0] - 1f && lon <= near[2] + 1f && lat >= near[1] - 1f && lat <= near[3] + 1f)
                if (ok) { pick = lon to lat; break }
            }
            pick ?: if (arr != null && arr.length() > 0 && near == null) arr.getJSONObject(0).let { it.optDouble("longitude").toFloat() to it.optDouble("latitude").toFloat() } else null
        } catch (e: Exception) {
            return@withContext null     // network trouble: don't remember a miss
        }
        sp.edit().putString(key, found?.let { "${it.first},${it.second}" } ?: "none").apply()
        found
    }
}
