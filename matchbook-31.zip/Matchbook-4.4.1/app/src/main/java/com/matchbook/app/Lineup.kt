package com.matchbook.app

import androidx.compose.foundation.*
import android.graphics.BitmapFactory
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.PI
import android.view.WindowManager
import android.os.Build
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineStart
import androidx.compose.animation.core.AnimationVector2D
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.drawscope.clipPath

// =============================================================== formations (ported from the lineup builder mockup)
private val FM = linkedMapOf(
    "4-4-2" to listOf(4, 4, 2), "4-3-3" to listOf(4, 3, 3), "4-2-3-1" to listOf(4, 2, 3, 1), "4-1-4-1" to listOf(4, 1, 4, 1),
    "4-4-1-1" to listOf(4, 4, 1, 1), "4-3-2-1" to listOf(4, 3, 2, 1), "4-5-1" to listOf(4, 5, 1), "4-2-2-2" to listOf(4, 2, 2, 2),
    "4-1-2-1-2" to listOf(4, 1, 2, 1, 2), "3-5-2" to listOf(3, 5, 2), "3-4-3" to listOf(3, 4, 3), "3-4-2-1" to listOf(3, 4, 2, 1),
    "3-4-1-2" to listOf(3, 4, 1, 2), "5-3-2" to listOf(5, 3, 2), "5-4-1" to listOf(5, 4, 1), "5-2-3" to listOf(5, 2, 3),
)
val FORMATIONS: List<String> = FM.keys.toList()
private val SPREAD = mapOf(1 to 0f, 2 to 34f, 3 to 56f, 4 to 72f, 5 to 82f)
private fun mentShift(m: String) = when (m) { "D" -> 7f; "A" -> -7f; else -> 0f }
private fun widthScale(w: String) = when (w) { "N" -> .8f; "W" -> 1.15f; else -> 1f }

class PSlot(val x: Float, val y: Float, val role: String)

private fun roleLabels(r: List<Int>, i: Int): List<String> {
    val c = r[i]; val n = r.size; val k = n - 1 - i
    if (i == 0) return when (c) { 3 -> listOf("CB", "CB", "CB"); 4 -> listOf("LB", "CB", "CB", "RB"); else -> listOf("LWB", "CB", "CB", "CB", "RWB") }
    if (k == 0) return when (c) { 1 -> listOf("ST"); 2 -> listOf("ST", "ST"); else -> listOf("LW", "ST", "RW") }
    if (c == 1) return listOf(if (k == 1) "CAM" else "CDM")
    if (c == 2) return if (k == 1 && n >= 4) listOf("CAM", "CAM") else if (i == 1 && n >= 4) listOf("CDM", "CDM") else listOf("CM", "CM")
    if (c == 3) return if (k == 1 && r[n - 1] == 1) listOf("LW", "CAM", "RW") else listOf("CM", "CM", "CM")
    return if (c == 4) listOf("LM", "CM", "CM", "RM") else listOf("LM", "CM", "CM", "CM", "RM")
}

fun baseSlots(fm: String): List<PSlot> {
    val r = FM[fm] ?: FM.getValue("4-3-3")
    val n = r.size
    val out = ArrayList<PSlot>()
    out.add(PSlot(50f, 91f, "GK"))
    r.forEachIndexed { i, c ->
        val y = 76f - i * (60f / (n - 1))
        val sp = SPREAD[c] ?: 0f
        val labels = roleLabels(r, i)
        for (j in 0 until c) out.add(PSlot(if (c == 1) 50f else 50f - sp / 2f + j * sp / (c - 1), y, labels[j]))
    }
    return out
}

fun lineupSlots(l: Lineup): List<PSlot> {
    val base = baseSlots(l.fm)
    return if (l.px.size == 11 && l.py.size == 11) base.mapIndexed { i, s -> PSlot(l.px[i], l.py[i], s.role) } else base
}

private fun depthScale(d: String) = when (d) { "T" -> .86f; "L" -> 1.12f; else -> 1f }

/** Where a formation spot shows on the pitch (percent), after width, depth and mentality. */
private fun disp(s: PSlot, l: Lineup): Pair<Float, Float> {
    val x = (50f + (s.x - 50f) * widthScale(l.wd)).coerceIn(10f, 90f)
    val y = if (s.role == "GK") s.y else (50f + (s.y - 50f) * depthScale(l.depth) + mentShift(l.mn)).coerceIn(9f, 93f)
    return x to y
}

/** The opposite of [disp]: the formation spot that shows at pitch percent ([fx], [fy]). */
private fun unDisp(fx: Float, fy: Float, role: String, l: Lineup): Pair<Float, Float> {
    val x = 50f + (fx - 50f) / widthScale(l.wd)
    val y = if (role == "GK") fy else 50f + (fy - mentShift(l.mn) - 50f) / depthScale(l.depth)
    return x to y
}

/** Moves players to new shown spots ([moves]: starter index to pitch percent) and stores them as the lineup's own positions. */
private fun moveSpots(l: Lineup, slots: List<PSlot>, moves: Map<Int, Pair<Float, Float>>): Lineup {
    val nx = slots.mapIndexed { i, s -> moves[i]?.let { unDisp(it.first.coerceIn(10f, 90f), it.second.coerceIn(9f, 93f), s.role, l).first } ?: s.x }
    val ny = slots.mapIndexed { i, s -> moves[i]?.let { unDisp(it.first.coerceIn(10f, 90f), it.second.coerceIn(9f, 93f), s.role, l).second } ?: s.y }
    return l.copy(px = nx, py = ny)
}

/** The starters standing on the same line as [idx] (within about three percent of the pitch). */
private fun rowOf(l: Lineup, slots: List<PSlot>, idx: Int): List<Int> {
    val y0 = disp(slots[idx], l).second
    return slots.indices.filter { abs(disp(slots[it], l).second - y0) < 3.2f }
}

/** "Andrew Robertson" stays as it is, longer names become "T. Alexander-Arnold" so the name plate stays small. */
private fun shortName(n: String): String {
    val t = n.trim()
    val p = t.split(" ").filter { it.isNotEmpty() }
    return if (t.length > 14 && p.size >= 2) p.first().take(1) + ". " + p.drop(1).joinToString(" ") else t
}

/** The text under a player: name, surname, number and surname, or the role. */
private fun tokenText(slot: LineSlot, role: String, mode: String): String {
    val sur = slot.name.trim().substringAfterLast(' ')
    return when (mode) {
        "S" -> sur.ifBlank { role }
        "B" -> (slot.num + " " + sur).trim().ifBlank { role }
        "R" -> role
        else -> shortName(slot.name).ifBlank { role }
    }
}

private fun roleGroup(role: String) = when (role) {
    "GK" -> "GK"; "LB", "RB", "CB", "LWB", "RWB" -> "DEF"; "CDM", "CM", "CAM", "LM", "RM" -> "MID"; else -> "FWD"
}

private fun slotOf(l: Lineup, key: String): LineSlot = if (key.startsWith("p")) l.xi[key.drop(1).toInt()] else l.bench[key.drop(1).toInt()]

private fun withSlot(l: Lineup, key: String, s: LineSlot): Lineup {
    val i = key.drop(1).toInt()
    return if (key.startsWith("p")) l.copy(xi = l.xi.mapIndexed { n, o -> if (n == i) s else o })
    else l.copy(bench = l.bench.mapIndexed { n, o -> if (n == i) s else o })
}

private fun swapSlots(l: Lineup, a: String, b: String): Lineup {
    val sa = slotOf(l, a); val sb = slotOf(l, b)
    return withSlot(withSlot(l, a, sb), b, sa)
}

private fun fromPlayer(p: Player) = LineSlot(p.id, p.name, if (p.num > 0) p.num.toString() else "", p.img)

private fun autoFill(vm: AppVM, l: Lineup): Lineup {
    val squad = vm.playersOf(l.cid)
    val used = HashSet<String>()
    val slots = lineupSlots(l)
    val xi = slots.mapIndexed { i, s ->
        val g = roleGroup(s.role)
        val p = squad.firstOrNull { it.id !in used && it.pos == g } ?: squad.firstOrNull { it.id !in used }
        if (p != null) { used.add(p.id); fromPlayer(p) } else LineSlot(num = (i + 1).toString())
    }
    val bench = List(7) { i ->
        val p = squad.firstOrNull { it.id !in used }
        if (p != null) { used.add(p.id); fromPlayer(p) } else LineSlot(num = (i + 12).toString())
    }
    return l.copy(xi = xi, bench = bench)
}

private fun styleSummary(l: Lineup): String {
    val tempo = when (l.tempo) { "S" -> "Slow tempo"; "F" -> "Fast tempo"; else -> "Normal tempo" }
    val press = when (l.press) { "L" -> "Low press"; "H" -> "High press"; else -> "Mid press" }
    val line = when (l.line) { "D" -> "Deep line"; "H" -> "High line"; else -> "Normal line" }
    val ment = when (l.mn) { "D" -> "Defensive"; "A" -> "Attacking"; else -> "Balanced" }
    return "$ment · $tempo · $press · $line"
}

private val RunColor = Color.White
private val PassColor = Color(0xFFFFE066)
private val PressColor = Color(0xFFF46C4E)

private fun DrawScope.drawArrow(from: Offset, to: Offset, color: Color, dashed: Boolean, width: Float) {
    drawLine(color, from, to, strokeWidth = width, cap = StrokeCap.Round, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(18f, 12f)) else null)
    val ang = atan2(to.y - from.y, to.x - from.x)
    val len = 16.dp.toPx()
    for (da in listOf(Math.PI.toFloat() + .5f, Math.PI.toFloat() - .5f)) {
        val a = ang + da
        drawLine(color, to, Offset(to.x + len * cos(a), to.y + len * sin(a)), strokeWidth = width, cap = StrokeCap.Round)
    }
}

private fun arrowColor(kind: String) = when (kind) { "pass" -> PassColor; "press" -> PressColor; else -> RunColor }

// =============================================================== images
/** Small copies of the renders, kept in memory: the 2048 px originals are far too big to draw eleven times per frame. */
private object TokenImages {
    private val cache = android.util.LruCache<String, ImageBitmap>(40)
    fun peek(path: String): ImageBitmap? = cache.get(path)
    fun load(path: String, target: Int = 360): ImageBitmap? {
        cache.get(path)?.let { return it }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching { BitmapFactory.decodeFile(path, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
        val bmp = runCatching { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) }.getOrNull()
            ?.asImageBitmap() ?: return null
        cache.put(path, bmp)
        return bmp
    }
}

/** null while loading, false when there is nothing to show, otherwise the (small) picture. */
@Composable
private fun rememberTokenImage(path: String): Any? {
    if (path.isBlank()) return false
    val st = produceState<Any?>(TokenImages.peek(path), path) {
        value = TokenImages.peek(path) ?: withContext(Dispatchers.IO) { TokenImages.load(path) } ?: false
    }
    return st.value
}

// =============================================================== the pitch
private class PitchLook(
    val top: Color, val bottom: Color, val band: Color, val bandAlpha: Float,
    val line: Color, val lineAlpha: Float, val grid: Boolean = false,
)

private fun pitchLook(s: String) = when (s) {
    "mowed" -> PitchLook(Color(0xFF1FB254), Color(0xFF14A04A), Color.Black, .10f, Color.White, .9f)
    "night" -> PitchLook(Color(0xFF14513B), Color(0xFF0B2F24), Color.White, .05f, Color.White, .6f)
    "chalk" -> PitchLook(Color(0xFF26302C), Color(0xFF1D2522), Color.White, 0f, Color(0xFFF2EFE6), .85f)
    "paper" -> PitchLook(Color(0xFFF5F2EB), Color(0xFFEAE6DC), Color.Black, .035f, Color(0xFF1B1B1B), .7f)
    "blueprint" -> PitchLook(Color(0xFF16508F), Color(0xFF0E3A6B), Color.White, 0f, Color(0xFF9CCBFF), .9f, grid = true)
    else -> PitchLook(Color(0xFF2E7D3E), Color(0xFF2E7D3E), Color.Black, .10f, Color.White, .92f)
}

val PITCH_STYLES = listOf("grass" to "Stripes", "mowed" to "Mowed", "night" to "Night", "chalk" to "Chalk", "paper" to "Paper", "blueprint" to "Blueprint")

/** The pitch seen from behind the bottom goal: [persp] makes the far end narrower, like a team-sheet graphic. Positions are percent of [rect]. */
private class Proj(val rect: Rect, val persp: Boolean) {
    private fun wf(t: Float) = if (persp) TopWidth + (1f - TopWidth) * t.coerceIn(0f, 1f) else 1f
    fun pt(fx: Float, fy: Float): Offset {
        val t = fy / 100f
        return Offset(rect.left + rect.width * (.5f + (fx - 50f) / 100f * wf(t)), rect.top + rect.height * t)
    }
    fun from(p: Offset): Offset {
        val t = (p.y - rect.top) / rect.height
        return Offset(50f + ((p.x - rect.left) / rect.width - .5f) / wf(t) * 100f, t * 100f)
    }
}

private const val TopWidth = .80f

private fun Path.mv(o: Offset) = moveTo(o.x, o.y)
private fun Path.ln(o: Offset) = lineTo(o.x, o.y)

private fun DrawScope.drawLineupPitch(look: PitchLook, pr: Proj) {
    val r = pr.rect
    val k = min(1f, r.width / 340.dp.toPx())                    // thumbnails get thinner lines
    fun px(x: Float) = 4f + x / 68f * 92f                       // metres to pitch percent
    fun py(y: Float) = 3f + y / 105f * 94f
    fun at(x: Float, y: Float) = pr.pt(px(x), py(y))
    val whole = Path().apply { mv(pr.pt(0f, 0f)); ln(pr.pt(100f, 0f)); ln(pr.pt(100f, 100f)); ln(pr.pt(0f, 100f)); close() }
    drawPath(whole, Brush.verticalGradient(listOf(look.top, look.bottom), startY = r.top, endY = r.bottom))
    if (look.bandAlpha > 0f) for (i in 0 until 10 step 2) {
        val band = Path().apply { mv(pr.pt(0f, i * 10f)); ln(pr.pt(100f, i * 10f)); ln(pr.pt(100f, i * 10f + 10f)); ln(pr.pt(0f, i * 10f + 10f)); close() }
        drawPath(band, look.band.copy(alpha = look.bandAlpha))
    }
    if (look.grid) {
        val gc = look.line.copy(alpha = .10f)
        for (i in 1 until 20) {
            drawLine(gc, pr.pt(i * 5f, 0f), pr.pt(i * 5f, 100f), strokeWidth = max(.6f, 1.dp.toPx() * k))
            drawLine(gc, pr.pt(0f, i * 5f), pr.pt(100f, i * 5f), strokeWidth = max(.6f, 1.dp.toPx() * k))
        }
    }
    val line = look.line.copy(alpha = look.lineAlpha)
    val st = Stroke(max(1f, 2.2.dp.toPx() * k), cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun poly(pts: List<Offset>, closed: Boolean = false) {
        if (pts.size < 2) return
        drawPath(Path().apply { mv(pts[0]); for (i in 1 until pts.size) ln(pts[i]); if (closed) close() }, line, style = st)
    }
    fun arc(cx: Float, cy: Float, rad: Float, from: Int, to: Int, step: Int = 4) =
        (from..to step step).map { a -> val t = a * PI.toFloat() / 180f; at(cx + rad * cos(t), cy + rad * sin(t)) }
    poly(listOf(at(0f, 0f), at(68f, 0f), at(68f, 105f), at(0f, 105f)), true)
    poly(listOf(at(0f, 52.5f), at(68f, 52.5f)))
    poly(arc(34f, 52.5f, 9.15f, 0, 360))
    drawCircle(line, max(1.2f, 3.dp.toPx() * k), at(34f, 52.5f))
    for (top in listOf(true, false)) {
        val e = if (top) 0f else 105f; val d = if (top) 1f else -1f
        poly(listOf(at(34f - 20.16f, e), at(34f - 20.16f, e + d * 16.5f), at(34f + 20.16f, e + d * 16.5f), at(34f + 20.16f, e)))
        poly(listOf(at(34f - 9.16f, e), at(34f - 9.16f, e + d * 5.5f), at(34f + 9.16f, e + d * 5.5f), at(34f + 9.16f, e)))
        drawCircle(line, max(1f, 2.5.dp.toPx() * k), at(34f, e + d * 11f))
        poly(if (top) arc(34f, 11f, 9.15f, 38, 142, 3) else arc(34f, 94f, 9.15f, 218, 322, 3))
        // the goal and its net, outside the touchline
        val net = line.copy(alpha = line.alpha * .55f)
        val gl = at(34f - 3.66f, e); val gr = at(34f + 3.66f, e)
        val bl = at(34f - 3.66f, e - d * 2.4f); val br = at(34f + 3.66f, e - d * 2.4f)
        drawPath(Path().apply { mv(gl); ln(bl); ln(br); ln(gr) }, line, style = st)
        for (i in 1..5) {
            val f = i / 6f
            drawLine(net, Offset(gl.x + (gr.x - gl.x) * f, gl.y), Offset(bl.x + (br.x - bl.x) * f, bl.y), strokeWidth = max(.6f, 1.dp.toPx() * k))
        }
        for (i in 1..2) {
            val f = i / 3f
            drawLine(net, Offset(gl.x + (bl.x - gl.x) * f, gl.y + (bl.y - gl.y) * f), Offset(gr.x + (br.x - gr.x) * f, gr.y + (br.y - gr.y) * f), strokeWidth = max(.6f, 1.dp.toPx() * k))
        }
    }
    drawPath(whole, Color.Black.copy(alpha = .10f), style = Stroke(max(1f, 3.dp.toPx() * k)))
}

// =============================================================== tokens
/** How a player looks: just the render with a white name plate, like a team-sheet graphic. Without a render (or in circle mode): a numbered circle. */
@Composable
private fun Token(
    slot: LineSlot, role: String, gk: Boolean, selected: Boolean, duty: String, kit: Color, w: Dp,
    labelMode: String, circleOnly: Boolean,
) {
    val u = LocalU.current
    val label = tokenText(slot, role, labelMode)
    val shirt = if (gk) Color(0xFFF6C945) else kit
    val loaded = rememberTokenImage(if (circleOnly) "" else slot.img)
    val bmp = loaded as? ImageBitmap
    val render = !circleOnly && slot.img.isNotBlank() && loaded != false
    val h = w * 1.14f
    val fs = w.value
    Box(Modifier.size(w, h)) {
        if (selected) Box(
            if (render) Modifier.align(Alignment.TopCenter).fillMaxWidth().fillMaxHeight(.84f).clip(RoundedCornerShape(w * .16f)).background(u.acc.copy(alpha = .32f))
            else Modifier.align(Alignment.TopCenter).size(w * .86f).clip(CircleShape).background(u.acc.copy(alpha = .32f)),
        )
        if (render) {
            if (bmp != null) Image(
                bmp, null, Modifier.align(Alignment.TopCenter).fillMaxWidth().fillMaxHeight(.9f),
                contentScale = ContentScale.Fit, alignment = Alignment.BottomCenter, filterQuality = FilterQuality.Medium,
            )
        } else {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = w * .04f).size(w * .6f).shadow(4.dp, CircleShape).clip(CircleShape)
                    .background(shirt).border(if (selected) 3.dp else 2.dp, if (selected) u.acc else Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Tx(slot.num, fs * .25f, 800, inkOn(shirt), maxLines = 1) }
        }
        NamePlate(label, selected, fs, Modifier.align(Alignment.BottomCenter))
        if (duty.isNotEmpty()) Box(
            Modifier.align(Alignment.TopEnd).size(w * .26f).clip(CircleShape).background(PressColor).border(1.5.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Tx(duty, fs * .13f, 800, Color.White) }
    }
}

@Composable
private fun NamePlate(label: String, ring: Boolean, fs: Float, modifier: Modifier = Modifier) {
    val u = LocalU.current
    val ts = (fs * .165f).coerceIn(9.5f, 14f)                 // text size in sp, from the token width in dp
    val shape = RoundedCornerShape((ts * .42f).dp)
    Box(
        modifier.wrapContentWidth(Alignment.CenterHorizontally, unbounded = true).shadow(2.dp, shape).clip(shape).background(Color.White)
            .border(if (ring) 2.dp else 1.dp, if (ring) u.acc else Color(0xFFC9CCD1), shape)
            .widthIn(min = (fs * .56f).dp).padding(horizontal = (ts * .6f).dp, vertical = (ts * .24f).dp),
        contentAlignment = Alignment.Center,
    ) { Tx(label, ts, 800, Color(0xFF111111), maxLines = 1, align = TextAlign.Center, modifier = Modifier.widthIn(max = (fs * 1.3f).dp)) }
}

// =============================================================== the board
private const val BoardAspect = 1.76f      // height of the board divided by its width

/** Sizes and positions of the board (flat pitch with the bench dock underneath), all in pixels of a board [bw] wide. */
private class Geo(val bw: Float) {
    val pad = bw * .02f
    val tokW = bw * .19f
    val tokH = tokW * 1.14f
    val benchW = bw * .134f
    val benchH = benchW * 1.14f
    val pitchH = (bw - 2f * pad) * 105f / 68f
    val pitch = Proj(Rect(pad, pad, bw - pad, pad + pitchH), false)
    val benchTop = pad + pitchH + bw * .05f
    val h = benchTop + benchH + bw * .05f
    val dock = Rect(0f, benchTop - bw * .03f, bw, h)
    fun benchAnchor(i: Int, total: Int): Offset {
        val sw = (bw - 2f * pad) / maxOf(total, 1)
        return Offset(pad + sw * (i + .5f), benchTop + benchH * .74f)
    }
    /** Width of the token of [key] ("p3" starter, "b2" bench). */
    fun wOf(key: String) = if (key.startsWith("p")) tokW else benchW
}

/** Where a token is touched, dragged and dropped. Everything the finger moves is read in the layout or draw phase, so a drag does not recompose anything. */
private class DragState {
    var key by mutableStateOf<String?>(null)
    var pos by mutableStateOf(Offset.Zero)        // finger, in board pixels
    var grab by mutableStateOf(Offset.Zero)       // finger minus the token's anchor, kept while dragging
    var over by mutableStateOf<String?>(null)     // token under the finger that a drop would swap with
    var sx by mutableStateOf<Float?>(null)        // where the player would stand after snapping (pitch percent)
    var sy by mutableStateOf<Float?>(null)
    var gx by mutableStateOf<Float?>(null)        // guide lines the snap is locked to (pitch percent)
    var gy by mutableStateOf<Float?>(null)
}

private val Glide = spring<Offset>(dampingRatio = .8f, stiffness = 420f)

/**
 * The board: the pitch with the eleven and the bench dock under it. A player follows the finger exactly; guides and a landing ring show
 * where he will settle, and on release he glides there. Dropping on another player swaps them (that player slides over while you hover).
 * In [arrowsMode] a drag on the pitch draws an arrow instead.
 */
@Composable
private fun LineupBoard(
    vm: AppVM, c: Club, l: Lineup, slots: List<PSlot>, sel: String, arrowsMode: Boolean, modifier: Modifier = Modifier,
) {
    val u = LocalU.current
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val kit = remember(c.color) { hex(c.color) }
    val look = remember(l.pitch) { pitchLook(l.pitch) }
    val circleOnly = l.tokens == "C"
    val ds = remember { DragState() }
    var live by remember { mutableStateOf<Pair<Offset, Offset>?>(null) }     // arrow being drawn, in board pixels
    val lineup by rememberUpdatedState(l)
    val slotsNow by rememberUpdatedState(slots)
    val arrowsNow by rememberUpdatedState(arrowsMode)
    val kindNow by rememberUpdatedState(vm.arrowKind)
    val anims = remember { HashMap<String, Animatable<Offset, AnimationVector2D>>() }
    val lift = remember { Animatable(1f) }
    LaunchedEffect(ds.key != null) { lift.animateTo(if (ds.key != null) 1.1f else 1f, spring(dampingRatio = .55f, stiffness = 500f)) }

    BoxWithConstraints(modifier, contentAlignment = Alignment.TopCenter) {
        val maxW = constraints.maxWidth.toFloat()
        val maxH = if (constraints.hasBoundedHeight) constraints.maxHeight.toFloat() else Float.MAX_VALUE
        val bw = min(maxW, maxH / BoardAspect)
        val geo = remember(bw) { Geo(bw) }
        val geoNow by rememberUpdatedState(geo)
        val bwDp = with(density) { bw.toDp() }
        val tokDp = with(density) { geo.tokW.toDp() }
        val benchDp = with(density) { geo.benchW.toDp() }
        val nBench = l.bench.size

        /** Where the token [k] stands when nobody touches it, in board pixels. */
        fun homeOf(k: String): Offset {
            val i = k.drop(1).toInt()
            val g = geoNow
            return if (k.startsWith("p")) { val (dx, dy) = disp(slotsNow[i], lineup); g.pitch.pt(dx, dy) } else g.benchAnchor(i, nBench)
        }
        fun allKeys() = (0 until 11).map { "p$it" } + (0 until nBench).map { "b$it" }
        fun rectOf(k: String): Rect {
            val a = homeOf(k); val w = geoNow.wOf(k)
            return Rect(a.x - w / 2f, a.y - w * 1.14f * .74f, a.x + w / 2f, a.y + w * 1.14f * .26f).inflate(geoNow.tokW * .06f)
        }
        fun hit(p: Offset): String? {
            var best: String? = null; var bd = Float.MAX_VALUE
            for (k in allKeys()) {
                if (!rectOf(k).contains(p)) continue
                val d = (homeOf(k) - p).getDistance()
                if (d < bd) { bd = d; best = k }
            }
            return best
        }
        /** The place a drop at [p] would swap with: over the dock the nearest bench place, on the pitch a player the finger is close to. */
        fun swapTarget(p: Offset, self: String): String? {
            val g = geoNow
            if (nBench > 0 && p.y > g.dock.top - g.benchH * .2f) {
                var best: String? = null; var bd = Float.MAX_VALUE
                for (i in 0 until nBench) {
                    val k = "b$i"
                    if (k == self) continue
                    val d = abs(g.benchAnchor(i, nBench).x - p.x)
                    if (d < bd) { bd = d; best = k }
                }
                if (best != null) return best
            }
            var best: String? = null; var bd = g.tokW * .5f
            for (k in allKeys()) {
                if (k == self || k.startsWith("b")) continue
                val a = homeOf(k)
                val d = (Offset(a.x, a.y - g.tokW * .4f) - p).getDistance()
                if (d < bd) { bd = d; best = k }
            }
            return best
        }
        fun snapAt(a: Offset, self: Int) {
            val f = geoNow.pitch.from(a)
            var fx = f.x.coerceIn(10f, 90f)
            var fy = f.y.coerceIn(9f, 93f)
            var gx: Float? = null; var gy: Float? = null
            val cur = lineup
            when (cur.snap) {
                "G" -> { fx = ((fx / 5f).roundToInt() * 5f).coerceIn(10f, 90f); fy = ((fy / 5f).roundToInt() * 5f).coerceIn(10f, 90f) }
                "S" -> {
                    val others = slotsNow.indices.filter { it != self }.map { disp(slotsNow[it], cur) }
                    val cx = (others.map { it.first } + 50f).minByOrNull { abs(it - fx) }
                    if (cx != null && abs(cx - fx) <= 2.6f) { fx = cx; gx = cx }
                    val cy = others.map { it.second }.minByOrNull { abs(it - fy) }
                    if (cy != null && abs(cy - fy) <= 2.2f) { fy = cy; gy = cy }
                }
            }
            if ((gx != null && gx != ds.gx) || (gy != null && gy != ds.gy)) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            ds.sx = fx; ds.sy = fy; ds.gx = gx; ds.gy = gy
        }
        fun clearSnap() { ds.sx = null; ds.sy = null; ds.gx = null; ds.gy = null }
        fun animOf(key: String, at: Offset) = anims.getOrPut(key) { Animatable(at, Offset.VectorConverter) }
        /** Starts the token [key] at [from] (where it is on the screen) and glides it to [to]. */
        fun glide(key: String, from: Offset, to: Offset) {
            val a = animOf(key, to)
            scope.launch(start = CoroutineStart.UNDISPATCHED) { a.snapTo(from); a.animateTo(to, Glide) }
        }

        val gesture = Modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val k = hit(down.position)
                val pr = geoNow.pitch.rect
                if (arrowsNow) {
                    // arrows: a drag on the pitch draws one; a tap picks a player
                    if (!pr.contains(down.position)) {
                        if (k != null) { val up = waitForUpOrCancellation(); if (up != null) vm.lineupSel = k }
                        return@awaitEachGesture
                    }
                    val slop = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                    if (slop == null) {
                        if (currentEvent.changes.none { it.pressed }) vm.lineupSel = k ?: ""
                        return@awaitEachGesture
                    }
                    val from = down.position
                    live = from to from
                    drag(slop.id) { change -> change.consume(); live = from to change.position }
                    val a = live
                    if (a != null && (a.second - a.first).getDistance() > 28f) {
                        val p1 = geoNow.pitch.from(a.first); val p2 = geoNow.pitch.from(a.second)
                        val arrow = Arrow(p1.x, p1.y, p2.x, p2.y, kindNow)
                        vm.editLineup(lineup.cid) { it.copy(arrows = it.arrows + arrow) }
                    }
                    live = null
                    return@awaitEachGesture
                }
                if (k == null) {
                    val up = waitForUpOrCancellation()
                    if (up != null) vm.lineupSel = ""
                    return@awaitEachGesture
                }
                val slop = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                if (slop == null) {
                    if (currentEvent.changes.none { it.pressed }) vm.lineupSel = if (vm.lineupSel == k) "" else k
                    return@awaitEachGesture
                }
                // ---- a player is picked up
                val onPitch = k.startsWith("p")
                val idx = k.drop(1).toInt()
                val home0 = homeOf(k)
                vm.lineupSel = k
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                ds.grab = down.position - home0
                ds.pos = slop.position
                ds.over = null
                clearSnap()
                ds.key = k
                val finished = drag(slop.id) { change ->
                    change.consume()
                    ds.pos = change.position
                    val t = swapTarget(change.position, k)
                    if (t != ds.over) { ds.over = t; if (t != null) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                    // snapping only while the finger is not over another player, so a swap never fights a guide
                    if (onPitch && t == null) snapAt(ds.pos - ds.grab, idx) else clearSnap()
                }
                val ghost = ds.pos - ds.grab
                val target = if (finished) swapTarget(ds.pos, k) else null
                val cidNow = lineup.cid
                if (finished && target != null) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val aTarget = homeOf(target)
                    vm.editLineup(cidNow) { swapSlots(it, k, target) }
                    // the other player is already standing where you were; you glide from the finger to his old place
                    glide(target, ghost, aTarget)
                } else if (finished && onPitch) {
                    val f = geoNow.pitch.from(ghost)
                    val fx = ds.sx ?: f.x.coerceIn(10f, 90f)
                    val fy = ds.sy ?: f.y.coerceIn(9f, 93f)
                    val s = slotsNow[idx]
                    val (xs, ys) = unDisp(fx, fy, s.role, lineup)
                    val nx = slotsNow.mapIndexed { n, o -> if (n == idx) xs else o.x }
                    val ny = slotsNow.mapIndexed { n, o -> if (n == idx) ys else o.y }
                    vm.editLineup(cidNow) { it.copy(px = nx, py = ny) }
                    glide(k, ghost, geoNow.pitch.pt(fx, fy))
                } else {
                    glide(k, ghost, home0)
                }
                ds.key = null
                ds.over = null
                clearSnap()
            }
        }

        Box(Modifier.size(bwDp, with(density) { geo.h.toDp() }).then(gesture)) {
            // ---- pitch, dock, arrows, guides
            Canvas(Modifier.fillMaxSize()) {
                val pr = geo.pitch
                val cr = CornerRadius(18.dp.toPx())
                clipPath(Path().apply { addRoundRect(RoundRect(pr.rect, cr)) }) { drawLineupPitch(look, pr) }
                drawRoundRect(u.sf, Offset(geo.dock.left, geo.dock.top), Size(geo.dock.width, geo.dock.height), CornerRadius(18.dp.toPx()))
                l.arrows.forEach { a ->
                    drawArrow(pr.pt(a.x1, a.y1), pr.pt(a.x2, a.y2), arrowColor(a.kind), a.kind == "run", if (a.kind == "press") 4.dp.toPx() else 3.dp.toPx())
                }
                live?.let { (a, b) -> drawArrow(a, b, arrowColor(kindNow), kindNow == "run", 3.dp.toPx()) }
                val dk = ds.key
                if (dk != null && dk.startsWith("p")) {
                    if (l.snap == "G") {
                        val gc = Color.White.copy(alpha = .20f)
                        for (i in 2..18) {
                            drawLine(gc, pr.pt(i * 5f, 0f), pr.pt(i * 5f, 100f), strokeWidth = 1.dp.toPx())
                            drawLine(gc, pr.pt(0f, i * 5f), pr.pt(100f, i * 5f), strokeWidth = 1.dp.toPx())
                        }
                    }
                    val guide = Color(0xFFFFE066).copy(alpha = .95f)
                    val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                    ds.gx?.let { drawLine(guide, pr.pt(it, 0f), pr.pt(it, 100f), strokeWidth = 1.6.dp.toPx(), pathEffect = dash) }
                    ds.gy?.let { drawLine(guide, pr.pt(0f, it), pr.pt(100f, it), strokeWidth = 1.6.dp.toPx(), pathEffect = dash) }
                    // landing ring: where he settles when you let go
                    val sx = ds.sx; val sy = ds.sy
                    if (sx != null && sy != null && ds.over == null) {
                        val p = pr.pt(sx, sy)
                        drawCircle(Color.White.copy(alpha = .75f), geo.tokW * .36f, Offset(p.x, p.y - geo.tokH * .36f), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))))
                    }
                }
                // swap ring around the player you would swap with
                val ov = ds.over
                if (ov != null && dk != null) {
                    val a = homeOf(ov); val w = geo.wOf(ov)
                    val ctr = Offset(a.x, a.y - w * 1.14f * .36f)
                    drawCircle(u.acc.copy(alpha = .22f), w * .62f, ctr)
                    drawCircle(u.acc, w * .62f, ctr, style = Stroke(3.dp.toPx()))
                }
            }

            // ---- the eleven (each one glides to its place, so formation, width and nudges move smoothly)
            slots.indices.sortedBy { disp(slots[it], l).second }.forEach { i ->
                key(i) {
                    val s = slots[i]
                    val k = "p$i"
                    val home = homeOf(k)
                    val target = if (ds.over == k && ds.key != null) homeOf(ds.key!!) else home
                    val anim = animOf(k, target)
                    LaunchedEffect(k, target.x.roundToInt(), target.y.roundToInt()) { anim.animateTo(target, Glide) }
                    val pop = 1f
                    Box(
                        Modifier.offset { val p = anim.value; IntOffset((p.x - geo.tokW / 2f).roundToInt(), (p.y - geo.tokH * .74f).roundToInt()) }
                            .graphicsLayer {
                                alpha = if (ds.key == k) 0f else 1f
                                scaleX = pop; scaleY = pop
                                transformOrigin = TransformOrigin(.5f, .74f)
                            },
                    ) { Token(l.xi[i], s.role, s.role == "GK", sel == k, l.duty[i], kit, tokDp, l.label, circleOnly) }
                }
            }

            // ---- the bench
            l.bench.forEachIndexed { i, sl ->
                key("b$i") {
                    val k = "b$i"
                    val home = homeOf(k)
                    val target = if (ds.over == k && ds.key != null) homeOf(ds.key!!) else home
                    val anim = animOf(k, target)
                    LaunchedEffect(k, target.x.roundToInt(), target.y.roundToInt()) { anim.animateTo(target, Glide) }
                    val pop = 1f
                    Box(
                        Modifier.offset { val p = anim.value; IntOffset((p.x - geo.benchW / 2f).roundToInt(), (p.y - geo.benchH * .74f).roundToInt()) }
                            .graphicsLayer {
                                alpha = if (ds.key == k) .25f else 1f
                                scaleX = pop; scaleY = pop
                                transformOrigin = TransformOrigin(.5f, .74f)
                            },
                    ) { Token(sl, "Sub ${i + 1}", false, sel == k, "", kit, benchDp, l.label, circleOnly) }
                }
            }

            // ---- the player in the finger: follows it exactly, lifted, with a soft shadow
            val dk = ds.key
            if (dk != null) {
                val ghostSlot = slotOf(l, dk)
                val onPitch = dk.startsWith("p")
                val role = if (onPitch) slots[dk.drop(1).toInt()].role else "Sub ${dk.drop(1).toInt() + 1}"
                val gw = geo.wOf(dk)
                Box(
                    Modifier.offset {
                        val a = ds.pos - ds.grab
                        IntOffset((a.x.coerceIn(0f, geo.bw) - gw / 2f).roundToInt(), (a.y.coerceIn(0f, geo.h) - gw * 1.14f * .74f).roundToInt())
                    }.zIndex(5f).graphicsLayer {
                        scaleX = lift.value; scaleY = lift.value; alpha = .98f
                        transformOrigin = TransformOrigin(.5f, .74f)
                    },
                ) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).offset(y = with(density) { (gw * .12f).toDp() })
                            .size(with(density) { (gw * .62f).toDp() }, with(density) { (gw * .14f).toDp() })
                            .clip(CircleShape).background(Color.Black.copy(alpha = .35f)),
                    )
                    Token(
                        ghostSlot, role, onPitch && slots[dk.drop(1).toInt()].role == "GK", true,
                        if (onPitch) l.duty[dk.drop(1).toInt()] else "", kit, if (onPitch) tokDp else benchDp, l.label, circleOnly,
                    )
                }
            }
        }
    }
}

/** Moves a starter one step on the pitch (percent). */
private fun nudgeLineup(vm: AppVM, cid: String, idx: Int, dx: Float, dy: Float) = vm.editLineup(cid) { cur ->
    val sl = lineupSlots(cur)
    val (x, y) = disp(sl[idx], cur)
    moveSpots(cur, sl, mapOf(idx to ((x + dx) to (y + dy))))
}

// =============================================================== the editor
private val LINEUP_PAGES = listOf("players" to "Players", "shape" to "Shape", "look" to "Look", "tactics" to "Tactics")

private fun slotName(slots: List<PSlot>, key: String) = if (key.startsWith("p")) slots[key.drop(1).toInt()].role else "Sub ${key.drop(1).toInt() + 1}"

private fun validKey(sel: String) = sel.length > 1 && (sel.startsWith("p") || sel.startsWith("b")) && sel.drop(1).toIntOrNull() != null

private fun freshSlot(sel: String) = LineSlot(num = (if (sel.startsWith("p")) sel.drop(1).toInt() + 1 else sel.drop(1).toInt() + 12).toString())

@Composable
private fun FloatBtn(icon: String, on: Boolean = false, onClick: () -> Unit) {
    val u = LocalU.current
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(if (on) u.acc else u.sf).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Ico(icon, 21.dp, if (on) inkOn(u.acc) else u.ink, 2f) }
}

@Composable
private fun MiniBtn(text: String, onClick: () -> Unit) {
    val u = LocalU.current
    Box(Modifier.size(36.dp).clip(CircleShape).background(u.bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Tx(text, 15 * u.fs, 800)
    }
}

/** The lineup builder: the pitch over the whole screen, a few buttons on it, and a pull-up menu with everything else. */
@Composable
fun LineupPage(vm: AppVM, cid: String) {
    val c = vm.cl(cid) ?: return
    LineupEditor(vm, c, cid) { vm.goBack() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LineupEditor(vm: AppVM, c: Club, cid: String, onClose: () -> Unit) {
    val u = LocalU.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val l = vm.lineupOf(cid)
    val slots = lineupSlots(l)
    val sel = vm.lineupSel
    val idx = if (sel.startsWith("p") && validKey(sel)) sel.drop(1).toInt() else -1
    val tab = LINEUP_PAGES.firstOrNull { it.first == vm.lineupPage }?.first ?: "players"
    val sheet = remember { Animatable(0f) }
    val sheetShown by remember { derivedStateOf { sheet.value > .001f } }
    var arrows by remember { mutableStateOf(false) }
    var fmOpen by remember { mutableStateOf(false) }
    fun openSheet(open: Boolean) { scope.launch { sheet.animateTo(if (open) 1f else 0f, spring(dampingRatio = .9f, stiffness = 380f)) } }
    LaunchedEffect(Unit) { if (vm.lineupTactics) sheet.animateTo(1f, spring(dampingRatio = .9f, stiffness = 380f)) }

    Dialog(
        onDismissRequest = { if (sheet.value > .5f) openSheet(false) else onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val view = LocalView.current
        DisposableEffect(view) {
            val w = (view.parent as? DialogWindowProvider)?.window
            if (w != null) {
                WindowCompat.setDecorFitsSystemWindows(w, false)
                w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
                if (Build.VERSION.SDK_INT >= 28) {
                    w.attributes = w.attributes.apply {
                        layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                val ctl = WindowCompat.getInsetsController(w, view)
                ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(WindowInsetsCompat.Type.systemBars())
            }
            onDispose { }
        }
        Box(Modifier.fillMaxSize().background(u.bg)) {
            BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
                val topH = 62.dp
                val botH = 76.dp
                val sheetH = maxHeight * .5f
                val sheetPx = with(density) { sheetH.toPx() }
                val availPx = with(density) { (maxHeight - topH - botH).toPx() }
                val bwPx = min(with(density) { maxWidth.toPx() }, availPx / BoardAspect)
                val boardH = bwPx * BoardAspect
                val sMin = (with(density) { (maxHeight - topH - sheetH - 6.dp).toPx() } / boardH).coerceIn(.3f, 1f)

                // ---- the board; the menu shrinks it instead of covering it
                Box(Modifier.fillMaxSize().padding(top = topH, bottom = botH)) {
                    LineupBoard(
                        vm, c, l, slots, sel, arrows,
                        Modifier.fillMaxSize().graphicsLayer {
                            val s = 1f + (sMin - 1f) * sheet.value
                            scaleX = s; scaleY = s
                            transformOrigin = TransformOrigin(.5f, 0f)
                        },
                    )
                }

                // ---- the few buttons on the pitch
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().height(topH).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FloatBtn("close", onClick = onClose)
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Row(
                            Modifier.height(46.dp).clip(CircleShape).background(u.sf).clickable { fmOpen = !fmOpen }.padding(horizontal = 18.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Tx(l.fm, 16 * u.fs, 800)
                            Ico(if (fmOpen) "chevu" else "chevd", 16.dp, u.mu, 2.2f)
                        }
                    }
                    FloatBtn("route", on = arrows) { arrows = !arrows; fmOpen = false; if (arrows) openSheet(false) }
                    FloatBtn("menu") { fmOpen = false; openSheet(true) }
                }
                if (fmOpen) Row(
                    Modifier.align(Alignment.TopCenter).padding(top = topH).fillMaxWidth().padding(horizontal = 12.dp).zIndex(3f)
                        .clip(RoundedCornerShape(24.dp)).background(u.sf).horizontalScroll(rememberScrollState()).padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FORMATIONS.forEach { f ->
                        Chip(f, l.fm == f) { vm.editLineup(cid) { it.copy(fm = f, px = emptyList(), py = emptyList()) }; fmOpen = false }
                    }
                }

                // ---- bottom: the four menus, or the picked player, or the arrow tools (one row, so the bench gets the room)
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(botH).padding(horizontal = 12.dp).padding(bottom = 10.dp, top = 8.dp)
                        .graphicsLayer { alpha = 1f - sheet.value },
                    contentAlignment = Alignment.BottomCenter,
                ) {
                    if (arrows) {
                        Row(
                            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp)).background(u.sf).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf("run" to "Run", "pass" to "Pass", "press" to "Press").forEach { (k, t) -> Chip(t, vm.arrowKind == k) { vm.arrowKind = k } }
                            Chip("Undo", false) { vm.editLineup(cid) { it.copy(arrows = it.arrows.dropLast(1)) } }
                            Chip("Clear", false) { vm.editLineup(cid) { it.copy(arrows = emptyList()) } }
                            Chip("Done", true) { arrows = false }
                        }
                    } else if (validKey(sel)) {
                        val slot = slotOf(l, sel)
                        Row(
                            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp)).background(u.sf).padding(start = 18.dp, end = 10.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Column(Modifier.weight(1f)) {
                                Tx(slot.name.ifBlank { slotName(slots, sel) }, 14 * u.fs, 800, maxLines = 1)
                                Tx((if (idx >= 0) "Starter" else "Bench") + " · " + slotName(slots, sel), 11.5f * u.fs, 500, u.mu, maxLines = 1)
                            }
                            if (idx >= 0) {
                                MiniBtn("←") { nudgeLineup(vm, cid, idx, -1f, 0f) }
                                MiniBtn("→") { nudgeLineup(vm, cid, idx, 1f, 0f) }
                                MiniBtn("↑") { nudgeLineup(vm, cid, idx, 0f, -1f) }
                                MiniBtn("↓") { nudgeLineup(vm, cid, idx, 0f, 1f) }
                            }
                            Chip("Edit", true) { vm.lineupPage = "players"; openSheet(true) }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LINEUP_PAGES.forEach { (k, t) ->
                                Box(
                                    Modifier.weight(1f).fillMaxHeight().clip(CircleShape).background(u.sf).clickable { vm.lineupPage = k; openSheet(true) },
                                    contentAlignment = Alignment.Center,
                                ) { Tx(t, 13.5f * u.fs, 700, u.ink, maxLines = 1) }
                            }
                        }
                    }
                }

                // ---- the pull-up menu
                val dragState = rememberDraggableState { dy -> scope.launch { sheet.snapTo((sheet.value - dy / sheetPx).coerceIn(0f, 1f)) } }
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sheetH)
                        .graphicsLayer { translationY = (1f - sheet.value) * size.height; alpha = if (sheet.value > .001f) 1f else 0f }
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(u.sf),
                ) {
                    Column(
                        Modifier.fillMaxWidth().draggable(
                            dragState, Orientation.Vertical,
                            onDragStopped = { v ->
                                val to = if (v > 700f) 0f else if (v < -700f) 1f else if (sheet.value > .5f) 1f else 0f
                                sheet.animateTo(to, spring(dampingRatio = .9f, stiffness = 380f))
                            },
                        ).padding(bottom = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.padding(vertical = 10.dp).size(40.dp, 5.dp).clip(CircleShape).background(u.mu.copy(alpha = .5f)))
                        SegRow(LINEUP_PAGES, tab, Modifier.padding(horizontal = 14.dp)) { vm.lineupPage = it }
                    }
                    if (sheetShown) key(tab) {
                        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
                            when (tab) {
                                "players" -> PlayersTab(vm, cid, l, slots, sel)
                                "shape" -> ShapeTab(vm, cid, l, slots, sel)
                                "look" -> LookTab(vm, cid, l)
                                else -> TacticsTab(vm, cid, l, slots, sel) { arrows = true; openSheet(false) }
                            }
                            Spacer(Modifier.height(40.dp))
                        }
                    }
                }
            }
        }
    }
}

// =============================================================== the menus
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayersTab(vm: AppVM, cid: String, l: Lineup, slots: List<PSlot>, sel: String) {
    val u = LocalU.current
    val kit = remember(vm.cl(cid)?.color) { hex(vm.cl(cid)?.color ?: "#888888") }
    val squad = vm.playersOf(cid)
    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)
    Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassBtn("Auto-fill", "users", Modifier.weight(1f)) { edit { autoFill(vm, it) } }
        GlassBtn("Reset", "swap", Modifier.weight(1f)) { vm.resetLineup(cid) }
    }
    if (validKey(sel)) {
        Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(top = 12.dp)) {
            Tx(slotName(slots, sel) + (if (sel.startsWith("p")) "  ·  Starter" else "  ·  Bench"), 13 * u.fs, 800, u.mu, Modifier.padding(start = 16.dp, bottom = 8.dp))
            SlotEditor(vm, cid, l, sel, slots, squad)
        }
    } else {
        Tx("Tap a player on the pitch or in the lists to edit his name, number and render.", 12.5f * u.fs, 500, u.mu, Modifier.padding(bottom = 12.dp), lh = 12.5f * u.fs * 1.5f)
    }
    H3("Starting XI")
    Glass(Modifier.fillMaxWidth(), pad = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) {
        slots.forEachIndexed { i, s ->
            val key = "p$i"
            PlayerRow(l.xi[i], s.role, s.role == "GK", kit, sel == key) { vm.lineupSel = if (sel == key) "" else key }
        }
    }
    H3("Bench")
    Glass(Modifier.fillMaxWidth(), pad = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) {
        l.bench.forEachIndexed { i, s ->
            val key = "b$i"
            PlayerRow(s, "Sub ${i + 1}", false, kit, sel == key) { vm.lineupSel = if (sel == key) "" else key }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShapeTab(vm: AppVM, cid: String, l: Lineup, slots: List<PSlot>, sel: String) {
    val u = LocalU.current
    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)
    val idx = if (sel.startsWith("p") && validKey(sel)) sel.drop(1).toInt() else -1
    Glass(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Formation", 15 * u.fs, 800)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FORMATIONS.forEach { f -> Chip(f, l.fm == f) { edit { it.copy(fm = f, px = emptyList(), py = emptyList()) } } }
        }
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Snapping while you drag", 15 * u.fs, 800)
        Spacer(Modifier.height(10.dp))
        SegRow(listOf("O" to "Free", "G" to "Grid", "S" to "Smart"), l.snap) { v -> edit { it.copy(snap = v) } }
        Tx(
            when (l.snap) {
                "G" -> "Players click onto a 5% grid. The grid shows while you drag."
                "S" -> "Players lock onto the lines of the other players and the centre of the pitch. A yellow guide shows what you are locked to."
                else -> "Players go exactly where you drop them."
            },
            12 * u.fs, 500, u.mu, Modifier.padding(top = 10.dp), lh = 12 * u.fs * 1.5f,
        )
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Shape of the team", 15 * u.fs, 800)
        Lbl("Mentality")
        SegRow(listOf("D" to "Defensive", "B" to "Balanced", "A" to "Attacking"), l.mn) { m -> edit { it.copy(mn = m) } }
        Lbl("Width")
        SegRow(listOf("N" to "Narrow", "M" to "Normal", "W" to "Wide"), l.wd) { w -> edit { it.copy(wd = w) } }
        Lbl("Space between the lines")
        SegRow(listOf("T" to "Tight", "M" to "Normal", "L" to "Stretched"), l.depth) { v -> edit { it.copy(depth = v) } }
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Fine moves", 15 * u.fs, 800)
        Lbl("Pick a starter")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            slots.indices.forEach { i -> Chip("${l.xi[i].num} ${slots[i].role}", idx == i) { vm.lineupSel = "p$i" } }
        }
        if (idx >= 0) {
            Tx(l.xi[idx].name.ifBlank { slots[idx].role }, 13 * u.fs, 600, u.mu, Modifier.padding(top = 10.dp, bottom = 10.dp), maxLines = 1)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("←", false) { nudgeLineup(vm, cid, idx, -1f, 0f) }
                Chip("→", false) { nudgeLineup(vm, cid, idx, 1f, 0f) }
                Chip("↑", false) { nudgeLineup(vm, cid, idx, 0f, -1f) }
                Chip("↓", false) { nudgeLineup(vm, cid, idx, 0f, 1f) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Align his line", false) {
                    edit { cur ->
                        val sl = lineupSlots(cur)
                        val row = rowOf(cur, sl, idx)
                        val my = row.map { disp(sl[it], cur).second }.average().toFloat()
                        moveSpots(cur, sl, row.associateWith { disp(sl[it], cur).first to my })
                    }
                }
                Chip("Even spacing", false) {
                    edit { cur ->
                        val sl = lineupSlots(cur)
                        val row = rowOf(cur, sl, idx).sortedBy { disp(sl[it], cur).first }
                        if (row.size < 3) cur else {
                            val lo = disp(sl[row.first()], cur).first; val hi = disp(sl[row.last()], cur).first
                            val step = (hi - lo) / (row.size - 1)
                            moveSpots(cur, sl, row.withIndex().associate { (n, i) -> i to ((lo + step * n) to disp(sl[i], cur).second) })
                        }
                    }
                }
                Chip("Centre line", false) {
                    edit { cur ->
                        val sl = lineupSlots(cur)
                        val row = rowOf(cur, sl, idx)
                        val avg = row.map { disp(sl[it], cur).first }.average().toFloat()
                        moveSpots(cur, sl, row.associateWith { (disp(sl[it], cur).first + 50f - avg) to disp(sl[it], cur).second })
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Reset all positions", false) { edit { it.copy(px = emptyList(), py = emptyList()) } }
        }
    }
}

@Composable
private fun LookTab(vm: AppVM, cid: String, l: Lineup) {
    val u = LocalU.current
    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)
    Glass(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Pitch", 15 * u.fs, 800)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PITCH_STYLES.forEach { (k, name) ->
                val on = l.pitch == k
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp)).clickable { edit { it.copy(pitch = k) } }.padding(2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Box(
                        Modifier.size(66.dp, 96.dp).clip(RoundedCornerShape(12.dp))
                            .border(if (on) 3.dp else 1.dp, if (on) u.acc else u.ln, RoundedCornerShape(12.dp)),
                    ) {
                        val look = pitchLook(k)
                        Canvas(Modifier.fillMaxSize()) { drawLineupPitch(look, Proj(Rect(0f, 0f, size.width, size.height), false)) }
                    }
                    Tx(name, 12 * u.fs, if (on) 800 else 600, if (on) u.ink else u.mu, maxLines = 1)
                }
            }
        }
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Players", 15 * u.fs, 800)
        Lbl("Text on the name plate")
        SegRow(listOf("N" to "Name", "S" to "Surname", "B" to "No. + name", "R" to "Role"), l.label) { v -> edit { it.copy(label = v) } }
        Lbl("Picture")
        SegRow(listOf("R" to "Render", "C" to "Numbered circle"), l.tokens) { v -> edit { it.copy(tokens = v) } }
        Tx(
            "Players without a render always show a numbered circle in the colour of the club. Goalkeepers are yellow.",
            12 * u.fs, 500, u.mu, Modifier.padding(top = 10.dp), lh = 12 * u.fs * 1.5f,
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TacticsTab(vm: AppVM, cid: String, l: Lineup, slots: List<PSlot>, sel: String, onDraw: () -> Unit) {
    val u = LocalU.current
    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)
    val idx = if (sel.startsWith("p") && validKey(sel)) sel.drop(1).toInt() else -1
    Glass(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Duties", 15 * u.fs, 800)
        Lbl("Pick a starter")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            slots.indices.forEach { i -> Chip("${l.xi[i].num} ${slots[i].role}", idx == i) { vm.lineupSel = "p$i" } }
        }
        if (idx >= 0) {
            Tx(l.xi[idx].name.ifBlank { slots[idx].role }, 13 * u.fs, 600, u.mu, Modifier.padding(top = 10.dp), maxLines = 1)
            Lbl("Duty")
            SegRow(listOf("" to "None", "A" to "Attack", "S" to "Support", "D" to "Defend"), l.duty[idx]) { v ->
                edit { it.copy(duty = it.duty.mapIndexed { n, o -> if (n == idx) v else o }) }
            }
        }
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Arrows", 15 * u.fs, 800)
        Tx("${l.arrows.size} on the pitch.", 12 * u.fs, 500, u.mu, Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("run" to "Run", "pass" to "Pass", "press" to "Press").forEach { (k, t) -> Chip(t, vm.arrowKind == k) { vm.arrowKind = k } }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Draw on the pitch", true, onDraw)
            Chip("Undo", false) { edit { it.copy(arrows = it.arrows.dropLast(1)) } }
            Chip("Clear", false) { edit { it.copy(arrows = emptyList()) } }
        }
    }
    Glass(Modifier.fillMaxWidth().padding(bottom = 12.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx("Team instructions", 15 * u.fs, 800)
        Lbl("Tempo")
        SegRow(listOf("S" to "Slow", "N" to "Normal", "F" to "Fast"), l.tempo) { v -> edit { it.copy(tempo = v) } }
        Lbl("Pressing")
        SegRow(listOf("L" to "Low", "M" to "Mid", "H" to "High"), l.press) { v -> edit { it.copy(press = v) } }
        Lbl("Defensive line")
        SegRow(listOf("D" to "Deep", "N" to "Normal", "H" to "High"), l.line) { v -> edit { it.copy(line = v) } }
        Tx(styleSummary(l), 13 * u.fs, 700, u.mu, Modifier.padding(top = 14.dp))
    }
}


/** One place of the lineup in the Players list. */
@Composable
private fun PlayerRow(slot: LineSlot, role: String, gk: Boolean, kit: Color, on: Boolean, onClick: () -> Unit) {
    val u = LocalU.current
    val loaded = rememberTokenImage(slot.img)
    val bmp = loaded as? ImageBitmap
    val shirt = if (gk) Color(0xFFF6C945) else kit
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (on) u.acc.copy(alpha = .12f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(shirt), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
            else Tx(slot.num, 15f, 800, inkOn(shirt), maxLines = 1)
        }
        Column(Modifier.weight(1f)) {
            Tx(slot.name.ifBlank { "Empty" }, 15 * u.fs, 700, if (slot.name.isBlank()) u.mu else u.ink, maxLines = 1)
            Tx(role + (if (slot.num.isNotBlank()) " · No. ${slot.num}" else ""), 12 * u.fs, 500, u.mu, maxLines = 1)
        }
        Ico(if (on) "chevd" else "chev", 16.dp, u.mu, 2.2f)
    }
}

/** Name, number, squad pick, online render, upload, background cut-out, swap and clear for one place. */
@Composable
private fun SlotEditor(vm: AppVM, cid: String, l: Lineup, sel: String, slots: List<PSlot>, squad: List<Player>) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val slot = slotOf(l, sel)
    val d = remember(sel, slot.img) { Draft(null, mapOf("img" to slot.img)) }
    val img = d["img"]
    LaunchedEffect(img) { if (img != slot.img) vm.editLineup(cid) { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(img = img)) } }
    var busy by remember(sel) { mutableStateOf(false) }
    var note by remember(sel) { mutableStateOf("") }
    fun edit(f: (Lineup) -> Lineup) = vm.editLineup(cid, f)

    Column(Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, bottom = 12.dp)) {
        FRow {
            Fld("Name", slot.name, { v -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(name = v, pid = "")) } }, Modifier.weight(1.6f), ph = "Player name")
            Fld("No.", slot.num, { v -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(num = v)) } }, Modifier.weight(1f), number = true)
        }
        if (squad.isNotEmpty()) DropSelect(
            "Pick from squad", "", squad.map { it.id to (if (it.num > 0) "${it.num}  ${it.name}" else it.name) },
            { pid -> squad.find { it.id == pid }?.let { p -> edit { cur -> withSlot(cur, sel, fromPlayer(p)) } } },
        )
        OnlineLookup(
            slot.name,
            { n, _ -> edit { cur -> withSlot(cur, sel, slotOf(cur, sel).copy(name = n, pid = "")) } },
            { d["img"] = it },
        )
        Upload("Render", d, "img")
        if (slot.img.isNotBlank()) {
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                SmallBtn(if (busy) "Cutting out..." else "Cut out the background", "s") {
                    if (!busy) {
                        busy = true; note = ""
                        scope.launch {
                            val out = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(slot.img)?.let { CutOut.cut(it) } }.getOrNull() }
                            if (out == null) note = "Couldn't cut that picture out."
                            else d["img"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, out) }
                            busy = false
                        }
                    }
                }
            }
            Tx(
                if (note.isNotBlank()) note else "Turns a photo into a render: the person stays and the background goes. Works best on a clear head and shoulders shot.",
                12 * u.fs, 500, if (note.isNotBlank()) u.red else u.mu, Modifier.padding(start = 4.dp, top = 6.dp), lh = 12 * u.fs * 1.5f,
            )
        }
        val others = (l.xi.indices.map { "p$it" } + l.bench.indices.map { "b$it" }).filter { it != sel }
        DropSelect(
            "Swap with", "", others.map { k -> k to (slotOf(l, k).name.ifBlank { slotName(slots, k) }) },
            { k -> edit { swapSlots(it, sel, k) } },
        )
        Spacer(Modifier.height(10.dp))
        Btn("Clear player", "red", 0.dp, 0.dp) { edit { cur -> withSlot(cur, sel, freshSlot(sel)) } }
    }
}
