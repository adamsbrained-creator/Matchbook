package com.matchbook.app

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.segmentation.Segmentation
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * "Cut out the background" (4.1): turns a photo of a person into a transparent render, on the phone.
 * It uses Google's ML Kit selfie segmentation, which works best on a single clear person.
 */
object CutOut {
    suspend fun cut(src: Bitmap): Bitmap? {
        // keep it small enough to be quick and to leave memory for the result
        val k = minOf(1f, 1024f / maxOf(src.width, src.height))
        val bmp = if (k < 1f) Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true) else src.copy(Bitmap.Config.ARGB_8888, false)
        val opts = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val seg = Segmentation.getClient(opts)
        return try {
            val mask = suspendCancellableCoroutine<SegmentationMask?> { cont ->
                seg.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resume(null) }
            } ?: return null
            val w = mask.width
            val h = mask.height
            val buf = mask.buffer
            buf.rewind()
            val conf = FloatArray(w * h)
            buf.asFloatBuffer().get(conf)
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            for (y in 0 until bmp.height) {
                val my = (y * h / bmp.height).coerceIn(0, h - 1)
                for (x in 0 until bmp.width) {
                    val mx = (x * w / bmp.width).coerceIn(0, w - 1)
                    // soften the edge: below .35 gone, above .85 solid
                    val a = ((conf[my * w + mx] - .35f) / .5f).coerceIn(0f, 1f)
                    val c = px[y * bmp.width + x]
                    px[y * bmp.width + x] = Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))
                }
            }
            Bitmap.createBitmap(px, bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        } finally {
            seg.close()
        }
    }
}
