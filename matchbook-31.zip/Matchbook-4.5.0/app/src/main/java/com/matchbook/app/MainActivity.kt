package com.matchbook.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // System launch screen first (dark + ball), then the animated Compose launch screen takes over
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // Which mode (Matchbook or Ringbook) must be known before the data is loaded
        Mode.load(this)
        // Transparent bars: the colour glow of each page runs under the status bar
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        setContent {
            if (!Mode.chosen) {
                ModePicker { wrestling -> Mode.set(this@MainActivity, wrestling) }
            } else {
                // one AppVM per mode: each loads its own saved data, and switching just picks the other one
                val id = if (Mode.wrestling) "ringbook" else "matchbook"
                val vm = remember(id) { ViewModelProvider(this@MainActivity)[id, AppVM::class.java] }
                key(id) { MatchbookApp(vm) }
            }
        }
    }
}
