package com.matchbook.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// =====================================================================================================
// World map page (3.1): countries with leagues light up, tap one to see its border and its leagues,
// tap a league to see its table and (placed by city) its clubs on the map. Pinch to zoom, drag to move.
// =====================================================================================================

internal class Cam(val s: Float, val tx: Float, val ty: Float)
internal class PinItem(val id: String, val lon: Float, val lat: Float, val label: String, val color: Color, val weight: Int)
internal class PinView(val x: Float, val y: Float, val items: List<PinItem>)
internal class WGroup(val key: String, val label: String, val shape: GeoShape?, val leagues: List<League>)

private const val LAT_TOP = 83f
private const val LAT_BOTTOM = -58f

internal fun homeCam(w: Float, h: Float): Cam {
    val s = w / 360f
    return Cam(s, w / 2f, h / 2f + 12.5f * s)
}

internal fun clampCam(c: Cam, w: Float, h: Float): Cam {
    val minS = w / 360f
    val s = c.s.coerceIn(minS, minS * 80f)
    val mapW = 360f * s
    val mapH = (LAT_TOP - LAT_BOTTOM) * s
    val tx = if (mapW <= w) w / 2f else c.tx.coerceIn(w - 180f * s, 180f * s)
    val ty = if (mapH <= h) h / 2f + 12.5f * s else c.ty.coerceIn(h - (-LAT_BOTTOM) * s, LAT_TOP * s)
    return Cam(s, tx, ty)
}

/** The camera that shows [b] (minLon, minLat, maxLon, maxLat) with some air around it. */
internal fun fitCam(b: FloatArray, w: Float, h: Float): Cam {
    val dLon = max(b[2] - b[0], 1f); val dLat = max(b[3] - b[1], 1f)
    val minS = w / 360f
    val s = min(w / (dLon * 1.5f), h / (dLat * 1.5f)).coerceIn(minS, minS * 80f)
    return clampCam(Cam(s, w / 2f - (b[0] + b[2]) / 2f * s, h / 2f + (b[1] + b[3]) / 2f * s), w, h)
}

internal fun pinsFor(items: List<PinItem>, cam: Cam, radius: Float): List<PinView> {
    val used = BooleanArray(items.size)
    val out = ArrayList<PinView>()
    val order = items.indices.sortedByDescending { items[it].weight }
    for (i in order) {
        if (used[i]) continue
        val a = items[i]
        val ax = a.lon * cam.s + cam.tx; val ay = -a.lat * cam.s + cam.ty
        val grp = arrayListOf(a)
        used[i] = true
        for (j in order) {
            if (used[j]) continue
            val b = items[j]
            val bx = b.lon * cam.s + cam.tx; val by = -b.lat * cam.s + cam.ty
            if (hypot(ax - bx, ay - by) < radius) { grp.add(b); used[j] = true }
        }
        val cx = grp.sumOf { (it.lon * cam.s + cam.tx).toDouble() } / grp.size
        val cy = grp.sumOf { (-it.lat * cam.s + cam.ty).toDouble() } / grp.size
        out.add(PinView(cx.toFloat(), cy.toFloat(), grp))
    }
    return out
}

internal fun buildGroups(vm: AppVM, shapes: List<GeoShape>?): List<WGroup> =
    vm.leagues.groupBy { l ->
        vm.regionFor(l.country)?.let { "region:" + it.id } ?: WorldGeo.find(shapes, l.country)?.key ?: ("txt:" + l.country.trim().lowercase())
    }.map { (k, ls) ->
        if (k.startsWith("region:")) {
            val r = vm.regions.first { "region:" + it.id == k }
            WGroup(k, r.name, shapes?.let { WorldGeo.regionShape(r, it) }, ls)
        } else {
            val sh = shapes?.firstOrNull { it.key == k }
            WGroup(k, ls.first().country.trim().ifBlank { "No country" }, sh, ls)
        }
    }.sortedWith(compareByDescending<WGroup> { it.leagues.size }.thenBy { it.label })

/** Keys of the countries that light up (own leagues, or part of a region with leagues). */
internal fun hotKeys(groups: List<WGroup>): Set<String> =
    groups.mapNotNull { it.shape }.flatMap { if (it.members.isEmpty()) listOf(it.key) else it.members.toList() }.toSet()

/** Country key -> key of the region group it belongs to, for countries without leagues of their own. */
internal fun regionOfCountry(groups: List<WGroup>): Map<String, String> {
    val own = groups.filter { it.shape != null && it.shape.members.isEmpty() }.map { it.key }.toSet()
    val m = HashMap<String, String>()
    for (g in groups) g.shape?.members?.forEach { k -> if (k !in own) m[k] = g.key }
    return m
}

/** Which of the dotted countries belong to the chosen group (a country, or all countries of a region). */
internal fun pickSetFor(list: List<GeoShape>?, key: String?, groups: List<WGroup>): BooleanArray {
    if (list == null || key.isNullOrEmpty()) return BooleanArray(list?.size ?: 0)
    val ms = groups.firstOrNull { it.key == key }?.shape?.members?.takeIf { it.isNotEmpty() } ?: setOf(key)
    return BooleanArray(list.size) { list[it].key in ms }
}

@Composable
fun WorldPage(vm: AppVM) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var shapes by remember { mutableStateOf(WorldGeo.cached()) }
    var failed by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        if (shapes == null) { failed = false; val r = WorldGeo.load(ctx); shapes = r; failed = r == null }
    }
    val sh = shapes
    val groups = remember(vm.leagues, sh) { buildGroups(vm, sh) }
    val sel = groups.firstOrNull { it.key == vm.worldCountry }
    val selShape = sel?.shape ?: sh?.firstOrNull { it.key == vm.worldCountry }
    val selLeague = vm.lg(vm.worldLeague)?.takeIf { l -> sel?.leagues?.any { it.id == l.id } == true }
    val leagueKeys = remember(groups) { groups.filter { it.shape != null }.map { it.key }.toSet() }
    val countryItems = remember(groups, u) { groups.mapNotNull { g -> g.shape?.let { PinItem(g.key, it.center.x, it.center.y, g.label, u.acc, g.leagues.size) } } }

    // ---- clubs of the chosen league, placed by their city
    val clubItems = remember { mutableStateMapOf<String, PinItem>() }
    var placing by remember { mutableStateOf(false) }

    // ---- camera
    var box by remember { mutableStateOf(IntSize.Zero) }
    var cam by remember { mutableStateOf<Cam?>(null) }
    var anim by remember { mutableStateOf<Job?>(null) }
    fun flyTo(target: Cam) {
        val from = cam ?: return
        anim?.cancel()
        anim = scope.launch {
            Animatable(0f).animateTo(1f, tween(450)) {
                cam = Cam(lerp(from.s, target.s, value), lerp(from.tx, target.tx, value), lerp(from.ty, target.ty, value))
            }
        }
    }
    fun targetCam(): Cam {
        val w = box.width.toFloat(); val h = box.height.toFloat()
        return selShape?.let { fitCam(it.focus, w, h) } ?: homeCam(w, h)
    }
    LaunchedEffect(box) { if (box.width > 0 && cam == null) cam = targetCam() }
    LaunchedEffect(vm.worldCountry, sh) { if (box.width > 0 && cam != null) flyTo(targetCam()) }

    LaunchedEffect(selLeague?.id, sh) {
        clubItems.clear()
        val l = selLeague ?: return@LaunchedEffect
        placing = true
        val inRegion = vm.regionFor(l.country) != null
        for (c in vm.clubs.filter { it.lid == l.id }) {
            var p = WorldGeo.parseGeo(c.geo)
            if (p == null && (c.city.isNotBlank() || (!Mode.wrestling && c.stadium.isNotBlank()))) {
                p = if (Mode.wrestling) (WorldGeo.locate(ctx, "", c.city, if (inRegion) "" else l.country, selShape?.bbox) ?: WorldGeo.locate(ctx, "", c.city, "", null))
                    else WorldGeo.locate(ctx, c.stadium, c.city, if (inRegion) "" else l.country, selShape?.bbox)
                if (p != null) vm.setClubGeo(c.id, WorldGeo.fmtGeo(p.first, p.second))     // remembered, and editable in the club form
            }
            if (p != null) clubItems[c.id] = PinItem(c.id, p.first, p.second, ab(c.name, c.short), hex(c.color), 1)
        }
        placing = false
        if (clubItems.isNotEmpty() && box.width > 0) {
            val v = clubItems.values
            val b = floatArrayOf(v.minOf { it.lon } - .3f, v.minOf { it.lat } - .3f, v.maxOf { it.lon } + .3f, v.maxOf { it.lat } + .3f)
            flyTo(fitCam(b, box.width.toFloat(), box.height.toFloat()))
        }
    }

    val items = if (selLeague != null) clubItems.values.toList() else countryItems
    val itemsNow by rememberUpdatedState(items)
    val shapesNow by rememberUpdatedState(sh)
    val clubMode = selLeague != null
    val clubModeNow by rememberUpdatedState(clubMode)
    val density = androidx.compose.ui.platform.LocalDensity.current
    val pinR = with(density) { 13.dp.toPx() }
    val textMeasurer = rememberTextMeasurer()

    val ocean = if (u.coral) u.track else u.sf
    val land = androidx.compose.ui.graphics.lerp(ocean, u.ink, if (u.dark) .26f else .30f)
    val withLeagues = u.acc.copy(alpha = .8f)
    val dots = remember { DotField() }
    val hot = remember(groups) { hotKeys(groups) }
    val hotIdx = remember(sh, hot) { BooleanArray(sh?.size ?: 0) { sh!![it].key in hot } }
    val pickSet = pickSetFor(sh, vm.worldCountry, groups)
    val memberGroup = remember(groups) { regionOfCountry(groups) }
    val memberGroupNow by rememberUpdatedState(memberGroup)
    val leagueKeysNow by rememberUpdatedState(leagueKeys)
    val pickColor = if (vm.worldCountry in leagueKeys) u.acc else u.ink.copy(alpha = .55f)
    val dotPx = with(density) { 3.6.dp.toPx() }
    val cardShape = RoundedCornerShape(minOf(u.r, 28.dp))

    TopRow(vm.backLabel, { vm.goBack() })
    val clubTotal = vm.clubs.size
    Tp("World", w("${groups.size} ${if (groups.size == 1) "country" else "countries"} · ${vm.leagues.size} leagues · $clubTotal clubs", "${groups.size} ${if (groups.size == 1) "country" else "countries"} · ${vm.leagues.size} promotions · $clubTotal wrestlers"))

    Column(Modifier.bd(top = 14.dp)) {
        Box(
            Modifier.fillMaxWidth().height(280.dp).clip(cardShape).background(ocean).onSizeChanged { box = it },
        ) {
            Canvas(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val c = cam ?: return@detectTransformGestures
                            anim?.cancel()
                            val w = box.width.toFloat(); val h = box.height.toFloat()
                            val minS = w / 360f
                            val ns = (c.s * zoom).coerceIn(minS, minS * 80f)
                            val z = ns / c.s
                            cam = clampCam(Cam(ns, centroid.x - (centroid.x - c.tx) * z + pan.x, centroid.y - (centroid.y - c.ty) * z + pan.y), w, h)
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { p ->
                            val c = cam ?: return@detectTapGestures
                            val w = box.width.toFloat(); val h = box.height.toFloat()
                            val pins = pinsFor(itemsNow, c, pinR * 2.1f)
                            val hit = pins.minByOrNull { hypot(it.x - p.x, it.y - p.y) }?.takeIf { hypot(it.x - p.x, it.y - p.y) <= pinR * 1.5f }
                            if (hit != null) {
                                if (hit.items.size > 1) {
                                    val b = floatArrayOf(hit.items.minOf { it.lon } - .4f, hit.items.minOf { it.lat } - .4f, hit.items.maxOf { it.lon } + .4f, hit.items.maxOf { it.lat } + .4f)
                                    flyTo(fitCam(b, w, h))
                                } else if (clubModeNow) vm.openClub(hit.items[0].id)
                                else { vm.worldCountry = hit.items[0].id; vm.worldLeague = "" }
                                return@detectTapGestures
                            }
                            val lon = (p.x - c.tx) / c.s; val lat = -(p.y - c.ty) / c.s
                            val s = shapesNow?.filter { val b = it.bbox; lon >= b[0] && lon <= b[2] && lat >= b[1] && lat <= b[3] && it.test(lon, lat) }
                                ?.minByOrNull { (it.bbox[2] - it.bbox[0]) * (it.bbox[3] - it.bbox[1]) }
                            vm.worldCountry = when {
                                s == null -> ""
                                s.key in leagueKeysNow -> s.key
                                else -> memberGroupNow[s.key] ?: s.key
                            }
                            vm.worldLeague = ""
                        }
                    },
            ) {
                val c = cam ?: return@Canvas
                val list = sh ?: return@Canvas
                drawDots(dots, list, c, dotPx, land, withLeagues, pickColor, hotIdx, pickSet)
                withTransform({ translate(c.tx, c.ty); scale(c.s, c.s, Offset.Zero) }) {
                    selShape?.let { drawPath(it.path, u.acc, style = Stroke(width = 2.2.dp.toPx() / c.s, join = StrokeJoin.Round)) }
                }
                // pins
                for (pv in pinsFor(items, c, pinR * 2.1f)) {
                    if (pv.x < -pinR || pv.y < -pinR || pv.x > size.width + pinR || pv.y > size.height + pinR) continue
                    val single = pv.items.size == 1
                    val it0 = pv.items[0]
                    val fill = if (single) it0.color else u.ink
                    val fg = if (single) inkOn(fill) else u.bg
                    val label = if (single) (if (clubMode) it0.label else it0.weight.toString()) else pv.items.sumOf { it.weight }.toString()
                    if (single && !clubMode && it0.id == vm.worldCountry) drawCircle(u.ink, pinR + 4.dp.toPx(), Offset(pv.x, pv.y), style = Stroke(2.dp.toPx()))
                    drawCircle(Color.Black.copy(alpha = .25f), pinR + 1.dp.toPx(), Offset(pv.x, pv.y + 1.dp.toPx()))
                    drawCircle(fill, pinR, Offset(pv.x, pv.y))
                    val txt = textMeasurer.measure(label, TextStyle(fontSize = if (label.length > 2) 9.sp else 11.sp, fontWeight = FontWeight.Bold, color = fg))
                    drawText(txt, topLeft = Offset(pv.x - txt.size.width / 2f, pv.y - txt.size.height / 2f))
                }
            }
            if (sh == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (failed) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Tx("Couldn't download the map. Check your connection.", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 24.dp), align = androidx.compose.ui.text.style.TextAlign.Center)
                    SmallBtn("Try again", "s") { tick++ }
                } else Tx("Loading the map...", 13 * u.fs, 600, u.mu)
            }
            if (sh != null) Box(
                Modifier.align(Alignment.TopStart).padding(12.dp).clip(CircleShape2).background(u.bg.copy(alpha = .72f)).padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Tx(
                    when {
                        selLeague != null -> if (placing) w("Placing clubs...", "Placing wrestlers...") else w("${clubItems.size} of ${vm.clubs.count { it.lid == selLeague.id }} clubs placed", "${clubItems.size} of ${vm.clubs.count { it.lid == selLeague.id }} wrestlers placed")
                        selShape != null -> selShape.label
                        else -> "Pinch to zoom · tap a country"
                    },
                    12 * u.fs, 700, u.ink,
                )
            }
            if (sh != null) Box(
                Modifier.align(Alignment.TopEnd).padding(12.dp).size(40.dp).clip(CircleShape2).background(u.menuBg)
                    .clickable { vm.mapFull = "world" },
                contentAlignment = Alignment.Center,
            ) { Ico("expand", 18.dp, u.ink, 1.9f) }
            if (cam != null && (selShape != null || cam!!.s > box.width / 360f * 1.05f)) Box(
                Modifier.align(Alignment.BottomEnd).padding(12.dp).size(44.dp).clip(CircleShape2).background(u.menuBg)
                    .clickable { vm.worldCountry = ""; vm.worldLeague = ""; flyTo(homeCam(box.width.toFloat(), box.height.toFloat())) },
                contentAlignment = Alignment.Center,
            ) { Ico("globe", 20.dp, u.ink, 1.9f) }
        }

        Spacer(Modifier.height(16.dp))
        if (vm.worldCountry.isNotEmpty() && (sel != null || selShape != null)) {
            val name = sel?.label ?: selShape?.label ?: ""
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Tx(flag(name) + name, 22 * u.fs, 800, maxLines = 1)
                    val lc = sel?.leagues?.size ?: 0
                    val cc = sel?.let { g -> vm.clubs.count { c -> g.leagues.any { it.id == c.lid } } } ?: 0
                    Tx(w("$lc ${if (lc == 1) "league" else "leagues"} · $cc clubs", "$lc ${if (lc == 1) "promotion" else "promotions"} · $cc wrestlers"), 13 * u.fs, 600, u.mu)
                }
                if (vm.worldCountry.startsWith("region:")) { Chip("Edit", false) { vm.editRegion(vm.worldCountry.removePrefix("region:")) }; Spacer(Modifier.width(8.dp)) }
                Chip("All countries", false) { vm.worldCountry = ""; vm.worldLeague = "" }
            }
            Spacer(Modifier.height(10.dp))
            if (sel == null) {
                Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 18.dp, vertical = 16.dp)) {
                    Tx(w("No leagues in $name yet.", "No promotions in $name yet."), 14 * u.fs, 500, u.mu)
                    Spacer(Modifier.height(8.dp))
                    SmallBtn(w("Add a league in $name", "Add a promotion in $name")) { vm.newLeague(name) }
                }
            } else {
                Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 18.dp, vertical = 2.dp)) {
                    sel.leagues.forEachIndexed { i, l ->
                        val on = selLeague?.id == l.id
                        KvRow(i == sel.leagues.lastIndex, Modifier.clickable { vm.worldLeague = if (on) "" else l.id }) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                Crest(l.color, l.color, l.logo, l.name.take(2).uppercase(), 40.dp)
                                Column {
                                    Tx(l.name, 15 * u.fs, 700, if (on) u.accInk else u.ink, maxLines = 1)
                                    Tx(w("${vm.clubs.count { it.lid == l.id }} clubs", "${vm.clubs.count { it.lid == l.id }} wrestlers") + if (l.season.isNotBlank()) w(" · ${l.season}", " · founded ${l.season}") else "", 12 * u.fs, 500, u.mu)
                                }
                            }
                            Tx(if (on) "Shown" else w("Show clubs", "Show wrestlers"), 12 * u.fs, 700, if (on) u.accInk else u.mu)
                        }
                    }
                }
                if (selLeague != null) {
                    StandingsCard(vm, selLeague, 8)
                    GlassBtn(w("League page", "Promotion page"), "trophy", Modifier.fillMaxWidth()) { vm.openLeague(selLeague.id) }
                }
            }
        } else {
            H3("Countries")
            if (groups.isEmpty()) EmptyBlock(w("No leagues yet. Add a league and give it a country, and it appears here.", "No promotions yet. Add a promotion and give it a country, and it appears here.")) { SmallBtn(w("Add a league", "Add a promotion")) { vm.newLeague() } }
            else Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 18.dp, vertical = 2.dp)) {
                groups.forEachIndexed { i, g ->
                    KvRow(i == groups.lastIndex, Modifier.clickable { vm.worldCountry = g.key; vm.worldLeague = "" }) {
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Tx(flag(g.label).ifBlank { "  " }.trim().ifBlank { "·" }, 22f, 500)
                            Column {
                                Tx(g.label, 15 * u.fs, 700, maxLines = 1)
                                Tx(g.leagues.joinToString(", ") { it.name }, 12 * u.fs, 500, u.mu, maxLines = 1)
                            }
                        }
                        Tx("${g.leagues.size}", 14 * u.fs, 700, u.mu)
                        Spacer(Modifier.width(8.dp))
                        Ico("chev", 16.dp, u.mu, 2f)
                    }
                }
            }
            H3("Regions")
            Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 18.dp, vertical = 2.dp)) {
                vm.regions.forEach { r ->
                    KvRow(false, Modifier.clickable { vm.editRegion(r.id) }) {
                        Column(Modifier.weight(1f)) {
                            Tx(r.name, 15 * u.fs, 700, maxLines = 1)
                            Tx(r.countries.joinToString(", "), 12 * u.fs, 500, u.mu, maxLines = 2)
                        }
                        Ico("edit", 18.dp, u.mu, 1.9f)
                    }
                }
                if (vm.regions.isEmpty()) Tx(w("Combine countries into one region, for example Balkans, and give its league that name as the country.", "Combine countries into one region, for example Scandinavia, and give its promotion that name as the country."), 13 * u.fs, 500, u.mu, Modifier.padding(vertical = 14.dp), lh = 13 * u.fs * 1.5f)
                Row(Modifier.padding(vertical = 10.dp)) { SmallBtn("New region") { vm.editRegion(null) } }
            }
            if (sh != null && groups.any { it.shape == null }) Tx(w("Some countries aren't on the map because the name isn't recognised. Check the spelling in the league.", "Some countries aren't on the map because the name isn't recognised. Check the spelling in the promotion."), 12 * u.fs, 500, u.mu, Modifier.padding(horizontal = 6.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

private val CircleShape2 = androidx.compose.foundation.shape.CircleShape
