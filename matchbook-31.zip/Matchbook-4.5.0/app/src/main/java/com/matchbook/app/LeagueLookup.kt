package com.matchbook.app

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

// =====================================================================================================
// League lookup (3.7): type "Premier League", pick the league, and the form fills itself in.
//   TheSportsDB   name, country, current season, logo, banner. Its list of football leagues is downloaded once
//                 and kept on the phone, so the search itself works offline afterwards.
//   Wikipedia     fallback when TheSportsDB is down or doesn't know the league (name and logo)
// The colour is taken from the logo. Everything lands in the normal form fields, so it stays editable.
// =====================================================================================================

data class OlLeague(
    val id: String, val name: String, val country: String, val season: String,
    val badge: String, val banner: String, val formed: String,
)

object OlLeagues {
    private const val KEY = "123"
    private const val FILE = "tsdb-leagues.json"

    private fun JSONObject.t(k: String): String = if (isNull(k)) "" else optString(k, "").trim().let { if (it == "null") "" else it }

    private class Row(val id: String, val name: String, val alt: String)

    /** Every football league TheSportsDB knows (id, name, alternate names). Downloaded once. */
    private fun all(ctx: Context): List<Row> {
        val f = File(ctx.filesDir, FILE)
        var text: String? = if (f.exists() && f.length() > 2_000) runCatching { f.readText() }.getOrNull() else null
        if (text == null) {
            text = String(OlNet.bytes("https://www.thesportsdb.com/api/v1/json/$KEY/all_leagues.php"), Charsets.UTF_8)
            if (text.length > 2_000) runCatching { f.writeText(text) }
        }
        val a = JSONObject(text).optJSONArray("leagues") ?: return emptyList()
        val out = ArrayList<Row>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!o.t("strSport").equals("Soccer", true)) continue
            out.add(Row(o.t("idLeague"), o.t("strLeague"), o.t("strLeagueAlternate")))
        }
        return out
    }

    private val details = HashMap<String, OlLeague>()

    /** One league's details, remembered while the app runs so repeated searches don't use up the free request limit. */
    private fun detail(id: String): OlLeague? {
        synchronized(details) { details[id]?.let { return it } }
        val d = fetchDetail(id)
        if (d != null) synchronized(details) { details[id] = d }
        return d
    }

    /** A result that only has its name (the details were refused or slow) gets them when it is picked. */
    fun complete(l: OlLeague): OlLeague =
        if (l.id.startsWith("wp:") || l.badge.isNotBlank() || l.country.isNotBlank()) l
        else runCatching { detail(l.id) }.getOrNull() ?: l

    private fun fetchDetail(id: String): OlLeague? {
        val a = OlNet.json("https://www.thesportsdb.com/api/v1/json/$KEY/lookupleague.php?id=$id").optJSONArray("leagues") ?: return null
        if (a.length() == 0) return null
        val o = a.getJSONObject(0)
        return OlLeague(
            id = id, name = o.t("strLeague"), country = o.t("strCountry"), season = o.t("strCurrentSeason"),
            badge = o.t("strBadge").ifBlank { o.t("strLogo") },
            banner = o.t("strBanner").ifBlank { o.t("strFanart1") }.ifBlank { o.t("strPoster") },
            formed = o.t("intFormedYear").takeIf { it.length == 4 && it != "0000" }.orEmpty(),
        )
    }

    /** TheSportsDB first; if it is down, refuses us or knows nothing, fall back to Wikipedia. */
    fun search(ctx: Context, q: String): List<OlLeague> {
        var err: Exception? = null
        val a = try { searchDb(ctx, q) } catch (e: Exception) { err = e; emptyList() }
        if (a.isNotEmpty()) return a
        val b = try { searchWiki(q) } catch (e: Exception) { if (err == null) err = e; emptyList() }
        if (b.isEmpty() && err != null) throw err
        return b
    }

    private fun searchDb(ctx: Context, q: String): List<OlLeague> {
        val want = q.trim().lowercase()
        val toks = want.split(' ', '-').filter { it.isNotBlank() }
        if (toks.isEmpty()) return emptyList()
        val hits = all(ctx).filter { r -> val h = (r.name + " " + r.alt).lowercase(); toks.all { h.contains(it) } }
            .sortedWith(compareBy({ if (it.name.equals(want, true)) 0 else if (it.name.lowercase().startsWith(want)) 1 else 2 }, { it.name.length }))
            .take(6)
        // The details (country, season, logo) are fetched side by side. If TheSportsDB refuses some of them (the free
        // key allows about 30 requests a minute) the league still shows by name and is completed when you pick it.
        val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
        try {
            val jobs = hits.map { r -> pool.submit(java.util.concurrent.Callable { runCatching { detail(r.id) }.getOrNull() }) }
            return hits.mapIndexed { i, r ->
                (runCatching { jobs[i].get(25, java.util.concurrent.TimeUnit.SECONDS) }.getOrNull())
                    ?: OlLeague(r.id, r.name, "", "", "", "", "")
            }
        } finally { pool.shutdown() }
    }

    private fun searchWiki(q: String): List<OlLeague> {
        val j = OlNet.json("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=8&format=json&srsearch=${OlNet.enc("$q football league")}")
        val a = j.getJSONObject("query").getJSONArray("search")
        val out = ArrayList<OlLeague>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i).optString("title")
            if (t.isBlank() || !Regex("(?i)(league|liga|division|championship|cup|serie|ligue|bundesliga|premier|eredivisie|superliga|super lig)").containsMatchIn(t)) continue
            out.add(OlLeague("wp:$t", t, "", "", "", "", ""))
        }
        return out
    }

    /** The logo of a Wikipedia article, for results that came from Wikipedia. */
    fun wikiThumb(title: String): String = runCatching {
        OlNet.json("https://en.wikipedia.org/api/rest_v1/page/summary/${OlNet.enc(title.replace(' ', '_')).replace("+", "%20")}")
            .optJSONObject("thumbnail")?.optString("source").orEmpty()
    }.getOrDefault("")

    /** "2025-2026" -> "2025/26", "2026" stays. */
    fun season(s: String): String {
        val m = Regex("""^(\d{4})\s*[-/]\s*(\d{4})$""").find(s.trim()) ?: return s.trim()
        return m.groupValues[1] + "/" + m.groupValues[2].takeLast(2)
    }
}

/** Button for the league form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun LeagueLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a league name, pick it, and country, season, logo, colour and banner are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) LeagueLookupSheet(d) { open = false }
}

@Composable
private fun LeagueLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    // search while typing: a moment after the last key
    LaunchedEffect(q) { if (q.trim() != query) { delay(600); query = q.trim() } }
    val res = olLoad<List<OlLeague>>(query to tick) { if (query.isBlank()) emptyList() else OlLeagues.search(ctx, query) }

    fun apply(picked: OlLeague) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val l = withContext(Dispatchers.IO) { OlLeagues.complete(picked) }
            val (logo, banner) = withContext(Dispatchers.IO) {
                val url = l.badge.ifBlank { if (l.id.startsWith("wp:")) OlLeagues.wikiThumb(l.name) else "" }
                val b = if (url.isNotBlank()) OlImages.load(url, 512, useCache = false) else null
                val bn = if (l.banner.isNotBlank()) OlImages.load(l.banner, 1400, useCache = false) else null
                b to bn
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", l.name); put("country", l.country); put("season", OlLeagues.season(l.season))
            if (logo != null) {
                if (replace || d["color"].isBlank() || d["color"] == "#2da678") OlClubs.crestColors(logo).firstOrNull()?.let { d["color"] = it }
                if (replace || d["logo"].isBlank()) d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, logo) }
            } else if (l.badge.isNotBlank()) note = "Filled in, but the logo couldn't be downloaded."
            if (banner != null && (replace || d["banner"].isBlank())) d["banner"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, banner) }
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("League name", q, { q = it }, ph = "e.g. Premier League")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a league name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the English name.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { l ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(l) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (l.badge.isNotBlank()) OlThumb(l.badge, Modifier.size(46.dp))
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(l.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(listOf(l.country, OlLeagues.season(l.season)).filter { it.isNotBlank() }.joinToString(" · "), 12 * u.fs, 500, u.mu, maxLines = 1)
                                }
                                if (l.formed.isNotBlank()) Tx(l.formed, 12 * u.fs, 600, u.mu)
                            }
                        }
                    }
                }
            }
        }
    }
}
