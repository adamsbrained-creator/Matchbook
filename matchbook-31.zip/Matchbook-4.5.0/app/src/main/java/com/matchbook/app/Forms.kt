package com.matchbook.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun FRow(gap: Int = 12, content: @Composable RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap.dp), content = content)

/** A glass card that groups a few form fields under a title. */
@Composable
fun FormCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val u = LocalU.current
    Glass(Modifier.fillMaxWidth().padding(bottom = 14.dp), pad = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Tx(title, 15 * u.fs, 800)
        content()
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
fun LeagueForm(vm: AppVM, d: Draft) {
    val ed = d.eid != null
    val others = vm.leagues.filter { it.id != d.eid }.map { it.id to it.name }
    TopRow(vm.backLabel, { vm.goBack() })
    Tp(if (ed) w("Edit league", "Edit promotion") else w("New league", "New promotion"), w("League details", "Promotion details"))
    Column(Modifier.bd(top = 18.dp, bottom = 20.dp)) {
        FormCard("Basics") {
            if (Mode.wrestling) PromotionLookup(d) else LeagueLookup(d)
            Fld(w("League name", "Promotion name"), d["name"], { d["name"] = it }, ph = w("Premier League", "World Wrestling Entertainment"))
            FRow {
                CountryField(d["country"], { d["country"] = it }, Modifier.weight(1f))
                Fld(w("Season", "Founded"), d["season"], { d["season"] = it }, Modifier.weight(1f), ph = w("2026/27", "1953"))
            }
        }
        FormCard("Look") {
            Upload("Logo", d, "logo")
            Upload("Banner", d, "banner", 4f)
            ColorField(w("League colour", "Promotion colour"), d["color"]) { d["color"] = it }
        }
        FormCard(w("Rules", "Rankings rules")) {
            FRow {
                Fld("Points per win", d["pw"], { d["pw"] = it }, Modifier.weight(1f), number = true)
                Fld("Points per draw", d["pd"], { d["pd"] = it }, Modifier.weight(1f), number = true)
            }
            FRow {
                Fld(w("Promotion spots", "Call-up spots"), d["promo"], { d["promo"] = it }, Modifier.weight(1f), number = true)
                Fld(w("Relegation spots", "Send-down spots"), d["rel"], { d["rel"] = it }, Modifier.weight(1f), number = true)
            }
        }
        FormCard(w("Qualification spots", "Rank tiers")) {
            Tx(w("Badges for places in the table, like Champions League for places 1 to 4. They show beside the club in the table and in the table legend.", "Badges for places in the rankings, like Title picture for places 1 to 3. They show beside the wrestler in the rankings and in the legend."),
                12 * LocalU.current.fs, 500, LocalU.current.mu, Modifier.padding(bottom = 6.dp), lh = 12 * LocalU.current.fs * 1.5f)
            val quals = parseQuals(d["quals"])
            fun save(l: List<Qual>) { d["quals"] = encodeQuals(l) }
            quals.forEachIndexed { i, q ->
                Column(Modifier.padding(top = 10.dp)) {
                    Fld("Name", q.name, { v -> save(quals.mapIndexed { n, o -> if (n == i) Qual(v, o.from, o.to, o.color) else o }) }, ph = w("Champions League", "Title picture"))
                    FRow {
                        Fld("From place", q.from.toString(), { v -> save(quals.mapIndexed { n, o -> if (n == i) Qual(o.name, v.filter(Char::isDigit).toIntOrNull() ?: 0, o.to, o.color) else o }) }, Modifier.weight(1f), number = true)
                        Fld("To place", q.to.toString(), { v -> save(quals.mapIndexed { n, o -> if (n == i) Qual(o.name, o.from, v.filter(Char::isDigit).toIntOrNull() ?: 0, o.color) else o }) }, Modifier.weight(1f), number = true)
                    }
                    ColorField("Badge colour", q.color) { v -> save(quals.mapIndexed { n, o -> if (n == i) Qual(o.name, o.from, o.to, v) else o }) }
                    SmallBtn(w("Remove spot", "Remove tier"), "s") { save(quals.filterIndexed { n, _ -> n != i }) }
                }
            }
            Spacer(Modifier.height(12.dp))
            val next = (quals.maxOfOrNull { maxOf(it.from, it.to) } ?: 0) + 1
            DashedBtn(w("Add qualification spot", "Add rank tier"), "plus") { save(quals + Qual("", next, next, "#3b82f6")) }
            if (quals.isEmpty()) Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (Mode.wrestling) Chip("Title picture 1-3", false) { save(listOf(Qual("Title picture", 1, 3, "#f5b301"), Qual("Contenders", 4, 6, "#38bdf8"), Qual("Midcard", 7, 9, "#16a34a"))) }
                else Chip("Champions League 1-4", false) { save(listOf(Qual("Champions League", 1, 4, "#1d4ed8"), Qual("Europa League", 5, 5, "#f97316"), Qual("Conference League", 6, 6, "#16a34a"))) }
            }
        }
        FormCard(w("Groups or conferences", "Brands or blocks")) {
            Tx(w("Optional. Use it when the league is split, like the Eastern and Western Conference, or Group A and Group B. Then set each club's group in its editor and the table gets a tab for every group.", "Optional. Use it when the promotion is split into brands (Raw and SmackDown) or tournament blocks (Block A and Block B). Then set each wrestler's brand in the wrestler editor and the rankings get a tab for every brand."),
                12 * LocalU.current.fs, 500, LocalU.current.mu, Modifier.padding(bottom = 6.dp), lh = 12 * LocalU.current.fs * 1.5f)
            Fld("Names, one per line", d["groups"], { d["groups"] = it }, multi = true, ph = w("Eastern Conference\nWestern Conference", "Raw\nSmackDown"))
            Row(Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (Mode.wrestling) {
                    Chip("Raw / SmackDown", false) { d["groups"] = "Raw\nSmackDown" }
                    Chip("Blocks A-B", false) { d["groups"] = "Block A\nBlock B" }
                    Chip("Blocks A-D", false) { d["groups"] = "Block A\nBlock B\nBlock C\nBlock D" }
                    Chip("Main / Developmental", false) { d["groups"] = "Main roster\nDevelopmental" }
                    Chip("Men / Women", false) { d["groups"] = "Men\nWomen" }
                } else {
                    Chip("East / West", false) { d["groups"] = "Eastern Conference\nWestern Conference" }
                    Chip("Groups A-B", false) { d["groups"] = "Group A\nGroup B" }
                    Chip("Groups A-D", false) { d["groups"] = "Group A\nGroup B\nGroup C\nGroup D" }
                    Chip("North / South", false) { d["groups"] = "North\nSouth" }
                }
                if (d["groups"].isNotBlank()) Chip("Clear", true) { d["groups"] = "" }
            }
        }
        FormCard(w("League links", "Feeder links")) {
            DropSelect(w("Promotion to", "Call-ups go to"), vm.lg(d["promoTo"])?.name ?: "", others, { d["promoTo"] = it }, none = "None")
            DropSelect(w("Relegation to", "Send-downs go to"), vm.lg(d["relTo"])?.name ?: "", others, { d["relTo"] = it }, none = "None")
        }
        if (ed) DeleteBtn(w("Delete league and its clubs", "Delete promotion and its wrestlers"), 0.dp) { vm.deleteLeague(d.eid!!) }
        Spacer(Modifier.height(100.dp))
    }
}

@Composable
fun ClubForm(vm: AppVM, d: Draft) {
    val u = LocalU.current
    val ed = d.eid != null
    TopRow(vm.backLabel, { vm.goBack() })
    Tp(if (ed) w("Edit club", "Edit wrestler") else w("New club", "New wrestler"), w("Club details", "Wrestler, tag team or stable"))
    Column(Modifier.bd(top = 18.dp, bottom = 20.dp)) {
        FormCard("Identity") {
            if (Mode.wrestling) WrestlerLookup(d) else ClubLookup(d)
            Fld(w("Club name", "Ring name"), d["name"], { d["name"] = it }, ph = w("Metalist", "Marcus Steel"))
            FRow {
                Fld("Short name", d["short"], { d["short"] = it }, Modifier.weight(1f), ph = w("ME", "MST"))
                Fld("Nickname", d["nick"], { d["nick"] = it }, Modifier.weight(1f), ph = w("", "The Iron Tribune"))
            }
            DropSelect(w("League", "Promotion"), vm.lg(d["lid"])?.name ?: "", vm.leagues.map { it.id to it.name }, { d["lid"] = it; d["grp"] = "" }, none = null)
            val grps = vm.lg(d["lid"])?.let { leagueGroups(it) } ?: emptyList()
            if (grps.isNotEmpty()) DropSelect(w("Group", "Brand or block"), d["grp"], grps.map { it to it }, { d["grp"] = it }, none = w("No group", "No brand"))
        }
        FormCard("Basics") {
            FRow {
                Fld(w("City", "Hometown"), d["city"], { d["city"] = it }, Modifier.weight(1f), ph = w("", "Pittsburgh"))
                Fld(w("Founded", "Debut year"), d["founded"], { d["founded"] = it }, Modifier.weight(1f), number = true, ph = w("1925", "2011"))
            }
            Fld("Map position", d["geo"], { d["geo"] = it }, ph = w("53.4308, -2.9608 (latitude, longitude)", "40.4406, -79.9959 (latitude, longitude)"))
            FindOnMap(vm, d)
            FRow {
                Fld(w("Stadium", "Finisher"), d["stadium"], { d["stadium"] = it }, Modifier.weight(1f), ph = w("", "Steel Driver"))
                Fld(w("Capacity", "Height (cm)"), d["cap"], { d["cap"] = it }, Modifier.weight(1f), number = true)
            }
            FRow {
                Fld("Manager", d["mgr"], { d["mgr"] = it }, Modifier.weight(1f))
                Fld(w("Chairman", "Trainer"), d["chair"], { d["chair"] = it }, Modifier.weight(1f))
            }
        }
        FormCard(w("Crest and colours", "Photo and colours")) {
            Upload(w("Crest image (optional)", "Photo or logo (optional)"), d, "logo")
            if (d["logo"].isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx(w("Show club colours behind logo", "Show gear colours behind the picture"), 14 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(d["logoBg"] == "1") { d["logoBg"] = if (d["logoBg"] == "1") "0" else "1" }
                }
            }
            ColorField(w("Main colour", "Main gear colour"), d["color"]) { d["color"] = it }
            ColorField(w("Second colour", "Second gear colour"), d["c2"]) { d["c2"] = it }
        }
        FormCard(w("Season record", "Match record")) {
            FRow(10) { for ((k, t) in listOf("w" to "Won", "d" to w("Drawn", "Draws"), "l" to "Lost")) Fld(t, d[k], { d[k] = it }, Modifier.weight(1f), number = true) }
            FRow(10) { for ((k, t) in listOf("gf" to w("Goals for", "Falls for"), "ga" to "Against", "titles" to w("Titles", "Title reigns"))) Fld(t, d[k], { d[k] = it }, Modifier.weight(1f), number = true) }
        }
        FormCard("Story") {
            Fld(w("Honours", "Championships"), d["hon"], { d["hon"] = it }, ph = "One per line", multi = true)
            Fld("About", d["info"], { d["info"] = it }, multi = true)
        }
        if (ed) DeleteBtn(w("Delete club", "Delete wrestler"), 0.dp) { vm.deleteClub(d.eid!!) }
        Spacer(Modifier.height(100.dp))
    }
}

@Composable
fun FixtureForm(vm: AppVM, d: Draft) {
    val ed = d.eid != null
    val inLeague = vm.clubs.filter { it.lid == d["lid"] }.map { it.id to it.name }
    TopRow(vm.backLabel, { vm.goBack() })
    Tp(if (ed) w("Edit fixture", "Edit match") else w("New fixture", "New match"), w("Schedule a match", "Book a match"))
    Column(Modifier.bd(top = 18.dp, bottom = 20.dp)) {
        FormCard("Match") {
            DropSelect(w("League", "Promotion"), vm.lg(d["lid"])?.name ?: "", vm.leagues.map { it.id to it.name }, {
                d["lid"] = it; d["home"] = ""; d["away"] = ""
            }, none = null)
            if (Mode.wrestling) {
                DropSelect("Corner A", vm.cl(d["home"])?.name ?: "", inLeague, { d["home"] = it }, none = null)
                DropSelect("Corner B", vm.cl(d["away"])?.name ?: "", inLeague, { d["away"] = it }, none = null)
                Fld("Match type", d["st"], { d["st"] = it }, ph = "Steel cage, Ladder, Triple threat...")
                Row(Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Singles", "Tag team", "Triple threat", "Fatal four-way", "Ladder", "Steel cage", "Hell in a Cell", "Last man standing", "Iron man", "Battle royal", "Title match").forEach { t ->
                        Chip(t, d["st"] == t) { d["st"] = t }
                    }
                }
            } else {
                DropSelect("Home club", vm.cl(d["home"])?.name ?: "", inLeague, {
                    d["home"] = it
                    if (d["venue"].isBlank()) d["venue"] = vm.cl(it)?.stadium ?: ""
                }, none = null)
                DropSelect("Away club", vm.cl(d["away"])?.name ?: "", inLeague, { d["away"] = it }, none = null)
            }
        }
        FormCard("When and where") {
            DateTimeField(d["at"].toLongOrNull() ?: System.currentTimeMillis()) { d["at"] = it.toString() }
            if (Mode.wrestling) Fld("Event or show", d["ev"], { d["ev"] = it }, ph = "WrestleMania, Dynamite, G1 Climax...")
            Fld("Venue", d["venue"], { d["venue"] = it }, ph = w("Stadium", "Arena"))
        }
        if (ed) DeleteBtn(w("Delete fixture", "Delete match"), 0.dp) { vm.deleteFixture(d.eid!!) }
        Spacer(Modifier.height(100.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateTimeField(at: Long, onChange: (Long) -> Unit) {
    val u = LocalU.current
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(at).atZone(zone)
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    val surface = if (u.coral) u.menuBg else if (u.dark) Color(0xFF16181D) else Color.White

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1.4f)) {
            Lbl("Date")
            Box(Modifier.fillMaxWidth().field().clickable { showDate = true }.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Tx(dt.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault())), 15 * u.fs, 600, maxLines = 1)
            }
        }
        Column(Modifier.weight(1f)) {
            Lbl("Time")
            Box(Modifier.fillMaxWidth().field().clickable { showTime = true }.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Tx(dt.format(DateTimeFormatter.ofPattern("HH:mm")), 15 * u.fs, 600, maxLines = 1)
            }
        }
    }

    if (showDate) {
        val st = rememberDatePickerState(initialSelectedDateMillis = dt.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { ms ->
                        val day = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        onChange(day.atTime(dt.toLocalTime()).atZone(zone).toInstant().toEpochMilli())
                    }
                    showDate = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Cancel") } },
        ) { DatePicker(state = st) }
    }

    if (showTime) {
        val ts = rememberTimePickerState(dt.hour, dt.minute, true)
        Dialog(onDismissRequest = { showTime = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(shape = RoundedCornerShape(if (u.coral) 32.dp else 28.dp), color = surface) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    TimePicker(state = ts)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showTime = false }) { Text("Cancel") }
                        TextButton(onClick = {
                            onChange(dt.toLocalDate().atTime(ts.hour, ts.minute).atZone(zone).toInstant().toEpochMilli())
                            showTime = false
                        }) { Text("OK") }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerForm(vm: AppVM, d: Draft) {
    val ed = d.eid != null
    val club = vm.cl(d["cid"])
    TopRow(vm.backLabel, { vm.goBack() })
    Tp(if (ed) w("Edit player", "Edit member") else w("New player", "New member"), club?.name ?: w("Squad", "Stable"))
    Column(Modifier.bd(top = 18.dp, bottom = 20.dp)) {
        FormCard(w("Player", "Member")) {
            Fld(w("Name", "Ring name"), d["name"], { d["name"] = it }, ph = w("Player name", "Wrestler or manager"))
            FRow {
                Fld("Number", d["num"], { d["num"] = it }, Modifier.weight(1f), number = true)
                DropSelect(w("Position", "Card position"), POS_NAMES.firstOrNull { it.first == d["pos"] }?.second ?: "", POS_NAMES, { d["pos"] = it }, Modifier.weight(1.4f))
            }
            Upload("Render (picture or cut-out)", d, "img")
            OnlineLookup(d["name"], { n, pos -> d["name"] = n; if (pos.isNotBlank()) d["pos"] = pos }, { d["img"] = it })
        }
        if (ed) DeleteBtn(w("Delete player", "Delete member"), 0.dp) { vm.deletePlayer(d.eid!!) }
        Spacer(Modifier.height(100.dp))
    }
}

/** Looks up the club's stadium (or city) on OpenStreetMap and fills in the map position. */
@Composable
private fun FindOnMap(vm: AppVM, d: Draft) {
    val u = LocalU.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var st by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SmallBtn(if (busy) "Searching..." else "Find on map", "s") {
            if (busy) return@SmallBtn
            if (if (Mode.wrestling) d["city"].isBlank() else (d["stadium"].isBlank() && d["city"].isBlank())) { st = w("Add a stadium or a city first", "Add a hometown first"); return@SmallBtn }
            busy = true; st = ""
            scope.launch {
                val lg = vm.lg(d["lid"])
                val reg = lg?.let { vm.regionFor(it.country) }
                val country = if (reg != null) "" else lg?.country.orEmpty()
                val shapes = WorldGeo.load(ctx)
                val near = if (reg != null) shapes?.let { WorldGeo.regionShape(reg, it) }?.bbox else WorldGeo.find(shapes, country)?.bbox
                val r = if (Mode.wrestling) (WorldGeo.locate(ctx, "", d["city"], country, near) ?: WorldGeo.locate(ctx, "", d["city"], "", null)) else WorldGeo.locate(ctx, d["stadium"], d["city"], country, near)
                busy = false
                if (r != null) { d["geo"] = WorldGeo.fmtGeo(r.first, r.second); st = "Found" } else st = w("Not found. Check the stadium and city, or type the position.", "Not found. Check the hometown, or type the position.")
            }
        }
        if (st.isNotEmpty()) Tx(st, 12 * u.fs, 600, u.mu, Modifier.weight(1f), maxLines = 2)
    }
}
