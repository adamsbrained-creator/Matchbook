package com.matchbook.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================================================================
// Modes (4.5): the app is Matchbook (football) or Ringbook (pro wrestling).
// Each mode keeps its own data (its own storage), settings and backups, so switching never touches the other one.
// Screens read [Mode.wrestling], so changing it redraws everything with the other words and features.
// =====================================================================================================

object Mode {
    /** True in Ringbook mode. A Compose state, so screens redraw when it changes. */
    var wrestling by mutableStateOf(false)

    /** False until the person has picked a mode once (the first start shows the picker). */
    var chosen by mutableStateOf(false)

    private fun prefs(c: Context) = c.getSharedPreferences("matchbook-mode", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        wrestling = p.getBoolean("wrestling", false)
        chosen = p.getBoolean("chosen", false)
    }

    fun set(c: Context, wrestlingMode: Boolean) {
        prefs(c).edit().putBoolean("wrestling", wrestlingMode).putBoolean("chosen", true).apply()
        wrestling = wrestlingMode
        chosen = true
    }
}

/** The word for football mode, or for Ringbook mode. */
fun w(football: String, wrestling: String): String = if (Mode.wrestling) wrestling else football

/** First start: pick Matchbook or Ringbook. Drawn before the app itself exists, so it brings its own colours. */
@Composable
fun ModePicker(onPick: (Boolean) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color(0xFF0B0C0F)).safeDrawingPadding().padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        BasicText("Welcome", style = TextStyle(color = Color(0xFFF5F5F5), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold))
        Spacer(Modifier.height(8.dp))
        BasicText(
            "Pick what you want to keep track of. Each one has its own data, and you can switch any time in Settings.",
            style = TextStyle(color = Color(0xFF9A9CA3), fontSize = 14.sp, lineHeight = 21.sp),
        )
        Spacer(Modifier.height(26.dp))
        ModeCard("Matchbook", "Football: clubs, leagues, tables, fixtures, squads and lineups.", Color(0xFFC8F26B)) { onPick(false) }
        Spacer(Modifier.height(14.dp))
        ModeCard("Ringbook", "Pro wrestling: wrestlers, promotions, rankings, matches, stables and a ring board.", Color(0xFFFFC23D)) { onPick(true) }
    }
}

@Composable
private fun ModeCard(title: String, text: String, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF16181D)).border(1.5.dp, accent.copy(alpha = .55f), shape)
            .clickable(onClick = onClick).padding(20.dp),
    ) {
        BasicText(title, style = TextStyle(color = accent, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold))
        Spacer(Modifier.height(6.dp))
        BasicText(text, style = TextStyle(color = Color(0xFFD6D7DB), fontSize = 14.sp, lineHeight = 20.sp))
    }
}
