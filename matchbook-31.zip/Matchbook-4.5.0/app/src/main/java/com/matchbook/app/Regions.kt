package com.matchbook.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// =====================================================================================================
// Regions (3.5): combine countries into one, for example "Balkans" with Serbia, Croatia, Moldova...
// Give a league the region's name as its country and it belongs to the whole region: the region lights
// up on the map as one area, and shows as one entry on the Home page and the World page.
// =====================================================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RegionDialog(vm: AppVM, d: Draft) {
    val u = LocalU.current
    var q by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val all = remember { (WorldGeo.cached()?.map { it.label } ?: COUNTRIES.map { it.first }).distinct().sorted() }
    val chosen = d["countries"].split("|").filter { it.isNotBlank() }
    fun setList(l: List<String>) { d["countries"] = l.joinToString("|") }
    Dialog(onDismissRequest = { vm.regionEdit = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(.94f).heightIn(max = 680.dp).clip(RoundedCornerShape(32.dp))
                .background(if (u.coral) u.menuBg else if (u.dark) androidx.compose.ui.graphics.Color(0xFF16181D) else androidx.compose.ui.graphics.Color.White)
                .verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Hd(if (d.eid == null) "New region" else "Edit region", 26f)
            Tx(
                w("A region is one area made of several countries. Give a league the region's name as its country and it plays for the whole region, ", "A region is one area made of several countries. Give a promotion the region's name as its country and it runs for the whole region, ") +
                    w("for example a Balkans league with the best clubs of each country.", "for example a Scandinavian promotion with wrestlers from each country."),
                13 * u.fs, 500, u.mu, lh = 13 * u.fs * 1.5f,
            )
            Fld("Name", d["name"], { d["name"] = it; err = "" }, ph = w("Balkans", "Scandinavia"))
            Lbl("Countries (${chosen.size})")
            if (chosen.isEmpty()) Tx("None yet. Pick at least two below.", 13 * u.fs, 500, u.mu)
            else FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                chosen.forEach { n -> Chip("${flag(n)}$n  ×", true) { setList(chosen - n); err = "" } }
            }
            Fld("Add a country", q, { q = it }, ph = "Start typing")
            val hits = (if (q.isBlank()) COUNTRIES.map { it.first } else all.filter { it.contains(q.trim(), true) }).filter { it !in chosen }.take(10)
            if (hits.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                hits.forEach { n -> Chip("${flag(n)}$n", false) { setList(chosen + n); q = ""; err = "" } }
            }
            if (err.isNotEmpty()) Tx(err, 13 * u.fs, 700, u.red)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallBtn("Save") { val e = vm.saveRegion(d); if (e == null) vm.regionEdit = null else err = e }
                SmallBtn("Cancel", "s") { vm.regionEdit = null }
            }
            d.eid?.let { id -> DeleteBtn("Delete region", 0.dp) { vm.deleteRegion(id); vm.regionEdit = null } }
        }
    }
}
