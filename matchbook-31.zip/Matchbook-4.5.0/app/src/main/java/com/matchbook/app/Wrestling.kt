package com.matchbook.app

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.Normalizer

// =====================================================================================================
// Ringbook mode: the web lookups for wrestlers, tag teams, stables and promotions.
//   Wikipedia   search, summary text, lead photo and the wrestler infobox (debut, trainer, billed height)
//   Wikidata    birthplace with its map coordinates, country, height, birth year, founding year
//   TheSportsDB extra cut-outs / renders when it knows the wrestler (free test key)
//   Wikimedia Commons  dated photos (shared with Matchbook mode, see Online.kt)
// Everything lands in the normal form fields, so it stays editable. Missing data is simply left blank.
// =====================================================================================================

private fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "").trim()

/** What the detail page shows: [facts] are label / value rows, [about] the opening paragraphs of the article. */
data class OlWStats(
    val who: String, val desc: String, val photo: String,
    val facts: List<Pair<String, String>>, val about: String,
)

/** Everything the web lookups know about one article. Missing parts stay blank. */
data class OlProfile(
    val title: String = "", val desc: String = "", val about: String = "", val thumb: String = "",
    val birthPlace: String = "", val geo: String = "", val country: String = "", val debut: String = "",
    val trainer: String = "", val billed: String = "", val heightCm: String = "", val born: String = "",
    val inception: String = "", val ringNames: String = "",
)

/** Country names from Wikidata mapped onto the names the app uses ("United States of America" -> "USA"). */
fun olCountry(label: String): String {
    val t = label.trim()
    if (t.isEmpty()) return ""
    val alias = mapOf(
        "united states of america" to "USA", "united states" to "USA", "united kingdom" to "England",
        "czech republic" to "Czechia", "republic of ireland" to "Ireland", "kingdom of the netherlands" to "Netherlands",
        "people's republic of china" to "China", "republic of korea" to "South Korea", "korea, south" to "South Korea",
    )
    alias[t.lowercase()]?.let { return it }
    return COUNTRIES.find { it.first.equals(t, true) }?.first ?: t
}

// -------------------------------------------------------------------------------- Wikipedia + Wikidata
object OlWiki {
    private const val API = "https://en.wikipedia.org/w/api.php"
    private val WRESTLING = Regex("(?i)(wrestl|tag team|stable|faction|promotion|lucha|puroresu|sumo|valet|manager)")

    /** A hit from the Wikipedia search: title, the short description and a lead photo. */
    class Hit(val title: String, val desc: String, val thumb: String)

    private fun wikiPath(title: String) = OlNet.enc(title.replace(' ', '_')).replace("+", "%20")

    /** Articles matching [q] that look like wrestling. If none do, everything found is returned so nothing is hidden. */
    fun search(q: String, extra: String): List<Hit> {
        val url = "$API?action=query&format=json&generator=search&gsrlimit=12&gsrsearch=${OlNet.enc("$q $extra")}" +
            "&prop=pageimages%7Cdescription&piprop=thumbnail&pithumbsize=500&pilimit=12"
        val pages = OlNet.json(url).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val all = ArrayList<Pair<Int, Hit>>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val title = p.s("title")
            if (title.isBlank()) continue
            all.add(
                p.optInt("index", 99) to Hit(title, p.s("description"), p.optJSONObject("thumbnail")?.s("source") ?: ""),
            )
        }
        val sorted = all.sortedBy { it.first }.map { it.second }
        val good = sorted.filter { WRESTLING.containsMatchIn(it.desc) }
        return if (good.isNotEmpty()) good else sorted.take(6)
    }

    /** Cuts the markup out of an infobox value: links, templates, references, line breaks. */
    private fun clean(s: String): String {
        var t = s
        t = t.replace(Regex("(?s)<ref[^>/]*>.*?</ref>"), "").replace(Regex("<ref[^>]*/>"), "")
        t = t.replace(Regex("(?i)<br\\s*/?>"), ", ").replace(Regex("<[^>]+>"), "")
        t = t.replace(Regex("(?i)\\{\\{\\s*(plainlist|ubl|unbulleted list|hlist|flatlist)\\s*\\|"), "").replace("*", ", ")
        var guard = 0
        while (guard++ < 6 && t.contains("{{")) t = t.replace(Regex("\\{\\{[^{}]*\\}\\}"), "")
        t = t.replace("}}", "")
        t = t.replace(Regex("\\[\\[[^\\]|]*\\|([^\\]]*)\\]\\]"), "$1").replace(Regex("\\[\\[([^\\]]*)\\]\\]"), "$1")
        t = t.replace("'''", "").replace("''", "").replace("&nbsp;", " ")
        t = t.replace(Regex("\\s*\\n\\s*"), " ").replace(Regex("(,\\s*)+"), ", ").trim().trim(',').trim()
        return t
    }

    private fun field(wt: String, key: String): String {
        val m = Regex("(?im)^\\s*\\|\\s*$key\\s*=\\s*(.*?)(?=\\n\\s*\\|[^\\n=]*=|\\n\\s*\\}\\})", RegexOption.DOT_MATCHES_ALL).find(wt) ?: return ""
        return clean(m.groupValues[1])
    }

    /** Wikitext of the opening section (it holds the infobox). */
    private fun lead(title: String): String = runCatching {
        val j = OlNet.json("$API?action=query&format=json&formatversion=2&prop=revisions&rvprop=content&rvslots=main&rvsection=0&titles=${OlNet.enc(title)}")
        j.getJSONObject("query").getJSONArray("pages").getJSONObject(0).getJSONArray("revisions").getJSONObject(0)
            .getJSONObject("slots").getJSONObject("main").getString("content")
    }.getOrDefault("")

    private fun qidOf(title: String): String? = runCatching {
        val pp = OlNet.json("$API?action=query&prop=pageprops&ppprop=wikibase_item&format=json&titles=${OlNet.enc(title)}")
        val pages = pp.getJSONObject("query").getJSONObject("pages")
        pages.getJSONObject(pages.keys().next()).getJSONObject("pageprops").getString("wikibase_item")
    }.getOrNull()

    /** The full profile of one Wikipedia article. Every step is allowed to fail on its own. */
    fun profile(title: String): OlProfile {
        var about = ""; var thumb = ""; var desc = ""; var shown = title
        runCatching {
            val s = OlNet.json("https://en.wikipedia.org/api/rest_v1/page/summary/${wikiPath(title)}")
            about = s.s("extract"); desc = s.s("description"); shown = s.s("title").ifBlank { title }
            thumb = s.optJSONObject("thumbnail")?.s("source") ?: ""
        }
        var debut = ""; var trainer = ""; var billed = ""; var ringNames = ""; var birthPlaceWt = ""
        val wt = lead(title)
        if (wt.isNotBlank()) {
            Regex("(?:19|20)\\d{2}").find(field(wt, "debut"))?.value?.let { debut = it }
            trainer = field(wt, "trainer").take(80)
            billed = field(wt, "billed_from").ifBlank { field(wt, "billed") }.take(80)
            ringNames = field(wt, "names").take(120)
            birthPlaceWt = field(wt, "birth_place").substringBefore(",").trim()
        }
        var birthPlace = ""; var geo = ""; var country = ""; var height = ""; var born = ""; var inception = ""
        runCatching {
            val qid = qidOf(title) ?: return@runCatching
            val ent = OlNet.json("https://www.wikidata.org/wiki/Special:EntityData/$qid.json")
                .getJSONObject("entities").getJSONObject(qid).getJSONObject("claims")
            fun first(p: String): JSONObject? = ent.optJSONArray(p)?.optJSONObject(0)?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")
            first("P2048")?.let { v ->
                val amt = v.s("amount").replace("+", "").toDoubleOrNull()
                if (amt != null && amt > 0) {
                    val cm = if (v.s("unit").endsWith("/Q11573") || amt < 3) amt * 100 else amt
                    if (cm in 100.0..260.0) height = cm.toInt().toString()
                }
            }
            first("P569")?.s("time")?.let { Regex("\\d{4}").find(it)?.value?.let { y -> born = y } }
            first("P571")?.s("time")?.let { Regex("\\d{4}").find(it)?.value?.let { y -> inception = y } }
            val placeId = first("P19")?.s("id").orEmpty()
            val countryId = (first("P27") ?: first("P495") ?: first("P17"))?.s("id").orEmpty()
            val hqId = if (countryId.isEmpty()) first("P159")?.s("id").orEmpty() else ""
            val ids = listOf(placeId, countryId, hqId).filter { it.isNotEmpty() }.distinct()
            if (ids.isNotEmpty()) {
                val ents = OlNet.json("https://www.wikidata.org/w/api.php?action=wbgetentities&props=labels%7Cclaims&languages=en&format=json&ids=${ids.joinToString("%7C")}")
                    .getJSONObject("entities")
                fun label(id: String) = ents.optJSONObject(id)?.optJSONObject("labels")?.optJSONObject("en")?.s("value").orEmpty()
                if (placeId.isNotEmpty()) {
                    birthPlace = label(placeId)
                    val c = ents.optJSONObject(placeId)?.optJSONObject("claims")?.optJSONArray("P625")?.optJSONObject(0)
                        ?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")
                    if (c != null && c.has("latitude") && c.has("longitude")) {
                        geo = String.format(java.util.Locale.US, "%.4f, %.4f", c.getDouble("latitude"), c.getDouble("longitude"))
                    }
                }
                if (countryId.isNotEmpty()) country = olCountry(label(countryId))
                else if (hqId.isNotEmpty()) {
                    // headquarters is a city: take its own country
                    val cid = ents.optJSONObject(hqId)?.optJSONObject("claims")?.optJSONArray("P17")?.optJSONObject(0)
                        ?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.s("id").orEmpty()
                    if (cid.isNotEmpty()) {
                        val l = OlNet.json("https://www.wikidata.org/w/api.php?action=wbgetentities&props=labels&languages=en&format=json&ids=$cid")
                            .getJSONObject("entities").optJSONObject(cid)?.optJSONObject("labels")?.optJSONObject("en")?.s("value").orEmpty()
                        country = olCountry(l)
                    }
                }
            }
        }
        if (birthPlace.isBlank()) birthPlace = birthPlaceWt
        return OlProfile(
            title = shown, desc = desc, about = about, thumb = thumb, birthPlace = birthPlace, geo = geo, country = country,
            debut = debut, trainer = trainer, billed = billed, heightCm = height, born = born, inception = inception, ringNames = ringNames,
        )
    }

    /** Wikipedia article thumbnail of a given width, for a stored thumb URL ("/500px-" is swapped). */
    fun bigger(url: String): String = url.replace("/500px-", "/960px-").replace("/320px-", "/960px-")
}


/** Search and profile for the "Find online" sheet of a stable member, in Ringbook mode. */
object OlWrestlers {
    private fun key(n: String) = Normalizer.normalize(n, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().replace(Regex("[^a-z ]"), "").trim()

    /** Wikipedia and TheSportsDB are tried on their own, so one that is down never hides the other. */
    fun search(q: String): List<OlPlayer> {
        val errs = ArrayList<Throwable>()
        fun <T> tryIt(f: () -> List<T>): List<T> = try { f() } catch (e: Exception) { errs.add(e); emptyList() }
        val wiki = tryIt { OlWiki.search(q, "professional wrestler") }.map { h ->
            val r = if (h.thumb.isNotBlank()) listOf(OlRender(h.thumb, "Photo", "Wikipedia", OlWiki.bigger(h.thumb))) else emptyList()
            OlPlayer(h.title.replace(Regex(" \\([^)]*\\)$"), ""), h.desc, h.desc, "", Regex("\\b(19|20)\\d{2}\\b").find(h.desc)?.value ?: "", r, h.title)
        }
        val db = tryIt { OlSportsDb.search(q) }
        if (wiki.isEmpty() && db.isEmpty() && errs.size == 2) throw errs.first()
        val merged = LinkedHashMap<String, OlPlayer>()
        for (p in wiki + db) {
            val k = key(p.name)
            val old = merged[k]
            merged[k] = if (old == null) p else old.copy(
                team = old.team.ifBlank { p.team }, pos = old.pos.ifBlank { p.pos },
                nationality = old.nationality.ifBlank { p.nationality }, born = old.born.ifBlank { p.born },
                renders = (old.renders + p.renders).distinctBy { it.url }, wiki = old.wiki.ifBlank { p.wiki },
            )
        }
        return merged.values.map { p -> p.copy(renders = p.renders.sortedBy { if (it.label == "Photo" || it.label.startsWith("Fan")) 1 else 0 }) }
    }

    /** The profile page for the detail view (facts and about text). */
    fun stats(p: OlPlayer): OlWStats? {
        val title = p.wiki.ifBlank { OlWiki.search(p.name, "professional wrestler").firstOrNull()?.title.orEmpty() }
        if (title.isBlank()) return null
        val pr = OlWiki.profile(title)
        if (pr.about.isBlank() && pr.birthPlace.isBlank()) return null
        val facts = ArrayList<Pair<String, String>>()
        if (pr.ringNames.isNotBlank()) facts.add("Ring names" to pr.ringNames)
        if (pr.born.isNotBlank()) facts.add("Born" to pr.born)
        if (pr.birthPlace.isNotBlank()) facts.add("Birthplace" to pr.birthPlace)
        if (pr.country.isNotBlank()) facts.add("Country" to pr.country)
        if (pr.heightCm.isNotBlank()) facts.add("Height" to "${pr.heightCm} cm")
        if (pr.billed.isNotBlank()) facts.add("Billed from" to pr.billed)
        if (pr.trainer.isNotBlank()) facts.add("Trained by" to pr.trainer)
        if (pr.debut.isNotBlank()) facts.add("Debut" to pr.debut)
        return OlWStats(pr.title, pr.desc, pr.thumb, facts, pr.about)
    }
}

// ================================================================================================ UI
@Composable
fun ColumnScope.OlWDetailPane(p: OlPlayer, onPick: (OlRender) -> Unit) {
    val u = LocalU.current
    val stats = olLoad<OlWStats?>("s:" + p.name + p.wiki) { OlWrestlers.stats(p) }
    val photos = olLoad<List<OlRender>>("c:" + p.name) { OlCommons.photos(p.name) }
    val lead = (stats as? OlState.Ok<OlWStats?>)?.v?.photo?.takeIf { it.isNotBlank() }?.let { OlRender(it, "Photo", "Wikipedia", OlWiki.bigger(it)) }
    val renders = (p.renders + listOfNotNull(lead)).distinctBy { it.url }
    val tight = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)

    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 0.dp, end = 16.dp, bottom = 40.dp)) {
        val sub = listOf(p.team, p.nationality, if (p.born.isNotBlank()) "b. ${p.born}" else "").filter { it.isNotBlank() }
        if (sub.isNotEmpty()) item { Tx(sub.joinToString(" · "), 13 * u.fs, 500, u.mu, tight) }
        item { Tx("Tap a picture to crop it and use it as the render.", 13 * u.fs, 500, u.mu, tight) }

        item { H3("Renders and cut-outs", 4.dp) }
        if (renders.isEmpty()) {
            item {
                val wait = stats is OlState.Busy
                Tx(
                    if (wait) "Looking for renders..." else "No renders for this wrestler yet.",
                    13 * u.fs, 500, u.mu, tight,
                )
            }
        } else olGrid(renders, onPick)

        item { H3("Photos by year", 4.dp) }
        item { Tx("Real photos from Wikimedia Commons (free licences), newest first. Not cut-outs.", 12 * u.fs, 500, u.mu, tight) }
        when (val r = photos) {
            OlState.Busy -> item { Tx("Loading photos...", 13 * u.fs, 500, u.mu, tight) }
            is OlState.Err -> item { Tx(r.msg, 13 * u.fs, 600, u.red, tight) }
            is OlState.Ok -> if (r.v.isEmpty()) item { Tx("No photos found for this name.", 13 * u.fs, 500, u.mu, tight) } else olGrid(r.v, onPick)
        }

        item { H3("Profile", 4.dp) }
        when (val r = stats) {
            OlState.Busy -> item { Tx("Loading profile...", 13 * u.fs, 500, u.mu, tight) }
            is OlState.Err -> item { Tx(r.msg, 13 * u.fs, 600, u.red, tight) }
            is OlState.Ok -> {
                val s = r.v
                if (s == null) {
                    item { Tx("No Wikipedia profile found for this name.", 13 * u.fs, 500, u.mu, tight) }
                } else {
                    item {
                        Tx(s.who, 14 * u.fs, 700, modifier = tight)
                        if (s.desc.isNotBlank()) Tx(s.desc, 12 * u.fs, 500, u.mu, Modifier.padding(horizontal = 4.dp))
                    }
                    items(s.facts) { (k, v) ->
                        KvRow(false, Modifier.padding(horizontal = 4.dp)) {
                            Tx(k, 14 * u.fs, 500, u.mu)
                            Tx(v, 14 * u.fs, 700)
                        }
                    }
                    if (s.about.isNotBlank()) {
                        item { H3("About", 4.dp) }
                        item { Tx(s.about, 13 * u.fs, 500, modifier = tight) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- wrestler lookup
data class OlWClub(val title: String, val name: String, val desc: String, val thumb: String)

object OlWClubs {
    /** Wrestlers, tag teams and stables matching [q]. */
    fun search(q: String): List<OlWClub> =
        OlWiki.search(q, "professional wrestling").map { h ->
            OlWClub(h.title, h.title.replace(Regex(" \\([^)]*\\)$"), ""), h.desc, h.thumb)
        }
}

/** A short About text: whole sentences, at most about 700 characters. */
private fun trimWAbout(s: String, max: Int = 700): String {
    val t = s.replace(Regex("\\s+\\n"), "\n").trim()
    if (t.length <= max) return t
    val cut = t.take(max)
    val end = cut.lastIndexOf(". ")
    return if (end > 200) cut.take(end + 1) else cut.trimEnd() + "..."
}

/** Button for the wrestler form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun WrestlerLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a ring name, pick the wrestler, and hometown, map position, height, debut, trainer, photo and an About text are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) WrestlerLookupSheet(d) { open = false }
}

@Composable
private fun WrestlerLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    val res = olLoad<List<OlWClub>>(query to tick) { if (query.isBlank()) emptyList() else OlWClubs.search(query) }

    fun apply(c: OlWClub) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val (pr, bmp) = withContext(Dispatchers.IO) {
                val e = runCatching { OlWiki.profile(c.title) }.getOrDefault(OlProfile())
                val url = e.thumb.ifBlank { c.thumb }
                val b = if (url.isNotBlank()) OlImages.load(OlWiki.bigger(url), 1024, useCache = false) ?: OlImages.load(url, 1024, useCache = false) else null
                e to b
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", c.name)
            put("nick", pr.ringNames.split(",").firstOrNull { it.isNotBlank() && !it.trim().equals(c.name, true) }?.trim().orEmpty().take(30))
            put("city", pr.birthPlace.ifBlank { pr.billed })
            put("geo", pr.geo)
            put("founded", pr.debut)
            put("cap", pr.heightCm)
            put("chair", pr.trainer)
            put("info", trimWAbout(pr.about))
            if (bmp != null && (replace || d["logo"].isBlank())) {
                d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, bmp) }
            } else if (bmp == null && (pr.thumb.isNotBlank() || c.thumb.isNotBlank())) note = "Filled in, but the photo couldn't be downloaded."
            if (pr.about.isBlank() && pr.birthPlace.isBlank() && pr.debut.isBlank()) note = "Only the name was found. Wikipedia had no details for this one."
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("Wrestler or team name", q, { q = it }, ph = "e.g. Rey Mysterio")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a ring name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the ring name in English.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { c ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(c) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (c.thumb.isNotBlank()) OlThumb(c.thumb, Modifier.size(46.dp), round = true)
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(c.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(c.desc, 12 * u.fs, 500, u.mu, maxLines = 2)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- promotion lookup
object OlWLeagues {
    /** Promotions matching [q]. The Founded year and country are added when one is picked. */
    fun search(@Suppress("UNUSED_PARAMETER") ctx: Context, q: String): List<OlLeague> =
        OlWiki.search(q, "professional wrestling promotion").map { h ->
            OlLeague("wp:${h.title}", h.title.replace(Regex(" \\([^)]*\\)$"), ""), "", "", h.thumb, "", "")
        }

    /** A result that only has its name gets country and founding year when it is picked. */
    fun complete(l: OlLeague): OlLeague {
        if (l.country.isNotBlank() && l.formed.isNotBlank()) return l
        val title = l.id.removePrefix("wp:")
        val p = runCatching { OlWiki.profile(title) }.getOrNull() ?: return l
        return l.copy(
            country = p.country, formed = p.inception, season = p.inception,
            badge = l.badge.ifBlank { p.thumb },
        )
    }

    /** The logo of a Wikipedia article, for results that came without one. */
    fun wikiThumb(title: String): String = runCatching { OlWiki.profile(title).thumb }.getOrDefault("")

    /** "2025-2026" -> "2025/26", "2026" stays. */
    fun season(s: String): String {
        val m = Regex("""^(\d{4})\s*[-/]\s*(\d{4})$""").find(s.trim()) ?: return s.trim()
        return m.groupValues[1] + "/" + m.groupValues[2].takeLast(2)
    }
}

/** Button for the league form. Fills the draft: blank fields always, filled ones only when [replace] is on. */
@Composable
fun PromotionLookup(d: Draft) {
    val u = LocalU.current
    var open by remember { mutableStateOf(false) }
    SmallBtn("Fill from the web", "s") { open = true }
    Tx(
        "Type a promotion name, pick it, and country, founding year, logo and colour are added. Edit anything afterwards.",
        12 * u.fs, 500, u.mu, Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    if (open) PromotionLookupSheet(d) { open = false }
}

@Composable
private fun PromotionLookupSheet(d: Draft, onClose: () -> Unit) {
    val u = LocalU.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(d["name"].trim()) }
    var query by remember { mutableStateOf(q) }
    var tick by remember { mutableIntStateOf(0) }
    var replace by remember { mutableStateOf(d.eid == null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    // search while typing: a moment after the last key
    LaunchedEffect(q) { if (q.trim() != query) { delay(600); query = q.trim() } }
    val res = olLoad<List<OlLeague>>(query to tick) { if (query.isBlank()) emptyList() else OlWLeagues.search(ctx, query) }

    fun apply(picked: OlLeague) {
        if (busy) return
        busy = true; note = ""
        scope.launch {
            val l = withContext(Dispatchers.IO) { OlWLeagues.complete(picked) }
            val (logo, banner) = withContext(Dispatchers.IO) {
                val url = l.badge.ifBlank { if (l.id.startsWith("wp:")) OlWLeagues.wikiThumb(l.name) else "" }
                val b = if (url.isNotBlank()) OlImages.load(url, 512, useCache = false) else null
                val bn = if (l.banner.isNotBlank()) OlImages.load(l.banner, 1400, useCache = false) else null
                b to bn
            }
            fun put(k: String, v: String) { if (v.isNotBlank() && (replace || d[k].isBlank())) d[k] = v }
            put("name", l.name); put("country", l.country); put("season", l.formed.ifBlank { l.season })
            if (logo != null) {
                if (replace || d["color"].isBlank() || d["color"] == "#2da678") OlClubs.crestColors(logo).firstOrNull()?.let { d["color"] = it }
                if (replace || d["logo"].isBlank()) d["logo"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, logo) }
            } else if (l.badge.isNotBlank()) note = "Filled in, but the logo couldn't be downloaded."
            if (banner != null && (replace || d["banner"].isBlank())) d["banner"] = withContext(Dispatchers.IO) { ImageStore.save(ctx, banner) }
            busy = false
            if (note.isBlank()) onClose()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(u.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Hd("Fill from the web", 24f, modifier = Modifier.weight(1f), maxLines = 1)
                Chip("Close", false) { onClose() }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Fld("Promotion name", q, { q = it }, ph = "e.g. All Elite Wrestling")
                SmallBtn("Search") { query = q.trim(); tick++ }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Replace what is already in the form", 13 * u.fs, 600, u.mu, Modifier.weight(1f))
                    Toggle(replace) { replace = !replace }
                }
            }
            if (busy) Tx("Fetching details...", 13 * u.fs, 600, u.mu, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            if (note.isNotBlank()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Tx(note, 13 * u.fs, 600, u.red)
                    SmallBtn("Done", "s") { onClose() }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 40.dp)) {
                when (val r = res) {
                    OlState.Busy -> item { Tx("Searching...", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                    is OlState.Err -> item {
                        Column(Modifier.padding(vertical = 12.dp)) {
                            Tx(r.msg, 14 * u.fs, 600, u.red)
                            SmallBtn("Try again", "s") { tick++ }
                        }
                    }
                    is OlState.Ok -> {
                        if (query.isBlank()) item { Tx("Type a promotion name and press Search.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        else if (r.v.isEmpty()) item { Tx("Nothing found for \"$query\". Try the English name.", 14 * u.fs, 500, u.mu, Modifier.padding(vertical = 12.dp)) }
                        items(r.v) { l ->
                            Row(
                                Modifier.fillMaxWidth().clickable { apply(l) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                if (l.badge.isNotBlank()) OlThumb(l.badge, Modifier.size(46.dp))
                                else Box(Modifier.size(46.dp).background(u.fieldFill))
                                Column(Modifier.weight(1f)) {
                                    Tx(l.name, 15 * u.fs, 700, maxLines = 1)
                                    Tx(listOf(l.country, OlWLeagues.season(l.season)).filter { it.isNotBlank() }.joinToString(" · "), 12 * u.fs, 500, u.mu, maxLines = 1)
                                }
                                if (l.formed.isNotBlank()) Tx(l.formed, 12 * u.fs, 600, u.mu)
                            }
                        }
                    }
                }
            }
        }
    }
}
