package com.matchbook.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

val TN = mapOf("home" to "Home", "clubs" to "Clubs", "leagues" to "Leagues", "add" to "Add", "stats" to "Stats")

class Draft(val eid: String?, init: Map<String, String>) {
    private val m = mutableStateMapOf<String, String>().also { it.putAll(init) }
    operator fun get(k: String) = m[k] ?: ""
    operator fun set(k: String, v: String) { m[k] = v }
}

sealed interface Screen {
    data class ClubS(val id: String) : Screen
    data class LeagueS(val id: String) : Screen
    data class TableS(val id: String) : Screen
    data class FixturesS(val lid: String?) : Screen
    data object SettingsS : Screen
    data class SettingsSubS(val page: String) : Screen
    data object CompareS : Screen
    data object MenuS : Screen
    data object WorldS : Screen
    data class SquadS(val cid: String) : Screen
    data class LineupS(val cid: String) : Screen
    data class FormP(val draft: Draft) : Screen
    data class FormL(val draft: Draft) : Screen
    data class FormC(val draft: Draft) : Screen
    data class FormF(val draft: Draft) : Screen
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val d0 = Store.load(app)
    var settings by mutableStateOf(d0.s); private set
    var leagues by mutableStateOf(d0.leagues); private set
    var clubs by mutableStateOf(d0.clubs); private set
    var fixtures by mutableStateOf(d0.fixtures); private set
    var players by mutableStateOf(d0.players); private set
    var lineups by mutableStateOf(d0.lineups); private set
    var regions by mutableStateOf(d0.regions); private set
    var regionEdit by mutableStateOf<Draft?>(null)   // region editor dialog
    var homeEdit by mutableStateOf(false)            // "Customize Home" dialog
    var mapFull by mutableStateOf<String?>(null)     // full screen map: "home" or "world" (the page it was opened from)
    var pick by mutableStateOf(d0.pick); private set
    var tab by mutableStateOf("home"); private set
    var homeCountry by mutableStateOf("")           // Home page: country shown in the sheet ("" = first one)
    var homeLeague by mutableStateOf("")            // Home page: league of that country shown in the mini table

    private val stack = mutableStateListOf<Screen>()
    val screen: Screen? get() = stack.lastOrNull()
    val backLabel: String get() = if (stack.size >= 2) labelOf(stack[stack.size - 2]) else (TN[tab] ?: "Back")

    var statsLeague by mutableStateOf("all")
    var clubFilter by mutableStateOf("all")
    var st by mutableIntStateOf(1)
    var searchOpen by mutableStateOf(false)
    var query by mutableStateOf("")
    var tableView by mutableStateOf("standings")
    var cmpA by mutableStateOf("")
    var cmpB by mutableStateOf("")
    var clubSort by mutableStateOf("az")          // Coral clubs list: az | pts | lg
    var leagueTab by mutableStateOf("table")      // Coral league page tabs: table | form | stats
    var fixTab by mutableStateOf("up")            // Coral fixtures tabs: up | res
    var navOpen by mutableStateOf(false)          // speed-dial, arc, section sheet and drawer navigation
    var lineupTactics by mutableStateOf(false)    // lineup page mode: false = lineup, true = tactics
    var lineupSel by mutableStateOf("")           // selected token on the pitch: "p3" starter, "b2" bench
    var arrowKind by mutableStateOf("run")

    var splashDone by mutableStateOf(false)
    var pending by mutableStateOf<PendingRestore?>(null)
    var msg by mutableStateOf<String?>(null)
    var hasPrev by mutableStateOf(Store.hasPrev(app))
    var lastBackup by mutableStateOf(Store.lastBackup(app))

    private fun snapshot() = Data(settings, leagues, clubs, fixtures, pick, players, lineups, regions)
    private fun persist() = Store.save(getApplication(), snapshot())
    private fun uid() = UUID.randomUUID().toString().take(6)

    fun lg(id: String) = leagues.find { it.id == id }
    fun cl(id: String) = clubs.find { it.id == id }
    fun pts(c: Club) = c.w * (lg(c.lid)?.pw ?: 3) + c.d * (lg(c.lid)?.pd ?: 1)
    fun nm(c: Club) = if (settings.nm == "short") c.short.ifBlank { c.name.take(3).uppercase() } else c.name
    fun table(lid: String) = clubs.filter { it.lid == lid }
        .sortedWith(compareByDescending<Club> { pts(it) }.thenByDescending { it.gf - it.ga }.thenByDescending { it.gf })
    fun rank(c: Club) = table(c.lid).indexOf(c) + 1

    /** Colour of the last opened club, used for the glow on list pages. */
    fun pickColor() = (cl(pick) ?: clubs.firstOrNull())?.color ?: "#3b3b44"

    fun shownClubs(): List<Club> {
        val q = query.trim()
        val list = clubs.filter { c ->
            (clubFilter == "all" || c.lid == clubFilter) &&
                (q.isEmpty() || listOf(c.name, c.short, c.nick, c.city, c.stadium, lg(c.lid)?.name ?: "").any { it.contains(q, true) })
        }
        return when (clubSort) {
            "pts" -> list.sortedByDescending { pts(it) }
            "lg" -> list.sortedWith(compareBy({ lg(it.lid)?.name ?: "" }, { it.name.lowercase() }))
            "az" -> if (settings.ui == "coral") list.sortedBy { it.name.lowercase() } else list
            else -> list
        }
    }

    fun shownLeagues(): List<League> {
        val q = query.trim()
        return if (q.isEmpty()) leagues else leagues.filter { l -> listOf(l.name, l.country, l.season).any { it.contains(q, true) } }
    }

    /** Earliest fixture that has not finished yet (kick-off up to 2 hours ago counts as still on). */
    fun nextFixture(lid: String? = null, club: String? = null): Fixture? {
        val from = System.currentTimeMillis() - 2 * 3_600_000L
        return fixtures.filter {
            it.at >= from && (lid == null || it.lid == lid) && (club == null || it.home == club || it.away == club)
        }.minByOrNull { it.at }
    }

    fun fixturesOf(lid: String?): List<Fixture> = fixtures.filter { lid == null || it.lid == lid }.sortedBy { it.at }

    fun labelOf(s: Screen): String = when (s) {
        is Screen.ClubS -> cl(s.id)?.name ?: "Club"
        is Screen.LeagueS -> lg(s.id)?.name ?: "League"
        is Screen.TableS -> "Table"
        is Screen.FixturesS -> "Fixtures"
        Screen.SettingsS -> "Settings"
        is Screen.SettingsSubS -> settingsTitle(s.page)
        Screen.CompareS -> "Compare"
        Screen.MenuS -> "Menu"
        Screen.WorldS -> "World"
        is Screen.SquadS -> "Squad"
        is Screen.LineupS -> "Lineup"
        is Screen.FormL, is Screen.FormC, is Screen.FormF, is Screen.FormP -> "Edit"
    }

    // ---- settings
    fun update(f: (Settings) -> Settings) { settings = f(settings); persist() }
    fun set(k: String, v: String) = update { it.put(k, v) }
    fun toggleCol(k: String) = update { it.copy(cols = if (k in it.cols) it.cols - k else it.cols + k) }
    fun toggleField(k: String) = update { it.copy(fields = if (k in it.fields) it.fields - k else it.fields + k) }
    fun toggleBlock(k: String) = update { it.copy(blocks = if (k in it.blocks) it.blocks - k else it.blocks + k) }
    fun applyPreset(id: String) = update { it.preset(id) }
    fun reset() = update { Settings() }

    fun loadSample() {
        val b = seed(); leagues = b.leagues; clubs = b.clubs; fixtures = b.fixtures; players = emptyList(); lineups = emptyList()
        persist()
    }

    fun clearAll() {
        leagues = emptyList(); clubs = emptyList(); fixtures = emptyList(); players = emptyList(); lineups = emptyList(); regions = emptyList(); pick = ""
        clubFilter = "all"; statsLeague = "all"; stack.clear(); persist()
    }

    // ---- navigation (back stack)
    fun selectTab(t: String) { tab = t; stack.clear(); searchOpen = false; query = ""; navOpen = false }
    fun toggleSearch() { searchOpen = !searchOpen; if (!searchOpen) query = "" }
    fun open(s: Screen) { if (stack.lastOrNull() != s) stack.add(s) }
    fun goBack() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun openSettings() { navOpen = false; stack.clear(); stack.add(Screen.SettingsS) }
    fun openSettingsPage(page: String) = open(Screen.SettingsSubS(page))
    var worldCountry by mutableStateOf("")
    var worldLeague by mutableStateOf("")
    fun openWorld() { navOpen = false; stack.clear(); stack.add(Screen.WorldS) }
    fun openMenu() { navOpen = false; stack.clear(); stack.add(Screen.MenuS) }
    fun openSquad(cid: String) = open(Screen.SquadS(cid))
    fun openLineup(cid: String, tactics: Boolean = false) { lineupTactics = tactics; lineupSel = ""; open(Screen.LineupS(cid)) }
    fun openClub(id: String) { pick = id; persist(); open(Screen.ClubS(id)) }
    fun openLeague(id: String) = open(Screen.LeagueS(id))
    fun openTable(id: String) = open(Screen.TableS(id))
    fun openFixtures(lid: String? = null) = open(Screen.FixturesS(lid))
    fun openCompare(a: String? = null) {
        if (a != null) cmpA = a
        if (cmpA.isBlank() || cl(cmpA) == null) cmpA = clubs.firstOrNull()?.id ?: ""
        if (cmpB.isBlank() || cl(cmpB) == null || cmpB == cmpA) cmpB = clubs.firstOrNull { it.id != cmpA }?.id ?: ""
        open(Screen.CompareS)
    }
    private fun resetTo(s: Screen, t: String) { tab = t; stack.clear(); stack.add(s) }

    // ---- new / edit
    fun newLeague(country: String = "") = open(Screen.FormL(Draft(null, mapOf("country" to country, "color" to "#2da678", "pw" to "3", "pd" to "1", "promo" to "1", "rel" to "1"))))
    fun editLeague(id: String) { lg(id)?.let { open(Screen.FormL(Draft(id, it.toMap()))) } }
    fun newClub(lid: String? = null) = open(Screen.FormC(Draft(null, mapOf(
        "lid" to (lid ?: leagues.firstOrNull()?.id ?: ""), "color" to "#0ea5e9", "c2" to "#ffffff",
        "w" to "0", "d" to "0", "l" to "0", "gf" to "0", "ga" to "0", "cap" to "0", "titles" to "0"))))
    fun editClub(id: String) { cl(id)?.let { open(Screen.FormC(Draft(id, it.toMap()))) } }
    fun newFixture(lid: String? = null, club: String? = null) {
        val league = lid ?: club?.let { cl(it)?.lid } ?: leagues.firstOrNull()?.id ?: ""
        val home = club ?: ""
        val soon = (System.currentTimeMillis() / 3_600_000L + 24) * 3_600_000L
        open(Screen.FormF(Draft(null, mapOf("lid" to league, "home" to home, "away" to "", "at" to soon.toString(),
            "venue" to (cl(home)?.stadium ?: "")))))
    }
    fun editFixture(id: String) { fixtures.find { it.id == id }?.let { open(Screen.FormF(Draft(id, it.toMap()))) } }

    fun setClubGeo(id: String, geo: String) { clubs = clubs.map { if (it.id == id) it.copy(geo = geo) else it }; persist() }

    // ---- regions (groups of countries with shared leagues)
    fun regionFor(country: String) = regions.firstOrNull { it.name.equals(country.trim(), true) }
    fun editRegion(id: String?) {
        val r = regions.firstOrNull { it.id == id }
        regionEdit = Draft(r?.id, mapOf("name" to (r?.name ?: ""), "countries" to (r?.countries?.joinToString("|") ?: "")))
    }
    /** Returns an error message, or null when saved. */
    fun saveRegion(d: Draft): String? {
        val name = d["name"].trim()
        val list = d["countries"].split("|").filter { it.isNotBlank() }.distinct()
        if (name.isEmpty()) return "Add a name first"
        if (list.size < 2) return "Pick at least two countries"
        if (regions.any { it.id != d.eid && it.name.equals(name, true) }) return "A region with this name exists"
        if (COUNTRIES.any { it.first.equals(name, true) }) return "That is a country name, pick another"
        val id = d.eid ?: uid()
        val old = regions.firstOrNull { it.id == id }
        regions = if (old != null) regions.map { if (it.id == id) Region(id, name, list) else it } else regions + Region(id, name, list)
        if (old != null && !old.name.equals(name, true)) leagues = leagues.map { if (it.country.trim().equals(old.name, true)) it.copy(country = name) else it }
        persist()
        if (worldCountry == "region:$id") worldLeague = ""
        return null
    }
    fun deleteRegion(id: String) {
        val r = regions.firstOrNull { it.id == id } ?: return
        regions = regions.filter { it.id != id }
        if (worldCountry == "region:$id") worldCountry = ""
        if (homeCountry == "region:$id") homeCountry = ""
        msg = "Region deleted. Its leagues keep the name \"${r.name}\" as their country."
        persist()
    }

    // ---- save / delete
    fun saveLeague(d: Draft): Boolean {
        if (d["name"].isBlank()) return false
        val id = d.eid ?: uid()
        val l = League(id, d["name"].trim(), d["country"], d["season"], d["color"], d["logo"], d["banner"],
            d["pw"].i(), d["pd"].i(), d["promo"].i(), d["rel"].i(),
            d["promoTo"].takeIf { it != id } ?: "", d["relTo"].takeIf { it != id } ?: "", d["quals"])
        leagues = if (d.eid != null) leagues.map { if (it.id == id) l else it } else leagues + l
        persist(); resetTo(Screen.LeagueS(id), "leagues")
        return true
    }

    fun saveClub(d: Draft): Boolean {
        if (d["name"].isBlank() || d["lid"].isBlank()) return false
        val id = d.eid ?: uid()
        val c = Club(id, d["lid"], d["name"].trim(), d["short"].ifBlank { d["name"].trim().take(3) }.uppercase().take(4),
            d["nick"], d["city"], d["founded"], d["stadium"], d["cap"].i(), d["mgr"], d["chair"], d["color"], d["c2"], d["logo"],
            d["titles"].i(), d["w"].i(), d["d"].i(), d["l"].i(), d["gf"].i(), d["ga"].i(), d["hon"], d["info"], d["logoBg"] == "1", d["geo"].trim())
        clubs = if (d.eid != null) clubs.map { if (it.id == id) c else it } else clubs + c
        pick = id; persist(); resetTo(Screen.ClubS(id), "clubs")
        return true
    }

    /** Returns an error message, or null when saved. */
    fun saveFixture(d: Draft): String? {
        if (d["lid"].isBlank()) return "Pick a league first"
        if (d["home"].isBlank() || d["away"].isBlank()) return "Pick both clubs"
        if (d["home"] == d["away"]) return "Pick two different clubs"
        val at = d["at"].toLongOrNull() ?: return "Pick a date and time"
        val id = d.eid ?: uid()
        val f = Fixture(id, d["lid"], d["home"], d["away"], at, d["venue"].trim())
        fixtures = if (d.eid != null) fixtures.map { if (it.id == id) f else it } else fixtures + f
        persist(); goBack()
        return null
    }

    /** Delete without leaving the page (long-press menus). */
    fun removeFixture(id: String) { fixtures = fixtures.filter { it.id != id }; persist() }
    fun removePlayer(id: String) {
        players = players.filter { it.id != id }
        lineups = lineups.map { l ->
            fun clean(s: LineSlot) = if (s.pid == id) s.copy(pid = "") else s
            l.copy(xi = l.xi.map(::clean), bench = l.bench.map(::clean))
        }
        persist()
    }

    fun deleteFixture(id: String) { fixtures = fixtures.filter { it.id != id }; persist(); goBack() }

    fun deleteClub(id: String) {
        clubs = clubs.filter { it.id != id }
        fixtures = fixtures.filter { it.home != id && it.away != id }
        players = players.filter { it.cid != id }
        lineups = lineups.filter { it.cid != id }
        if (cmpA == id) cmpA = ""
        if (cmpB == id) cmpB = ""
        persist(); tab = "clubs"; stack.clear()
    }

    fun deleteLeague(id: String) {
        leagues = leagues.filter { it.id != id }.map {
            it.copy(promoTo = if (it.promoTo == id) "" else it.promoTo, relTo = if (it.relTo == id) "" else it.relTo)
        }
        val gone = clubs.filter { it.lid == id }.map { it.id }.toSet()
        clubs = clubs.filter { it.lid != id }
        fixtures = fixtures.filter { it.lid != id }
        players = players.filter { it.cid !in gone }
        lineups = lineups.filter { it.cid !in gone }
        if (clubFilter == id) clubFilter = "all"
        if (statsLeague == id) statsLeague = "all"
        persist(); tab = "leagues"; stack.clear()
    }

    // ---- squad and lineups
    fun playersOf(cid: String) = players.filter { it.cid == cid }
        .sortedWith(compareBy({ listOf("GK", "DEF", "MID", "FWD").indexOf(it.pos) }, { it.num }, { it.name.lowercase() }))
    fun lineupOf(cid: String): Lineup = lineups.find { it.cid == cid } ?: Lineup(cid)
    fun editLineup(cid: String, f: (Lineup) -> Lineup) {
        val next = f(lineupOf(cid))
        lineups = if (lineups.any { it.cid == cid }) lineups.map { if (it.cid == cid) next else it } else lineups + next
        persist()
    }
    fun resetLineup(cid: String) { lineups = lineups.filter { it.cid != cid }; lineupSel = ""; persist() }
    fun newPlayer(cid: String) = open(Screen.FormP(Draft(null, mapOf("cid" to cid, "pos" to "MID", "num" to "", "name" to "", "img" to ""))))
    fun editPlayer(id: String) { players.find { it.id == id }?.let { open(Screen.FormP(Draft(id, it.toMap()))) } }
    fun savePlayer(d: Draft): String? {
        if (d["name"].isBlank()) return "Add a name first"
        val id = d.eid ?: uid()
        val p = Player(id, d["cid"], d["name"].trim(), d["num"].i(), d["pos"].ifBlank { "MID" }, d["img"])
        players = if (d.eid != null) players.map { if (it.id == id) p else it } else players + p
        persist(); goBack()
        return null
    }
    fun deletePlayer(id: String) {
        players = players.filter { it.id != id }
        lineups = lineups.map { l ->
            fun clean(s: LineSlot) = if (s.pid == id) s.copy(pid = "") else s
            l.copy(xi = l.xi.map(::clean), bench = l.bench.map(::clean))
        }
        persist(); goBack()
    }

    // ---- backup and restore
    fun appVersion(): String {
        val ctx = getApplication<Application>()
        return runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    fun buildNumber(): Long {
        val ctx = getApplication<Application>()
        return runCatching { PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0)) }.getOrDefault(0L)
    }

    fun createBackup(uri: Uri) {
        val ctx = getApplication<Application>()
        val snap = snapshot()
        val ver = appVersion()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { Backup.write(ctx, uri, snap, ver) }
            if (ok) { val t = System.currentTimeMillis(); Store.setLastBackup(ctx, t); lastBackup = t }
            msg = if (ok) "Backup saved" else "Couldn't save the backup"
        }
    }

    fun readBackup(uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { Backup.read(ctx, uri) }
            r.onSuccess { pending = it }.onFailure { msg = it.message ?: "Couldn't read that file" }
        }
    }

    fun cancelRestore() { pending = null }

    fun confirmRestore() {
        val p = pending ?: return
        val ctx = getApplication<Application>()
        Store.savePrev(ctx, snapshot()); hasPrev = true
        Backup.applyImages(ctx, p)
        applyData(p.data)
        pending = null
        msg = "Backup restored"
    }

    fun undoRestore() {
        val ctx = getApplication<Application>()
        val prev = Store.loadPrev(ctx) ?: return
        applyData(prev)
        Store.clearPrev(ctx); hasPrev = false
        msg = "Restore undone"
    }

    private fun applyData(d: Data) {
        settings = d.s; leagues = d.leagues; clubs = d.clubs; fixtures = d.fixtures; pick = d.pick
        players = d.players; lineups = d.lineups; regions = d.regions
        clubFilter = "all"; statsLeague = "all"; cmpA = ""; cmpB = ""; stack.clear()
        persist()
    }
}
