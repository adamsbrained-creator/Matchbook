package com.matchbook.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// =====================================================================================================
// Customize Home (3.9): choose which sections the Home page shows, put them in your order, add the ones
// that are off by default, and bring back clubs or countries that were hidden with a long press.
// =====================================================================================================

/** One section of the Home sheet: id, name, what it shows. The map on top is "map" and always comes first. */
class HomeSection(val id: String, val name: String, val about: String)

val HOME_SECTIONS = listOf(
    HomeSection("title", "Country title", "The name of the country with its numbers of leagues and clubs"),
    HomeSection("countries", "Country chips", "Switch between your countries"),
    HomeSection("leagues", "League chips", "Switch between the leagues of the country"),
    HomeSection("clubs", "Club strip", "The crests of the country's clubs"),
    HomeSection("next", "Next match", "The next fixture of the country"),
    HomeSection("table", "League table", "The top of the table"),
    HomeSection("upcoming", "Upcoming fixtures", "The next four matches of the country"),
    HomeSection("quick", "Quick add", "Buttons to add a club, a fixture or a league, and to open the world map"),
    HomeSection("stats", "Numbers", "Leagues, clubs, players and fixtures of the country"),
)

const val DEFAULT_HOME = "map,title,countries,leagues,clubs,next,table"

fun homeIds(s: String): List<String> = s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()

/** Hides an item from Home when it is shown, shows it again when it is hidden. [key] is "c:<club id>" or "g:<country key>". */
fun AppVM.toggleHomeHide(key: String) = update { it.copy(homeHide = if (key in it.homeHide) it.homeHide - key else it.homeHide + key) }

private fun AppVM.hiddenLabel(key: String): String {
    val v = key.drop(2)
    return if (key.startsWith("c:")) (cl(v)?.name ?: "A club")
    else flag(v.removePrefix("region:")) + (if (v.startsWith("region:")) (regions.find { it.id == v.removePrefix("region:") }?.name ?: v) else v)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeCustomizeDialog(vm: AppVM) {
    val u = LocalU.current
    val s = vm.settings
    val on = homeIds(s.home).filter { it == "map" || HOME_SECTIONS.any { x -> x.id == it } }
    fun save(list: List<String>) = vm.update { it.copy(home = list.joinToString(",")) }
    fun move(id: String, by: Int) {
        val l = on.toMutableList()
        val i = l.indexOf(id)
        val j = i + by
        // the map always stays first, so a section can never move above it
        if (i < 0 || j < 0 || j >= l.size || l[j] == "map") return
        l.removeAt(i); l.add(j, id); save(l)
    }
    fun flip(id: String) {
        if (id in on) save(on - id)
        else save(if (id == "map") listOf("map") + on else on + id)
    }
    // sections that are on come first, in your order, then the ones that are off
    val rows = on.filter { it != "map" }.mapNotNull { id -> HOME_SECTIONS.find { it.id == id } } +
        HOME_SECTIONS.filter { it.id !in on }

    Dialog(onDismissRequest = { vm.homeEdit = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(.94f).heightIn(max = 700.dp).clip(RoundedCornerShape(32.dp))
                .background(if (u.coral) u.menuBg else if (u.dark) Color(0xFF16181D) else Color.White)
                .verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Hd("Customize Home", 26f)
            Tx(
                "Turn sections on or off, and use the arrows to put them in your order. Long press a crest or a country chip on Home to hide it.",
                13 * u.fs, 500, u.mu, lh = 13 * u.fs * 1.5f, modifier = Modifier.padding(bottom = 8.dp),
            )
            // the map
            SectionRow("Map", "The dotted world map at the top", "map" in on, false, false, {}, {}) { flip("map") }
            rows.forEach { sec ->
                val isOn = sec.id in on
                val sections = on.filter { it != "map" }
                val idx = sections.indexOf(sec.id)
                SectionRow(
                    sec.name, sec.about, isOn, isOn && idx > 0, isOn && idx in 0 until sections.size - 1,
                    { move(sec.id, -1) }, { move(sec.id, 1) },
                ) { flip(sec.id) }
            }

            Lbl("Rows in the table")
            SegRow(listOf("3", "4", "6", "8", "10").map { it to it }, s.homeRows.toString()) { v -> vm.update { it.copy(homeRows = v.toInt()) } }

            if (s.homeHide.isNotEmpty()) {
                Lbl("Hidden on Home (tap to show again)")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    s.homeHide.sorted().forEach { k -> Chip(vm.hiddenLabel(k) + "  ×", false) { vm.toggleHomeHide(k) } }
                }
            }
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallBtn("Done") { vm.homeEdit = false }
                SmallBtn("Reset", "s") { vm.update { it.copy(home = DEFAULT_HOME, homeRows = 4, homeHide = emptySet()) } }
            }
        }
    }
}

@Composable
private fun SectionRow(
    name: String, about: String, on: Boolean, canUp: Boolean, canDown: Boolean,
    up: () -> Unit, down: () -> Unit, flip: () -> Unit,
) {
    val u = LocalU.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (u.coral) u.bg else u.fieldFill).padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Column(Modifier.weight(1f).clickable(onClick = flip)) {
            Tx(name, 15 * u.fs, 700, if (on) u.ink else u.mu, maxLines = 1)
            Tx(about, 11.5f * u.fs, 500, u.mu, Modifier.padding(top = 2.dp), lh = 11.5f * u.fs * 1.4f)
        }
        Arrow(true, canUp, up)
        Arrow(false, canDown, down)
        Toggle(on, flip)
    }
}

/** A small up / down button; it is dimmed and does nothing when the section cannot move that way. */
@Composable
private fun Arrow(up: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val u = LocalU.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.rotate(if (up) -90f else 90f)) { Ico("chev", 16.dp, if (enabled) u.ink else u.mu.copy(alpha = .25f), 2.2f) }
    }
}
