# Matchbook 4.0.3

Track clubs, leagues, tables, fixtures, squads, lineups and tactics. Jetpack Compose app.

Open in Android Studio, let Gradle sync, press Run. GitHub Actions builds the APK via
.github/workflows (artifact: matchbook-apk).

## What's new in 4.0.3
- The old green logo is replaced everywhere by the new icon: Settings, the About page, the drawer, the in-app launch screen (its glow is lime now) and the system splash. The Menu page no longer has a logo in its header
- Full screen map: tapping any country selects it, including countries without leagues, which show an "Add league" button

## What's new in 4.0.2
- League "Fill from the web" is more dependable. It now searches while you type (a moment after the last key), fetches the details of the results side by side, waits and retries once when TheSportsDB says "too many requests", remembers details while the app runs, and a result that could not load its details still appears by name and is completed when you pick it. Before, a refused detail request made that league silently vanish from the list

## What's new in 4.0.1
- Fixes the build error in 4.0 (an experimental-API opt-in in the Home page). The workflow in .github/workflows is now manual only: uploading files no longer starts a build

## What's new in 4.0
- Full screen map. A small corner button on the Home map (bottom left) and on the World map (top right) opens the dotted map over the whole screen, with the status bar hidden. It works in portrait and in landscape: turn the phone and the map fills the wider screen. Pinch to zoom, drag to move, tap a country or a pin to pick it, then Show uses it on the page you came from. The globe button returns to the whole world and the cross closes it

## What's new in 3.9
- Customize Home (button at the bottom of the Home page): every part of the page is a section you can switch on or off and move up or down, including the map. Three new sections can be added: Upcoming fixtures (the next four matches of the country), Quick add (add a club, fixture or league, or open the world map) and Numbers (leagues, clubs, players and fixtures). Choose how many rows the mini table shows (3 to 10)
- Long press a club crest in the strip, or a country chip, to hide it from Home. Hidden items are listed in Customize, where a tap brings them back. Hiding only affects the Home page, never your data. All of it is kept in your settings and backups, and Reset returns to the original layout
- The app icon glyph is smaller (about 80%) so it fits launchers that zoom adaptive icons, such as Smart Launcher

## What's new in 3.8
- New app icon: a thin, diagonal football pitch lying in perspective with a faint thick edge and a dotted shot trace ending in the ball, lime lines on black. Adaptive icon (background, foreground and monochrome layers in res/drawable), so round masks and Android 13+ themed icons work. The old icon may stay cached by some launchers until the app is reinstalled or the launcher restarts

## What's new in 3.7
- "Fill from the web" in the league form: type a league (e.g. Premier League), pick it from the list (each result shows its country and season, so the English and the Ukrainian Premier League are easy to tell apart) and the name, country, current season, logo and banner are added, and the league colour is taken from the logo. Like the club version, it only fills empty fields unless "Replace what is already in the form" is on
- Source: TheSportsDB. Its list of football leagues is downloaded once and kept on the phone, so the search itself is quick; Wikipedia is the fallback when it is down or doesn't know the league. Qualification spots, points rules and promotion links are not available from these sources, so they stay yours to set

## What's new in 3.6
- Clubs sit where they really are on the map. The position is looked up from the stadium first (OpenStreetMap, free), then the city, then the older city lookup, so Anfield puts Liverpool on Anfield, not just in the city. Results must fall inside the league's country or region, which rejects look-alike town names
- New "Map position" field in the club form (latitude, longitude, as copied from a maps app) with a Find on map button. Type your own and it is always used. A club whose position was found automatically keeps it, so the map doesn't search again, and you can correct it any time
- Clubs with only a stadium and no city are now placed too. Positions are part of backups

## What's new in 3.5
- Regions: combine several countries into one, for example Balkans with Serbia, Croatia, Bosnia and Moldova. On the World page open Countries, scroll to Regions and tap New region: name it, pick the countries and save
- Give a league the region's name as its country (the country field suggests region names) and the league belongs to the whole region. On the map every country of the region lights up together, tapping any of them selects the region and outlines all its borders, and the region has one pin, one chip on Home and one entry in the World list
- A country that still has its own domestic league keeps its own entry, so a country can have both. Delete the domestic league if the region league replaces it
- Renaming a region renames the country of its leagues. Deleting a region keeps the leagues and the name. Regions are included in backups
- Clubs of a region league are placed on the map by their city, anywhere inside the region

## What's new in 3.4
- Full screen: Settings > Navigation > Full screen hides the status bar and the navigation bar, in portrait and in landscape. Swipe from the top or bottom edge to bring the bars back for a moment. It is kept when you change look presets and in backups
- Map: fixed the stray strip of land that ran from Russia across the ocean to Alaska. Shapes that cross the 180th meridian (Chukotka, the Aleutians, Fiji) are now cut there and drawn on both edges of the map, so Russia also frames and zooms properly

## What's new in 3.3
- Home: the app now starts on a Home page. A dotted map fills the top with a pin for every country that has leagues (the number is its clubs); tap a pin, a lit country or a chip to switch country. The sheet below shows its clubs (tap one to open it), the next match and the top of the league table with its qualification colours. The globe button opens the full World map
- Home is the first item in every navigation style, in the Coral menu and in the swipe order. The Add and Settings pages are unchanged
- The World map is drawn as dots instead of filled shapes. Countries with leagues are lime, the chosen one is bigger, and its border is still outlined
- Crimea is part of Ukraine on the map, so clubs from Simferopol are placed there. The map data is the same file as before, the change is made when it is read
- Labeled dock: the raised Add button now sits in its own slot, since there are six destinations

## What's new in 3.2
- Clubs: new "Plain" look, a list or grid with no card background, just crest, name and league on the page itself. On the Clubs page choose Cards / Plain next to the sort menu; Settings > Pages and grids has "Plain list" and "Plain grid"

## What's new in 3.1
- World map page (Menu > World map in Coral, or the globe button on the Leagues page): real country shapes with borders, pinch to zoom and drag to move
- Countries that have a league light up and carry a pin with the number of leagues; nearby pins merge into a numbered cluster, tap it to zoom in
- Tap a country (or its pin, or its row in the list): its border is outlined, the map zooms to it and its leagues open below. England, Scotland, Wales and Northern Ireland are separate areas
- Tap a league: its table (with qualification badges) opens and its clubs appear on the map, placed by their city. Tap a club pin to open the club
- The map outlines (Natural Earth 1:50m) download once on first use, about 750 KB, and are kept on the phone. Club cities are looked up with Open-Meteo's free geocoding and remembered

## What's new in 3.0
- Tables can show club logos instead of colour dots (switch on the Table page, or Settings > Table columns)
- Qualification spots: in the league form add named badges for places in the table (e.g. Champions League places 1-4, Europa League 5, Conference League 6), each with its own colour. They show as a coloured edge and a small label under the club, plus a legend under the full table. One tap adds the usual three
- Promotion and relegation colours still apply to places no qualification spot covers

## What's new in 2.9.1
- Fixed "HTTP 403" in Fill from the web (and the online player search): TheSportsDB retired its old free key, the app now uses the current one
- If TheSportsDB is unreachable or finds nothing, Fill from the web falls back to Wikipedia (About text, crest, manager, chairman, founded)

## What's new in 2.9
- Screens ease in (short fade and rise) instead of snapping
- Honours show as a tidy bulleted list on the club page
- Fixtures: "Next up" label on the coming match, played matches are softened
- Friendlier empty states with a pitch icon

## What's new in 2.8
- "Fill from the web" on the club form: type a club (e.g. Liverpool), pick it, and name, short name, nickname, city, founded, stadium, capacity, manager, chairman, colours, crest and an About text are filled in. Everything stays editable
- Sources: TheSportsDB (details, crest), Wikipedia (About), Wikidata (manager, chairman). Honours and the titles count are not provided by these sources, so they stay yours to write

## What's new in 2.7
- Gestures from Paperback: swipe right to go back, optional swipe between the main pages, long-press menus on clubs, leagues, fixtures and players
- Lineup builder rebuilt: one touch layer for the whole board, the dragged player floats under the finger, no recomposition while dragging, downsized render cache
- Dropping a player on another swaps them (bench included); dropping on open grass places him exactly where released
- New pitch (stripes, boxes, arcs), rounder tokens, selection halo and a cleaner bench

## What's new in 2.6
- Coral rebuilt on Paperback's design: white page (black in dark), flat soft-grey cards, ink text, coral accent (#f46c4e)
- All twelve navigation styles now work in Coral, in Coral colours. "Menu button" is Coral's own default (Settings > Navigation)
- Paperback-style segmented switch, chips, fields, dialogs, menus, message pill and Menu page
- Existing Coral setups keep their menu button after the update; switching to Coral selects it, switching back selects the floating bar
- Header glow / height / surface options are hidden in Coral (they only apply to Glass)

## What's new in 2.5
- Squad per club, lineup builder (16 formations, drag to position or swap, bench) and a tactics mode (arrows, duties, team instructions)
- Coral interface as an alternative to the Glass look (Settings > Appearance > Interface style, or the "Coral" preset)
- Eleven extra navigation bars (Settings > Navigation); the 2.0 "Docked" option was removed
- Pitch app icon, refreshed icon set, Pitch launch screen
- Data format 3 (squads, lineups, tactics); 2.0 data and backups still load

## Online catalog (added after 2.5)
"Find online" in the player editor and in the lineup slot editor (Online.kt). Needs the INTERNET permission (added to the manifest).
- TheSportsDB (free test key "3"): names, positions, cut-outs / renders / photos
- Wikimedia Commons: real photos labelled by year (free licences), newest first
- Fantasy Premier League (public, unofficial): official PL render, this-season stats, last 5 matches, past seasons. Premier League only
Pick a picture and it goes through the normal crop dialog and ImageStore, so it is saved locally and travels in backups.
Stats are shown, not stored, so the data format is unchanged.

## Lineup renders
A player with a render on the lineup pitch or bench is drawn as the bare render with a name label (no circle); transparent PNG
cut-outs look best. Without a render (or if the file can't be read) the numbered circle is used.

## Settings layout
Settings is a short hub (summary card + grouped rows: LOOK, PAGES, DATA, About), modelled on Paperback's settings. Each row opens its own
page (Screen.SettingsSubS in AppVM, pages in SettingsScreen.kt: look, style, text, nav, pages, blocks, cols, fields, backup, data, about).
To add a setting: put the control on the matching page and, if it should show as the row's value, update the value text in SettingsScreen().

## Upgrading
Same app id (com.matchbook.app): 2.5 installs over 2.0/1.x and keeps your data. Settings and data are migrated
automatically (Store.settingsFromJson / Store.fromJson). Make a backup first (Settings > Backup and restore).

## Backups
One ZIP (data.json + images/). data.json carries a format number (DATA_FORMAT in Models.kt, now 3). New versions read
older formats; a backup from a newer format is refused with a clear message. When you change the JSON layout:
bump DATA_FORMAT and add a migration step.

## Optional fonts
Drop into app/src/main/res/font (lowercase names, picked up automatically):
manrope.ttf (Glass default), outfit.ttf (Coral), anton.ttf (Condensed headings), inter.ttf, nunito.ttf (Rounded).
Variable fonts work. Without them the app uses system fonts.
